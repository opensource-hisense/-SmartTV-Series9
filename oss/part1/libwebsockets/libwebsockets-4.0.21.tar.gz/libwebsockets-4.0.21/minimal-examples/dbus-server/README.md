|Example|Demonstrates|
---|---
minimal-dbus-server|Shows how to run a DBUS session server using lws event loop
minimal-dbus-ws-proxy|Control ws client connections via DBUS
