//<MStar Software>
//******************************************************************************
// MStar Software
// Copyright (c) 2010 - 2012 MStar Semiconductor, Inc. All rights reserved.
// All software, firmware and related documentation herein ("MStar Software") are
// intellectual property of MStar Semiconductor, Inc. ("MStar") and protected by
// law, including, but not limited to, copyright law and international treaties.
// Any use, modification, reproduction, retransmission, or republication of all
// or part of MStar Software is expressly prohibited, unless prior written
// permission has been granted by MStar.
//
// By accessing, browsing and/or using MStar Software, you acknowledge that you
// have read, understood, and agree, to be bound by below terms ("Terms") and to
// comply with all applicable laws and regulations:
//
// 1. MStar shall retain any and all right, ownership and interest to MStar
//    Software and any modification/derivatives thereof.
//    No right, ownership, or interest to MStar Software and any
//    modification/derivatives thereof is transferred to you under Terms.
//
// 2. You understand that MStar Software might include, incorporate or be
//    supplied together with third party`s software and the use of MStar
//    Software may require additional licenses from third parties.
//    Therefore, you hereby agree it is your sole responsibility to separately
//    obtain any and all third party right and license necessary for your use of
//    such third party`s software.
//
// 3. MStar Software and any modification/derivatives thereof shall be deemed as
//    MStar`s confidential information and you agree to keep MStar`s
//    confidential information in strictest confidence and not disclose to any
//    third party.
//
// 4. MStar Software is provided on an "AS IS" basis without warranties of any
//    kind. Any warranties are hereby expressly disclaimed by MStar, including
//    without limitation, any warranties of merchantability, non-infringement of
//    intellectual property rights, fitness for a particular purpose, error free
//    and in conformity with any international standard.  You agree to waive any
//    claim against MStar for any loss, damage, cost or expense that you may
//    incur related to your use of MStar Software.
//    In no event shall MStar be liable for any direct, indirect, incidental or
//    consequential damages, including without limitation, lost of profit or
//    revenues, lost or damage of data, and unauthorized system use.
//    You agree that this Section 4 shall still apply without being affected
//    even if MStar Software has been modified by MStar in accordance with your
//    request or instruction for your use, except otherwise agreed by both
//    parties in writing.
//
// 5. If requested, MStar may from time to time provide technical supports or
//    services in relation with MStar Software to you for your use of
//    MStar Software in conjunction with your or your customer`s product
//    ("Services").
//    You understand and agree that, except otherwise agreed by both parties in
//    writing, Services are provided on an "AS IS" basis and the warranty
//    disclaimer set forth in Section 4 above shall apply.
//
// 6. Nothing contained herein shall be construed as by implication, estoppels
//    or otherwise:
//    (a) conferring any license or right to use MStar name, trademark, service
//        mark, symbol or any other identification;
//    (b) obligating MStar or any of its affiliates to furnish any person,
//        including without limitation, you and your customers, any assistance
//        of any kind whatsoever, or any information; or
//    (c) conferring any license or right under any intellectual property right.
//
// 7. These terms shall be governed by and construed in accordance with the laws
//    of Taiwan, R.O.C., excluding its conflict of law rules.
//    Any and all dispute arising out hereof or related hereto shall be finally
//    settled by arbitration referred to the Chinese Arbitration Association,
//    Taipei in accordance with the ROC Arbitration Law and the Arbitration
//    Rules of the Association by three (3) arbitrators appointed in accordance
//    with the said Rules.
//    The place of arbitration shall be in Taipei, Taiwan and the language shall
//    be English.
//    The arbitration award shall be final and binding to both parties.
//
//******************************************************************************
//<MStar Software>
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2006-2007 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// (��MStar Confidential Information��) by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////////////////////////////
///
/// @file   drvMIU.h
/// @brief  MIU Driver Interface
/// @author MStar Semiconductor Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////

/*! \defgroup G_MIU MIU interface
    \ingroup  G_PERIPHERAL

    \brief 
    MIU is an IP used to manage DRAM, and it supports DRAM Protection, IP Selection, and IP Mask.    
    
    <b>Features</b>

    - MIU Protect: Enable/Disable IPs to read/write a specific memory range.
    - IP Select: To change IPs used in MIU0/MIU1
    - IP Mask: To disable IPs using DRAM.    

    <b> MIU Block Diagram: </b> \n
    \image html drvMIU_pic1.png
    
     \defgroup G_MIU_INIT Initialization Task relative
     \ingroup  G_MIU
     \defgroup G_MIU_COMMON Common Task relative
     \ingroup  G_MIU
     \defgroup G_MIU_CONTROL Control relative
     \ingroup  G_MIU
     \defgroup G_MIU_PROTECT Protect Task relative
     \ingroup  G_MIU
     \defgroup G_MIU_ToBeModified MIU api to be modified
     \ingroup  G_MIU
     \defgroup G_MIU_ToBeRemove MIU api to be removed
     \ingroup  G_MIU
*/

#ifndef _DRV_MIU_H_
#define _DRV_MIU_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "MsTypes.h"
#include "MsDevice.h"

//-------------------------------------------------------------------------------------------------
// Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
// Macros
//-------------------------------------------------------------------------------------------------
#define MIU_DRV_VERSION                 /* Character String for DRV/API version             */  \
    MSIF_TAG,                           /* 'MSIF'                                           */  \
    MSIF_CLASS,                         /* '00'                                             */  \
    MSIF_CUS,                           /* 0x0000                                           */  \
    MSIF_MOD,                           /* 0x0000                                           */  \
    MSIF_CHIP,                                                                                  \
    MSIF_CPU,                                                                                   \
    {'M','I','U','_'},                  /* IP__                                             */  \
    {'0','1'},                          /* 0.0 ~ Z.Z                                        */  \
    {'0','2'},                          /* 00 ~ 99                                          */  \
    {'0','0','2','6','4','8','8','5'},  /* CL#                                              */  \
    MSIF_OS

#define MIU_CLIENT_MAX  0x30


#define bit_check(x,bit_pos)  ((x & bit_pos) != 0) ? TRUE : FALSE


#define set_req_mask_info(reg_addr,base_addr,bEnable,id_pos)  \
    MST_MACRO_START                                                     \
    reg_addr = base_addr;                                               \
    reg_addr = reg_addr + (MS_U16)((id_pos >> 4) * 0x20);                  \
    if(reg_addr == 0x1286)                                              \
        reg_addr = 0x06F6;                                              \
    else if(reg_addr == 0x0686)                                         \
        reg_addr = 0x0628;                                              \
    reg_addr = reg_addr + (MS_U16)(bit_check(id_pos,BIT3));                \
    HAL_MIU_WriteRegBit(reg_addr, bEnable , (1 << (id_pos & (BIT2|BIT1|BIT0)))); \
    MST_MACRO_END

#ifdef ALIGN
#undef ALIGN
#define ALIGN(_val_,_shift_) (((_val_) >> _shift_) << _shift_)
#else
#define ALIGN(_val_,_shift_) (((_val_) >> _shift_) << _shift_)
#endif

//#define _MIU_INTERNEL_USE         //for internel test only
#define _ALIGN(_val_,_shift_) (((_val_) >> _shift_) << _shift_)

//-------------------------------------------------------------------------------------------------
// Type and Structure Declaration
//-------------------------------------------------------------------------------------------------
typedef enum
{
    CLIENT_TSPIWB,          // orz
    CLIENT_STRLD,
    CLIENT_HK51_ICACHE,    // MAU0
    CLIENT_AEON_I,          // MAU0
    CLIENT_FLH_W,           // MAU1
    CLIENT_HK51_XDATA,     // MAU1
    CLIENT_AEON,            // MAU1
    CLIENT_OD_LSB,
    CLIENT_GOP2,
    CLIENT_VE,
    CLIENT_FDSEICH,
    CLIENT_TSP,
    CLIENT_TTXSK,
    CLIENT_SVD_DB,
    CLIENT_FDDECICH,
    CLIENT_OPM,
    CLIENT_DC,
    CLIENT_GOP,
    CLIENT_GOP0,
    CLIENT_GOP1,
    CLIENT_DNRB,    // DNR
    CLIENT_COMB,
    CLIENT_OD,
    CLIENT_MADDMA2,   // DMA2
    CLIENT_MAD,
    CLIENT_SVD_EN,
    CLIENT_GE,
    CLIENT_BDMA,   // MIU_DMA
    CLIENT_NFC,
    CLIENT_USBP1,  // USB20 ??
    CLIENT_USBP2,  //USB20_1 ??
    CLIENT_RVD,
    CLIENT_SVDINTP,
    CLIENT_MVD,
    CLIENT_AESDMA,
    CLIENT_TTX,
    CLIENT_JPD,
    CLIENT_EMAC,
    CLIENT_MAX
} euMIUClientIDTYPE;

typedef struct
{
    MS_U8 miu;
    MS_U8 protect_id;
} stMIUClientID_t;

typedef enum
{
    MIU_CLIENT_NONE,    //none can access
    MIU_CLIENT_DUMMY,
    MIU_CLIENT_ADCDVIPLL_W,
    MIU_CLIENT_AESDMA_RW,
    MIU_CLIENT_AU_R2_RW,
    MIU_CLIENT_BDMA_RW,
    MIU_CLIENT_DC_R,                //same as MIU_CLIENT_MVOP_64BIT_R
    MIU_CLIENT_DISP_IPATH_DI_W,
    MIU_CLIENT_DISP_IPATH_MR_RW,
    MIU_CLIENT_DISP_IPATH_NR_RW,
    MIU_CLIENT_DMA2_RW,
    MIU_CLIENT_DNRA_RW,
    MIU_CLIENT_DSCRMB_RW,
    MIU_CLIENT_DVBC_ADC_RW,
    MIU_CLIENT_EMAC_RW,
    MIU_CLIENT_FCIE_RW,
    MIU_CLIENT_FDDECICH_R,
    MIU_CLIENT_FDSEICH_R,
    MIU_CLIENT_G3D_RW,
    MIU_CLIENT_GE_RW,
    MIU_CLIENT_GOP_W,
    MIU_CLIENT_GOP0_R,
    MIU_CLIENT_GOP1_R,
    MIU_CLIENT_GOP2_R,
    MIU_CLIENT_GOP3_R,
    MIU_CLIENT_HISPEED_UART_RW,
    MIU_CLIENT_HVD_RW,
    MIU_CLIENT_HVD_BBU_R,
    MIU_CLIENT_JPD_RW,
    MIU_CLIENT_M4VE_ME_R,
    MIU_CLIENT_M4VE0_RW,
    MIU_CLIENT_M4VE2_RW,
    MIU_CLIENT_MAU_RW,
    MIU_CLIENT_MAU0_W,
    MIU_CLIENT_MAU1_R,
    MIU_CLIENT_MFE0_W,
    MIU_CLIENT_MFE1_R,
    MIU_CLIENT_MHEG5_DCACHE_RW,
    MIU_CLIENT_MHEG5_ICACHE_R,
    MIU_CLIENT_MHEG5_ICACHE_RW,
    MIU_CLIENT_MHEG5_GDMA_RW,
    MIU_CLIENT_MIPS_R,
    MIU_CLIENT_MIPS_W,
    MIU_CLIENT_MIPS_RW,
    MIU_CLIENT_MOBF_RW,
    MIU_CLIENT_MPIF_RW,
    MIU_CLIENT_MVD_RW,
    MIU_CLIENT_MVD_BBU_RW,
    MIU_CLIENT_MVOP_64BIT_R,
    MIU_CLIENT_MVOP_128BIT_R,
    MIU_CLIENT_NAND_RW,
    MIU_CLIENT_OD_R,
    MIU_CLIENT_OD_W,
    MIU_CLIENT_OD_LSB_W,
    MIU_CLIENT_OD_LSB_R,
    MIU_CLIENT_OPW_W,
    MIU_CLIENT_OTG_RW,
    MIU_CLIENT_PM51_RW,
    MIU_CLIENT_PVR_W,
    MIU_CLIENT_PVR2_W,
    MIU_CLIENT_R2M_R,
    MIU_CLIENT_R2M_W,
    MIU_CLIENT_RASP0_W,
    MIU_CLIENT_RASP1_W,
    MIU_CLIENT_RVD_BBU_R,
    MIU_CLIENT_RVD_RW,
    MIU_CLIENT_SC_DNR_R,
    MIU_CLIENT_SC_DNR_W,
    MIU_CLIENT_SC_IPMAIN_R,
    MIU_CLIENT_SC_IPMAIN_W,
    MIU_CLIENT_SC_IPSUB_R,
    MIU_CLIENT_SC_IPSUB_W,
    MIU_CLIENT_SC_OP_R,
    MIU_CLIENT_SC_OPM_R,
    MIU_CLIENT_SC_TNR_R,
    MIU_CLIENT_SC_TNR_W,
    MIU_CLIENT_STRLD_RW,
    MIU_CLIENT_TSP_R,
    MIU_CLIENT_TSP_W,
    MIU_CLIENT_TSP_ORZ_R,
    MIU_CLIENT_TSP_ORZ_W,
    MIU_CLIENT_USB20_RW,
    MIU_CLIENT_USB_UHC0_RW,
    MIU_CLIENT_USB_UHC1_RW,
    MIU_CLIENT_USB_UHC2_RW,
    MIU_CLIENT_VD_COMB_R,
    MIU_CLIENT_VD_COMB_W,
    MIU_CLIENT_VD_TTX_RW,
    MIU_CLIENT_VD_TTXSL_W,
    MIU_CLIENT_VD_TTXSK_W,
    MIU_CLIENT_VE_W,
    MIU_CLIENT_VE_R,
    MIU_CLIENT_VIF_ADC_W,
    MIU_CLIENT_VIVALDI9_AUDMA_RW,
    MIU_CLIENT_VIVALDI9_DECODER_R,
    MIU_CLIENT_VIVALDI9_DMA_RW,
    MIU_CLIENT_VIVALDI9_LNKLST_R,
    MIU_CLIENT_VIVALDI9_MAD_RW,
    MIU_CLIENT_VIVALDI9_SE_R,
    MIU_CLIENT_MSP_ICACHE_RW,
    MIU_CLIENT_DISP_IPATH_DI_RW,
    MIU_CLIENT_MVOP1_R,
    MIU_CLIENT_LDM_W,
    MIU_CLIENT_LDM_R,
    MIU_CLIENT_T3D_W,
    MIU_CLIENT_T3D_R,
    MIU_CLIENT_MIIC0_RW,
    MIU_CLIENT_MIIC1_RW,
    MIU_CLIENT_MIIC2_W,
    MIU_CLIENT_MAXID,
    MIU_CLIENT_SC_IPMAIN_RW,
    MIU_CLIENT_SC_IPSUB_RW,
    MIU_CLIENT_SC_OPMAIN_RW,
    MIU_CLIENT_FRC_OSD_RW,
    MIU_CLIENT_FRC_IP_R,
    MIU_CLIENT_FRC_IP_W,
    MIU_CLIENT_FRC_OD_R,
    MIU_CLIENT_FRC_OD_W,
    MIU_CLIENT_FRC_OPM_R,
    MIU_CLIENT_FRC_R2_RW,
    MIU_CLIENT_FRC_SC_RW,
    MIU_CLIENT_SC_OP_W,
    MIU_CLIENT_SECURE_R2_RW,
    MIU_CLIENT_SC_2D3D_RW,
    MIU_CLIENT_SC_OD_W,
    MIU_CLIENT_SC_OD_R,
    MIU_CLIENT_SC_LD_RW,
    MIU_CLIENT_GPD_RW,
    MIU_CLIENT_VP6_RW,
    MIU_CLIENT_SDIO_RW,
    MIU_CLIENT_G3D0_RW,
    MIU_CLIENT_G3D1_RW,
    MIU_CLIENT_SECEMAC_RW,
    MIU_CLIENT_USB_UHC3_RW,
    MIU_CLIENT_TSP_PVR0_W,
    MIU_CLIENT_TSP_PVR1_W,
    MIU_CLIENT_MAU0_RW,
    MIU_CLIENT_MAU1_RW,
    MIU_CLIENT_TSP_SEC_W,
    MIU_CLIENT_OPM_R,
    MIU_CLIENT_USB3_RW,
    MIU_CLIENT_SC_DIPW_RW,
    MIU_CLIENT_CMD_QUEUE_RW,
    MIU_CLIENT_TSO_RW,
    MIU_CLIENT_VE_2DMCDI_RW,
    MIU_CLIENT_SC_IPSUB2_R,
    MIU_CLIENT_SC_IPSUB2_W,
    MIU_CLIENT_MIIC_DMA_RW,
    MIU_CLIENT_UART_DMA_RW,
    MIU_CLIENT_NJPD_RW,
    MIU_CLIENT_XD2MIU_RW,
    MIU_CLIENT_VD_R2D_RW,
    MIU_CLIENT_VD_R2I_R,
    MIU_CLIENT_TSP_ORZ_RW,
    MIU_CLIENT_MVOP_SUB_R,
    MIU_CLIENT_SC_DIPW_W,
    MIU_CLIENT_T3D_RW,
    MIU_CLIENT_BT_RW,
    MIU_CLIENT_VE_VBI_R,
    MIU_CLIENT_ARM_RW,
    MIU_CLIENT_SC1_OP_R,
    MIU_CLIENT_SC1_IPMAIN_RW,
    MIU_CLIENT_GOP4_R,
    MIU_CLIENT_GOP5_R,
    MIU_CLIENT_GMAC_RW,
    MIU_CLIENT_SATA_RW,
    MIU_CLIENT_SC_LOCALDIMING_RW,
    MIU_CLIENT_JPD720P_RW,
    MIU_CLIENT_SC_IPM2_R,
    MIU_CLIENT_VIVALDI_DSC_R,
    MIU_CLIENT_TSP_JPD_RW,
    MIU_CLIENT_DEMOD_W,
    MIU_CLIENT_DEMOD_R,
    MIU_CLIENT_DEMOD_ADCDMA_W,
    MIU_CLIENT_GPU_RW,
    MIU_CLIENT_PDW1_RW,
    MIU_CLIENT_GPO0_PDW0_RW,
    MIU_CLIENT_EVD_R,
    MIU_CLIENT_EVD_RW,
    MIU_CLIENT_SC_FRCL_R,
    MIU_CLIENT_SC_FRCR_R,
    MIU_CLIENT_VD_VBI_RW,
    MIU_CLIENT_VD_MHEG5_ICACHE_RW,
    MIU_CLIENT_TSP00_RW,
    MIU_CLIENT_TSP01_RW,
    MIU_CLIENT_TSP02_RW,
    MIU_CLIENT_TSP03_RW,
    MIU_CLIENT_TSP04_RW,
    MIU_CLIENT_TSP05_RW,
    MIU_CLIENT_TSP06_RW,
    MIU_CLIENT_VIVALDI9_COMBINE_RW,
    MIU_CLIENT_TSP07_RW,
    MIU_CLIENT_ISDBT_TDI_R,
    MIU_CLIENT_ISDBT_TDI_W,
    MIU_CLIENT_FI_Queue0_WR,
    MIU_CLIENT_FI_Queue1_WR,
    MIU_CLIENT_SWDC_RW,
    MIU_CLIENT_ISDB1_RW,
    MIU_CLIENT_ISDB2_RW,
    MIU_CLIENT_MIIC3_RW,
    MIU_CLIENT_SECAU_R2_RW,
    MIU_CLIENT_SC_LOCALDIMING_R_RW,
    MIU_CLIENT_SC_LOCALDIMING_L_RW,
    MIU_CLIENT_SC0_L_RW,
    MIU_CLIENT_SC0_R_RW,
    MIU_CLIENT_TSP_FIQ_RW,
    MIU_CLIENT_EVD_R2D_RW,
    MIU_CLIENT_EVD_R2I_R,
    MIU_CLIENT_SECHVD_RW,
    MIU_CLIENT_SECEVD_RW,
    MIU_CLIENT_MFDEC_R,
    MIU_CLIENT_SECMFDEC_R,
    MIU_CLIENT_MIUTEST_R,
    MIU_CLIENT_GOP3_PDW0_RW,
    MIU_CLIENT_SC1_OPMAIN_RW, 
    MIU_CLIENT_SC2_IPSUB_RW, 
    MIU_CLIENT_SC_IPMAIN2_RW, 
    MIU_CLIENT_SC2_OPMAIN_RW, 
    MIU_CLIENT_SC_ODL_RW,
    MIU_CLIENT_SC_ODR_RW,
    MIU_CLIENT_SC1_IPSUB_RW, 
    MIU_CLIENT_EVD_BBU_R,
    MIU_CLIENT_SC_DWIN_W,
    MIU_CLIENT_ZDEC_RW,
    MIU_CLIENT_ZDEC_ACP_RW,
    MIU_CLIENT_USB30_1_RW,
    MIU_CLIENT_USB30_2_RW,
    MIU_CLIENT_3RDHVD_RW,
    MIU_CLIENT_VP9_RW,
    MIU_CLIENT_FRC_R,
    MIU_CLIENT_FRCM_W,
    MIU_CLIENT_SC_OD_RW,
    MIU_CLIENT_SC_OPSUB_W, 
    MIU_CLIENT_FRCS_W,
    MIU_CLIENT_EVD_MTFC_W,
    MIU_CLIENT_EVD_MTFY_W,
    MIU_CLIENT_ZDEC2_RW,
    MIU_CLIENT_SC2_IPMAIN_RW, 
    MIU_CLIENT_MTF_W,
    MIU_CLIENT_DBG_R,
    MIU_CLIENT_DS_R,
    MIU_CLIENT_FRC_R2,
    MIU_CLIENT_MVD_RTO_RW,
    MIU_CLIENT_FRC_FSCM2_RW,
    MIU_CLIENT_FRC_FSCM3_RW,
    MIU_CLIENT_FRC_IPM0_W,
    MIU_CLIENT_FRC_IPM1_W,
    MIU_CLIENT_FRC_OPM0_R,
    MIU_CLIENT_FRC_OPM1_R,
    MIU_CLIENT_FRC_OPME0_R,
    MIU_CLIENT_FRC_OPME1_R,
    MIU_CLIENT_FRC_OPMI0_R,
    MIU_CLIENT_FRC_OPMI1_R,
    MIU_CLIENT_FRC_ME_W,
    MIU_CLIENT_FRC_ME_R,
    MIU_CLIENT_FRC_HR_W,
    MIU_CLIENT_FRC_HR_R,
    MIU_CLIENT_FRC_MI_MERGE_RW,
    MIU_CLIENT_MC2D_RW,
    MIU_CLIENT_CMD_QUEUE1_RW,
    MIU_CLIENT_USB_UHC4_RW,
    MIU_CLIENT_DEMOD_RW,
    MIU_CLIENT_VE_RW,
    MIU_CLIENT_SC_PDW_W,
    MIU_CLIENT_VIVALDI9_R2_ARB_RW,
    MIU_CLIENT_MCU51_DB_TOOL_RW,
    MIU_CLIENT_TSP_RW,
    MIU_CLIENT_TSP_ORZ2_RW,
    MIU_CLIENT_EVD_BBU_RW,
    MIU_CLIENT_DVBC_ADC_W,
    MIU_CLIENT_GMAC1_RW,
    MIU_CLIENT_MFE_RW,
    MIU_CLIENT_VD_R2_L_I_R,
    MIU_CLIENT_VD_R2_L_D_RW,
    MIU_CLIENT_CA_MIU_CROSSBAR_2_RW,
    MIU_CLIENT_TSP08_RW,
    MIU_CLIENT_ZDEC_LZDMA_RW,
    MIU_CLIENT_EVD2_BBU_R,
    MIU_CLIENT_GOP3_DWIN_RW,
    MIU_CLIENT_MVOP_256BIT_R,
    MIU_CLIENT_MFDEC1_R,
    MIU_CLIENT_SC_DYN_SCL_R,
    MIU_CLIENT_SC1_OPM_R,
    MIU_CLIENT_ZDEC_ACP_W,
    MIU_CLIENT_CMD_QUEUE_R,
    MIU_CLIENT_VIVALDI9_DECODER_RW,
    MIU_CLIENT_DEMOD_ADCDMA_RW,
    MIU_CLIENT_MIU_BIST,
    MIU_CLIENT_CA_MIU_CROSSBAR_0_RW,
    MIU_CLIENT_CA_MIU_CROSSBAR_1_RW,
    MIU_CLIENT_SECGMAC_RW,
    MIU_CLIENT_AU_R2_1_RW,
    MIU_CLIENT_TSO_1_RW,
    MIU_CLIENT_TSIO_RW,
    MIU_CLIENT_PCIE_OUTBOUND_RW,
    MIU_CLIENT_PCIE_INBOUND_RW,
    MIU_CLIENT_DDI_0_RW,
    MIU_CLIENT_SC_DIPW_1_RW,
    MIU_CLIENT_EVD_ENGINE1_RW,
    MIU_CLIENT_HVD_ENGINE1_RW,
    MIU_CLIENT_DDI_1_RW,
    MIU_CLIENT_MFDEC0_1_R,
    MIU_CLIENT_MFDEC1_1_R,
    MIU_CLIENT_AUTO_DOWNLOAD_R,
    MIU_CLIENT_MFEH_R,
    MIU_CLIENT_AUDIO_RW,
    MIU_CLIENT_OD_RW,
    MIU_CLIENT_MVOP1_256BIT_R,
    MIU_CLIENT_MVD_256BIT_RW,
    MIU_CLIENT_TSP_FILEIN_RW,
    MIU_CLIENT_TSP_SEC_RW,
    MIU_CLIENT_HDR_L_RW,
    MIU_CLIENT_HDR_R_RW,
    MIU_CLIENT_MIU_CMD_RW,
    MIU_CLIENT_G256_POST_ARB_RW,
    MIU_CLIENT_G128_POST_ARB_RW,
    MIU_CLIENT_G3_PRE_ARB_RW,
    MIU_CLIENT_EVD_2_MIU0_RW,
    MIU_CLIENT_EVD_2_MIU1_RW,
    //Add new after here
}eMIUClientID;

typedef enum
{
    //IP Access MIU0 only
    MIU_SELTYPE_MIU0 = 0,
    //IP Access MIU1 only
    MIU_SELTYPE_MIU1,
    //IP can access MIU0 & MIU1
    MIU_SELTYPE_MIU_ALL,
    //IP Access MIU2 only
    MIU_SELTYPE_MIU2,
    //IP Access MIU3 only
    MIU_SELTYPE_MIU3

}eMIU_SelType;

typedef struct
{
    MS_U8 u8Gp:4;
    MS_U8 u8BitPos:4;
}MIU_ClientInfo;

typedef struct DLL_PACKED
{
    MS_BOOL bHit;
    MS_U8   u8Group;
    MS_U8   u8ClientID;
    MS_U8   u8Block;
}MIU_PortectInfo;

typedef struct
{
    MS_U8   u81st;
    MS_U8   u82nd;
    MS_U8   u83rd;
    MS_U8   u84th;
}MIU_GroupPriority;

typedef enum
{
  E_MIU_0 = 0,
  E_MIU_1,
  E_MIU_2,
  E_MIU_3,
  E_MIU_NUM,
} MIU_ID;

typedef enum
{
  E_MIU_DDR_32MB = 0,
  E_MIU_DDR_64MB,
  E_MIU_DDR_128MB,
  E_MIU_DDR_256MB,
  E_MIU_DDR_512MB,
  E_MIU_DDR_1024MB,
  E_MIU_DDR_2048MB,
}MIU_DDR_SIZE;

typedef enum
{
  E_MIU_DDR3,
  E_MIU_DDR4
}MIU_DDR_TYPE;

typedef enum
{
  E_MIU_CLIENT_64BIT = 0,
  E_MIU_CLIENT_128BIT,
  E_MIU_CLIENT_256BIT,
}eMIU_ClientWidth;

#define MST_MACRO_START     do {
#define MST_MACRO_END       } while (0)


#define set_client_info(client_data,miu_pos,id_code)         \
        MST_MACRO_START                                      \
        client_data->miu = miu_pos;                          \
        client_data->protect_id = id_code;                   \
        MST_MACRO_END


//-------------------------------------------------------------------------------------------------
// Extern Global Variabls
//-------------------------------------------------------------------------------------------------

////////////////////////////////////////////////////////////////////////////////
// include utopia v2  header files here
////////////////////////////////////////////////////////////////////////////////
#include "drvMIU_v2.h"

//-------------------------------------------------------------------------------------------------
// Extern Functions
//-------------------------------------------------------------------------------------------------
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_OPM_R(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_DNRB_R(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_DNRB_W(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_DNRB_RW(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_SC_RW(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_MVOP_R(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_MVD_R(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_MVD_W(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_MVD_RW(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_Mask_Req_AUDIO_RW(MS_U8 u8Mask, MS_U8 u8Miu);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_MaskReq(MS_U8 u8Miu, eMIUClientID eClientID);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_UnMaskReq(MS_U8 u8Miu, eMIUClientID eClientID);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_INIT
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_InitCounter(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// void    MDrv_MIU_VOP_SwitchMIU(MS_U8 u8MiuID);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_PROTECT
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
void    MDrv_MIU_PrintMIUProtectInfo(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_PROTECT
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_U8*  MDrv_MIU_GetDefaultClientID_KernelProtect(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_U16  MDrv_MIU_GetBusWidth(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_SetSsc(MS_U16 u16Fmodulation, MS_U16 u16FDeviation,MS_BOOL bEnable);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_SetSscValue(MS_U8 u8MiuDev, MS_U16 u16Fmodulation, MS_U16 u16FDeviation, MS_BOOL bEnable);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_GetClientID(euMIUClientIDTYPE client_name, stMIUClientID_t *client_read, stMIUClientID_t *client_write);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_Mask(euMIUClientIDTYPE client_name);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_Unmask(euMIUClientIDTYPE client_name);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_MaskByPort(euMIUClientIDTYPE client_name,stMIUClientID_t *ByPort);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_UnmaskByPort(euMIUClientIDTYPE client_name,stMIUClientID_t *ByPort);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_ToBeRemove
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_SetIOMapBase(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_PROTECT
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_ProtectAlign(MS_U32 *u32PageShift);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_Dram_Size(MS_U8 MiuID, MS_U8 DramSize);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_Dram_ReadSize(MS_U8 MiuID, MIU_DDR_SIZE *pDramSize);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_U8 MDrv_MIU_ClinetNumber(MS_U8 u8Blockx);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_PROTECT
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_Protect( MS_U8 u8Blockx, MS_U8 *pu8ProtectId, MS_PHY phy64Start, MS_PHY phy64End, MS_BOOL bSetFlag );
MS_BOOL MDrv_MIU_ProtectEx( MS_U8 u8Blockx, MS_U32 *pu32ProtectId, MS_PHY phy64Start, MS_PHY phy64End, MS_BOOL bSetFlag );
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_IsSupportMIU1(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_SelMIU(eMIUClientID eClientID, eMIU_SelType eType);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_GetClientInfo(MS_U8 u8MiuDev, eMIUClientID eClientID, MIU_ClientInfo *pInfo);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_PROTECT
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_GetProtectInfo(MS_U8 u8MiuDev, MIU_PortectInfo *pInfo);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_SetGroupPriority(MS_U8 u8MiuDev, MIU_GroupPriority sPriority);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_SetHPriorityMask(MS_U8 u8MiuDev, eMIUClientID eClientID, MS_BOOL bMask);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_GetLibVer(const MSIF_Version **ppVersion);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_EnableScramble(MS_BOOL bEnable);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_CONTROL
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_IsScrambleEnabled(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_GetLoading(MS_U8 u8MiuDev, MS_U32 *Loading);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_INIT
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_BOOL MDrv_MIU_Init(void);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
MS_U32 MDrv_MIU_SetPowerState(EN_POWER_MODE u16PowerState);
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// MS_BOOL MDrv_MIU_GetClientWidth(MS_U8 u8MiuDevi, eMIUClientID eClientID, eMIU_ClientWidth *pClientWidth);


MS_BOOL MDrv_MIU_GetDramType(MIU_ID eMiu, MIU_DDR_TYPE* pType);

#ifdef _MIU_INTERNEL_USE 
//-------------------------------------------------------------------------------------------------
/// MOBF Encrypt
/// @ingroup G_MIU_COMMON
/// @param u32Key \b IN: Key
/// @param bEnable \b IN: TRUE/FLASE
/// @return DRVAESDMA_OK : Success
/// @return Others : Fail
//-------------------------------------------------------------------------------------------------
// DLL_PUBLIC MS_BOOL MDrv_MIU_GetLoading(MS_U8 u8MiuDev, MS_U32 *Loading);
#endif

#ifdef __cplusplus
}
#endif

#endif // _DRV_MIU_H_

