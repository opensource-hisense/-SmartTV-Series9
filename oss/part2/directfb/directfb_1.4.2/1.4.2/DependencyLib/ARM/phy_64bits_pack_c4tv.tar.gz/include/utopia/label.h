#ifndef _LABEL_H_
#define _LABEL_H_

#ifdef __cplusplus
extern "C"
{
#endif

#define UTOPIA_RELEASE_LABEL "UNKNOWN"

#ifdef __cplusplus
}
#endif

#endif // _LABEL_H_
