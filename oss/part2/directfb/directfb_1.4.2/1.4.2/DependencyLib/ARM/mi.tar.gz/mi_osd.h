/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
//------------------------------------------------------------------------------
// GetXxx/SetXxx and GetAttr/SetAttr coexist
//------------------------------------------------------------------------------

#ifndef _MI_OSD_H_
#define _MI_OSD_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
typedef MI_HANDLE     MI_HANDLE_L;
typedef MI_HANDLE     MI_HANDLE_W;
typedef MI_HANDLE     MI_HANDLE_S;

#define OSD_VIDEO_READY             0

#define OSD_CAP_READY                0
#define OSD_VMON_READY               0
#define OSD_IMGDEC_READY               0

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_OSD_LAYER_0 = 0,   //for HD
    E_MI_OSD_LAYER_1 = 1,   //for SD
    E_MI_OSD_LAYER_2 = 2,   //for subtitle, cus
    E_MI_OSD_LAYER_3 = 3,   //for still image
    E_MI_OSD_LAYER_4 = 4,
    E_MI_OSD_LAYER_MAX
} MI_OSD_Layer_e;

typedef enum
{
    E_MI_OSD_LAYER_SIZE_720X480,
    E_MI_OSD_LAYER_SIZE_720X576,
    E_MI_OSD_LAYER_SIZE_1280X720,
    E_MI_OSD_LAYER_SIZE_960X1080,
    E_MI_OSD_LAYER_SIZE_1920X1080,
    E_MI_OSD_LAYER_SIZE_3840X2160,
    E_MI_OSD_LAYER_SIZE_4096X2160,
    E_MI_OSD_LAYER_SIZE_CUSTOMIZE,
    E_MI_OSD_LAYER_SIZE_MAX
} MI_OSD_LayerSize_e;

typedef enum
{
    E_MI_OSD_LAYER_CAPABILITY_WINDOW,   //Window number
    E_MI_OSD_LAYER_CAPABILITY_PALETTE,
    E_MI_OSD_LAYER_CAPABILITY_VSTRETCH,
    E_MI_OSD_LAYER_CAPABILITY_AFBC,
    E_MI_OSD_LAYER_CAPABILITY_MAX
} MI_OSD_LayerCapability_e;

typedef enum
{
    E_MI_OSD_SURFACE_CAPABILITY_BUFFER_ALIGN,
    E_MI_OSD_SURFACE_CAPABILITY_PITCH_ALIGN,
    E_MI_OSD_SURFACE_CAPABILITY_MAX
} MI_OSD_SurfaceCapability_e;

typedef enum
{
    E_MI_OSD_COLOR_FORMAT_I1                     = 0x0,
    E_MI_OSD_COLOR_FORMAT_I2                     ,
    E_MI_OSD_COLOR_FORMAT_I4                     ,
    E_MI_OSD_COLOR_FORMAT_I8                     ,
    E_MI_OSD_COLOR_FORMAT_RGB565                 ,
    E_MI_OSD_COLOR_FORMAT_ARGB1555               ,
    E_MI_OSD_COLOR_FORMAT_ARGB4444               ,
    E_MI_OSD_COLOR_FORMAT_ABGR8888               ,
    E_MI_OSD_COLOR_FORMAT_ARGB8888               ,
    E_MI_OSD_COLOR_FORMAT_YUV422_YVYU            ,
    E_MI_OSD_COLOR_FORMAT_YUV422_YUYV            ,
    E_MI_OSD_COLOR_FORMAT_YUV422_UYVY            ,
    E_MI_OSD_COLOR_FORMAT_GENERIC                ,

    E_MI_OSD_COLOR_FORMAT_1ABFGBG12355           ,
    E_MI_OSD_COLOR_FORMAT_FABAFGBG2266           ,
    E_MI_OSD_COLOR_FORMAT_BGR565                 ,
    E_MI_OSD_COLOR_FORMAT_RGBA8888               ,
    E_MI_OSD_COLOR_FORMAT_BGRA8888               ,
} MI_OSD_ColorFormat_e;

typedef enum
{
    /// RGB mode transparent color.
    E_MI_OSD_TRANSPARENT_COLOR_FORMAT_RGB,
    /// index mode transparent color.
    E_MI_OSD_TRANSPARENT_COLOR_FORMAT_INDEX,
} MI_OSD_TransparentColorFormat_e;

typedef enum
{
    E_MI_OSD_RGB_TO_YUV_LIMITED_RANGE,  //Y's values are shifted and scaled to the range [16, 235]
    E_MI_OSD_RGB_TO_YUV_FULL_RANGE, //Y's values are shifted and scaled to full range [0, 255]
} MI_OSD_Rgb2YuvMode_e;

typedef enum
{
    E_MI_OSD_STRETCH_BLIT_TYPE_BILINEAR,
    E_MI_OSD_STRETCH_BLIT_TYPE_NEAREST,
} MI_OSD_StretchBlitType_e;

typedef enum
{
    E_MI_OSD_COLOR_RANGE_FULL,  //0 ~255 (default)
    E_MI_OSD_COLOR_RANGE_LIMIT, //16~235
    E_MI_OSD_COLOR_RANGE_MAX
} MI_OSD_ColorRange_e;

////////////////////////////////////////////////////////////////////////////////
//
//      window
//
////////////////////////////////////////////////////////////////////////////////

typedef enum
{
    E_MI_OSD_Z_ORDER_TOP = 0,
    E_MI_OSD_Z_ORDER_BOTTOM,
    E_MI_OSD_Z_ORDER_UP,
    E_MI_OSD_Z_ORDER_DOWN,
    E_MI_OSD_Z_ORDER_MAX
} MI_OSD_ZOrder_e;

typedef enum
{
    E_MI_OSD_WINDOW_BUFFER_SINGLE = 0,
    E_MI_OSD_WINDOW_BUFFER_DOUBLE,
    E_MI_OSD_WINDOW_BUFFER_EXTERNAL,
    E_MI_OSD_WINDOW_BUFFER_MAX
} MI_OSD_WindowBufferType_e;

////////////////////////////////////////////////////////////////////////////////
//
//      surface
//
////////////////////////////////////////////////////////////////////////////////

typedef enum
{
    E_MI_OSD_MEMORY_MMAP = 0,
    E_MI_OSD_MEMORY_OS,
    E_MI_OSD_MEMORY_PHY_OS,
    E_MI_OSD_MEMORY_MAX
} MI_OSD_MemoryType_e;

typedef enum
{
    E_MI_OSD_SURFACE_OWNER_AP = 0,
    E_MI_OSD_SURFACE_OWNER_SDK,
    E_MI_OSD_SURFACE_OWNER_MAX
} MI_OSD_SurfaceOwner_e;

typedef enum
{
    /// Desitination buffer for LINE, RECT, BLT
    E_MI_OSD_SURFACE_BUFFER_DST                    = 0,
    /// Source buffer for BLT
    E_MI_OSD_SURFACE_BUFFER_SRC                    = 1,
} MI_OSD_SurfaceBufferType_e;

typedef enum
{
    E_MI_OSD_MIRROR_NONE = 0,
    E_MI_OSD_MIRROR_HORIZONTAL, //Left Right
    E_MI_OSD_MIRROR_VERTICAL,   //Top Bottom
    E_MI_OSD_MIRROR_HORIZONTAL_VERTICAL,    //Both
    E_MI_OSD_MIRROR_MAX
} MI_OSD_Mirror_e;

typedef enum
{
    E_MI_OSD_ROTATE_NONE = 0,
    E_MI_OSD_ROTATE_90,     /**<Rotate 90  degree clockwise*/
    E_MI_OSD_ROTATE_180,    /**<Rotate 180 degree clockwise*/
    E_MI_OSD_ROTATE_270,    /**<Rotate 270 degree clockwise*/
    E_MI_OSD_ROTATE_MAX
} MI_OSD_Rotate_e;

typedef enum
{
    /// If EQUAL then perform CK operation
    E_MI_OSD_COLOR_KEY_OPERATION_RGB_EQUAL = 0,
    /// If NOT EQUAL then perform CK operation
    E_MI_OSD_COLOR_KEY_OPERATION_RGB_NOT_EQUAL,
    /// If EQUAL then perform Alpha Key operation
    E_MI_OSD_COLOR_KEY_OPERATION_ALPHA_EQUAL,
    /// If NOT EQUAL then Alpha Key operation
    E_MI_OSD_COLOR_KEY_OPERATION_ALPHA_NOT_EQUAL,
    /// If EQUAL then perform Alpha + Color  Key operation
    E_MI_OSD_COLOR_KEY_OPERATION_ARGB_EQUAL,
    /// If NOT EQUAL then Alpha + Color Key operation
    E_MI_OSD_COLOR_KEY_OPERATION_ARGB_NOT_EQUAL,
    /// Max of CKey op
    E_MI_OSD_COLOR_KEY_OPERATION_MAX,
} MI_OSD_ColorKeyOperation_e;

typedef enum
{
    E_MI_OSD_COLOR_KEY_MODE_SRC = 0,
    E_MI_OSD_COLOR_KEY_MODE_DST,
    E_MI_OSD_COLOR_KEY_MODE_MAX
} MI_OSD_ColorKeyMode_e;

typedef enum
{
    /// constant
    E_MI_OSD_ALPHA_FROM_CONST = 0,
    /// source alpha
    E_MI_OSD_ALPHA_FROM_SRC,
    /// destination alpha
    E_MI_OSD_ALPHA_FROM_DST,
    /// Aout = (Asrc*Aconst) + Adst*(1-Asrc*Aconst)
    E_MI_OSD_ALPHA_FROM_BLEND,

    /// Aout = Asrc*Aconst
    E_MI_OSD_ALPHA_FROM_SRC_CONST,
    /// Aout = Asrc*Aconst*Adst
    E_MI_OSD_ALPHA_FROM_IN,
    /// Aout = (1-Asrc*Aconst) * Adst
    E_MI_OSD_ALPHA_FROM_DSTOUT,
    /// Aout = (1-Adst) * Asrc*Aconst
    E_MI_OSD_ALPHA_FROM_SRCOUT,

    /// 1 - Aconst
    E_MI_OSD_ALPHA_FROM_INV_CONST,
    /// 1 - Asrc
    E_MI_OSD_ALPHA_FROM_INV_ASRC,
    /// 1 - Adst
    E_MI_OSD_ALPHA_FROM_INV_ADST,

    ///max of the enum
    E_MI_OSD_ALPHA_FROM_MAX
} MI_OSD_AlphaFrom_e;

typedef enum
{
    /// source alpha
    E_MI_OSD_CONST_ALPHA_FROM_SRC,
    /// destination alpha
    E_MI_OSD_CONST_ALPHA_FROM_DST,
    /// max of the enum
    E_MI_OSD_CONST_ALPHA_FROM_MAX
} MI_OSD_ConstAlphaFrom_e;

typedef enum
{
    E_MI_OSD_ROP_ZERO ,                     /// 0
    E_MI_OSD_ROP_NOT_PS_OR_PD,              /// ~( rop_src | rop_dst );
    E_MI_OSD_ROP_NS_AND_PD,                 ///((~rop_src) & rop_dst);
    E_MI_OSD_ROP_NS,                        ///~(rop_src);
    E_MI_OSD_ROP_PS_AND_ND,                 ///(rop_src & (~rop_dst));
    E_MI_OSD_ROP_ND,                        ///~(rop_dst);
    E_MI_OSD_ROP_PS_XOR_PD,                 ///( rop_src ^ rop_dst);
    E_MI_OSD_ROP_NOT_PS_AND_PD,             ///~(rop_src & rop_dst);
    E_MI_OSD_ROP_PS_AND_PD,                 ///(rop_src & rop_dst);
    E_MI_OSD_ROP_NOT_PS_XOR_PD,             ///~(rop_dst ^ rop_src);
    E_MI_OSD_ROP_PD,                        ///rop_dst;
    E_MI_OSD_ROP_NS_OR_PD,                  ///(rop_dst | (~rop_src));
    E_MI_OSD_ROP_PS,                        ///rop_src;
    E_MI_OSD_ROP_PS_OR_ND,                  ///(rop_src | (~rop_dst));
    E_MI_OSD_ROP_PD_OR_PS,                  ///(rop_dst | rop_src);
    E_MI_OSD_ROP_ONE,                       ///0xFFFF

    E_MI_OSD_ROP_NONE = 0xFF                /// disable ROP mode

} MI_OSD_RopMode_e;

///color = Csrc * coef + Cdst * (1- coef)
typedef enum
{
    /// Csrc
    E_MI_OSD_BLEND_ONE = 0,
    /// Csrc * Aconst + Cdst * (1 - Aconst)
    E_MI_OSD_BLEND_CONST,
    ///  Csrc * Asrc + Cdst * (1 - Asrc)
    E_MI_OSD_BLEND_ASRC,
    /// Csrc * Adst + Cdst * (1 - Adst)
    E_MI_OSD_BLEND_ADST,

    /// Csrc * (Asrc * Aconst) + Cdst * (1-(Asrc *Aconst))
    E_MI_OSD_BLEND_ROP8_ALPHA,
    /// ((Asrc * Aconst) * Csrc + Adst * Cdst * (1-(Asrc * Aconst))) / (Asrc * Aconst) + Adst * (1- Asrc * Aconst))
    E_MI_OSD_BLEND_ROP8_SRC_OVER,
    /// ((Asrc * Aconst) * Csrc * (1-Adst) + Adst * Cdst) / (Asrc * Aconst) * (1-Adst) + Adst)
    E_MI_OSD_BLEND_ROP8_DST_OVER,

    /// Csrc * Aconst
    E_MI_OSD_BLEND_CONST_SRC,
    /// Csrc * (1 - Aconst)
    E_MI_OSD_BLEND_1_CONST_SRC,

    /// Cdst
    E_MI_OSD_BLEND_ZERO,
    /// Csrc * (1 - Aconst) + Cdst * Aconst
    E_MI_OSD_BLEND_1_CONST,
    /// Csrc * (1 - Asrc) + Cdst * Asrc
    E_MI_OSD_BLEND_1_ASRC,
    ///  Csrc * (1 - Adst) + Cdst * Adst
    E_MI_OSD_BLEND_1_ADST,

    /// Csrc * Adst * Asrc * Aconst + Cdst * Adst * (1 - Asrc * Aconst)
    E_MI_OSD_BLEND_SRC_ATOP_DST,
    /// Cdst * Asrc * Aconst * Adst + Csrc * Asrc * Aconst * (1 - Adst)
    E_MI_OSD_BLEND_DST_ATOP_SRC,
    /// ((1 - Adst) *Csrc) * (Asrc * Aconst) + (Adst * Cdst) * (1 - (Asrc * Aconst))
    E_MI_OSD_BLEND_SRC_XOR_DST,

    ///disable blend mode
    E_MI_OSD_BLEND_NONE = 0xFF ,

} MI_OSD_BlendCoef_e;

typedef enum
{
    ///Asrc * 0, Csrc * 0
    E_MI_OSD_DFB_BLEND_ZERO ,
    ///Asrc * 1, Csrc * 1
    E_MI_OSD_DFB_BLEND_ONE,
    ///Asrc * Asrc, Csrc * Csrc
    E_MI_OSD_DFB_BLEND_SRC_COLOR,
    ///Asrc * (1 - Asrc), Csrc * (1 - Csrc)
    E_MI_OSD_DFB_BLEND_INV_SRC_COLOR,
    ///Asrc * Asrc, Csrc * Asrc
    E_MI_OSD_DFB_BLEND_SRC_ALPHA,
    ///Asrc * (1 - Asrc), Csrc * (1- Asrc)
    E_MI_OSD_DFB_BLEND_INV_SRC_ALPHA,
    ///Asrc * Adst, Csrc * Adst
    E_MI_OSD_DFB_BLEND_DST_ALPHA,
    ///Asrc * (1 - Adst), Csrc * (1 - Adst)
    E_MI_OSD_DFB_BLEND_INV_DST_ALPHA,
    ///Asrc * Adst, Csrc * Cdst
    E_MI_OSD_DFB_BLEND_DST_COLOR,
    ///Asrc * (1 - Adst), Csrc * (1 - Cdst)
    E_MI_OSD_DFB_BLEND_INV_DST_COLOR,
    ///Asrc * 1, Csrc * min(Asrc, (1 - Adst))
    E_MI_OSD_DFB_BLEND_SRC_ALPHA_SAT,
    ///max of the dfb blend
    E_MI_OSD_DFB_BLEND_MAX,

    /// disable dfb blend mode
    E_MI_OSD_DFB_BLEND_NONE = 0xFF,

} MI_OSD_DfbBlendMode_e;

typedef enum
{
    ///Asrc * Aconst (alphach enable) or Aconst (alphach disable)
    E_MI_OSD_DFB_BLEND_FLAG_COLOR_ALPHA         = 0x0001,
    ///Asrc * Aconst  or Asrc * Asmask
    E_MI_OSD_DFB_BLEND_FLAG_ALPHA_CHANNEL       = 0x0002,
    ///Csrc * Cconst
    E_MI_OSD_DFB_BLEND_FLAG_COLORIZE           = 0x0004,
    ///Csrc * Asrc
    E_MI_OSD_DFB_BLEND_FLAG_SRC_PREMUL          = 0x0008,
    ///Csrc * Aconst
    E_MI_OSD_DFB_BLEND_FLAG_SRC_PREMULCOL       = 0x0010,
    ///Cdst * Adst
    E_MI_OSD_DFB_BLEND_FLAG_DST_PREMUL          = 0x0020,
    ///Asrc^Adst, Csrc^Cdst
    E_MI_OSD_DFB_BLEND_FLAG_XOR                = 0x0040,
    ///Asrc / Asrc, Csrc / Asrc
    E_MI_OSD_DFB_BLEND_FLAG_DEMULTIPLY         = 0x0080,

    E_MI_OSD_DFB_BLEND_FLAG_SRC_ALPHA_MASK       = 0x0100,
    E_MI_OSD_DFB_BLEND_FLAG_SRC_COLOR_MASK       = 0x0200,

    ///disable dfb blend flag
    E_MI_OSD_DFB_BLEND_FLAG_NONE               = 0x0,

} MI_OSD_DfbBlendFlag_e;

///Define YOU 422 format
typedef enum
{
    E_MI_OSD_YUV422_YVYU                   = 0,
    E_MI_OSD_YUV422_YUYV                   = 1,
    E_MI_OSD_YUV422_VYUY                   = 2,
    E_MI_OSD_YUV422_UYVY                   = 3,

} MI_OSD_Yuv422Format_e;

typedef enum
{
    E_MI_OSD_INFO_LAYER = 0,
    E_MI_OSD_INFO_WINDOW,
    E_MI_OSD_INFO_SURFACE,
    E_MI_OSD_INFO_ALL,
    E_MI_OSD_INFO_MAX,
} MI_OSD_DumpInfo_e;

typedef enum
{
    E_MI_OSD_WINDOW_CANVAS_AUTO_SWITCH = 0,
    E_MI_OSD_WINDOW_CANVAS_FIX,
    E_MI_OSD_WINDOW_CANVAS_MAX
} MI_OSD_WindowCanvasMode_e;

typedef enum
{
    /// GOP V-Stretch Mode
    E_MI_OSD_V_STRETCH_LINEAR  = 0x0,
    E_MI_OSD_V_STRETCH_LINEAR_GAIN0,
    E_MI_OSD_V_STRETCH_LINEAR_GAIN1,
    E_MI_OSD_V_STRETCH_DUPLICATE,
    E_MI_OSD_V_STRETCH_NEAREST,
    E_MI_OSD_V_STRETCH_LINEAR_GAIN2,
    E_MI_OSD_V_STRETCH_4TAP_DEFAULT,
    E_MI_OSD_V_STRETCH_4TAP_SHARPEST,
    E_MI_OSD_V_STRETCH_MAX

} MI_OSD_VStretchMode_e;

typedef enum
{
    /// GOP H-Stretch Mode
    E_MI_OSD_H_STRETCH_DEFAULT               = 0,
    E_MI_OSD_H_STRETCH_LINEAR                = 1,
    E_MI_OSD_H_STRETCH_NEAREST               = 2,
    E_MI_OSD_H_STRETCH_SHARPNESS_8LEVEL      = 3,
    E_MI_OSD_H_STRETCH_DUPLICATE             = 4,
} MI_OSD_HStretchMode_e;


typedef enum
{
    /// GOP H-Stretch Mode - SHARPNESS Level
    E_MI_OSD_H_STRETCH_NEW4TAP = 0x0,
    E_MI_OSD_H_STRETCH_NEW4TAP_50,
    E_MI_OSD_H_STRETCH_NEW4TAP_55,
    E_MI_OSD_H_STRETCH_NEW4TAP_65,
    E_MI_OSD_H_STRETCH_NEW4TAP_75,
    E_MI_OSD_H_STRETCH_NEW4TAP_85,
    E_MI_OSD_H_STRETCH_NEW4TAP_95,
    E_MI_OSD_H_STRETCH_NEW4TAP_100,
    E_MI_OSD_H_STRETCH_NEW4TAP_105,
    E_MI_OSD_H_STRETCH_NEW4TAP_MAX,
} MI_OSD_HStretchSharpnessLevel_e;

typedef enum
{
    /// GOP 3D Mode
    E_MI_OSD_3D_DISABLE  = 0x0,
    E_MI_OSD_3D_TOP_BOTTOM,
    E_MI_OSD_3D_LEFT_RIGHT,
    E_MI_OSD_3D_MAX

} MI_OSD_3dMode_e;

typedef enum
{
    E_MI_OSD_ATTR_TYPE_V_STRETCH = (0),
    E_MI_OSD_ATTR_TYPE_H_STRETCH,
    E_MI_OSD_ATTR_TYPE_3D_MODE,
    E_MI_OSD_ATTR_TYPE_MIRROR,
    E_MI_OSD_ATTR_TYPE_BLINK_RATE,
    E_MI_OSD_ATTR_TYPE_WAIT_SYNC,
    E_MI_OSD_ATTR_TYPE_DESTINATION,
    E_MI_OSD_ATTR_TYPE_SCREEN_SIZE,
    E_MI_OSD_ATTR_TYPE_AUTO_DETECT_BUFFER,
    E_MI_OSD_ATTR_TYPE_BLENDING_POSITION,
    E_MI_OSD_ATTR_TYPE_CONFIG_WAIT_SYNC,
    E_MI_OSD_ATTR_TYPE_AFBC_MODE,
    E_MI_OSD_ATTR_TYPE_AFBC_CROP,
    E_MI_OSD_ATTR_TYPE_SWITCH_SECURE_AID,
    E_MI_OSD_ATTR_TYPE_SWITCH_INTERFACE_GE,
    E_MI_OSD_ATTR_TYPE_MMA_Authorize,
    E_MI_OSD_ATTR_TYPE_MAX

} MI_OSD_AttrType_e;

/// Stretch bitblt and source color key type
typedef enum
{
    /// Source bilinear stretch then do color key to destination
    E_MI_OSD_COLOR_KEY_STRETCH_BLIT_BILINEAR = 0,
    /// Source do color key then stretch by duplicating edge pixel to destination
    E_MI_OSD_COLOR_KEY_STRETCH_BLIT_NEAREST,
    /// Do color key then bilinear stretch with destination
    E_MI_OSD_COLOR_KEY_STRETCH_BLIT_DST_BILINEAR
} MI_OSD_ColorKeyStretchBlitType_e;

/// Window scroll direction type
typedef enum
{
    E_MI_OSD_WINDOW_SCROLL_DEFAULT = 0, // default right to left
    E_MI_OSD_WINDOW_SCROLL_UP,          // bottom to top
    E_MI_OSD_WINDOW_SCROLL_DOWN,        // top to bottom
    E_MI_OSD_WINDOW_SCROLL_LEFT,        // right to left
    E_MI_OSD_WINDOW_SCROLL_RIGHT,       // left to right
} MI_OSD_WindowScrollType_e;

typedef enum
{
    E_MI_OSD_COLOR_GRADIENT_NONE,
    E_MI_OSD_COLOR_GRADIENT_HORIZONTAL, //Left Right
    E_MI_OSD_COLOR_GRADIENT_VERTICAL,   //Top Bottom
    E_MI_OSD_COLOR_GRADIENT_HORIZONTAL_VERTICAL,    //Both
} MI_OSD_ColorGradient_e;

typedef enum
{
    E_MI_OSD_LAYER_DESTINATION_HD_PATH_OUTPUT = 0x0,
    E_MI_OSD_LAYER_DESTINATION_HD_PATH_INPUT,
    E_MI_OSD_LAYER_DESTINATION_HD_PATH_MAX,

    E_MI_OSD_LAYER_DESTINATION_SD_PATH_OUTPUT = 0x10,
    E_MI_OSD_LAYER_DESTINATION_SD_PATH_INPUT,
    E_MI_OSD_LAYER_DESTINATION_SD_PATH_MAX
} MI_OSD_LayerDestination_e;

typedef enum
{
    E_MI_OSD_LAYER_BLENDING_DEFAULT,            //Select OSD blending position at last
    E_MI_OSD_LAYER_BLENDING_BEFORE_3DLOOKUP,    //Select OSD blending position before RGB 3D LookUP
    E_MI_OSD_LAYER_BLENDING_BEFORE_PQGAMMA,     //Select OSD blending position before gamma table
    E_MI_OSD_LAYER_BLENDING_AFTER_PQGAMMA,      //Select OSD blending position after gamma table
    E_MI_OSD_LAYER_BLENDING_MAX
} MI_OSD_LayerBlendingPosition_e;

typedef enum
{
    E_MI_OSD_CALLBACK_EVENT_DISABLE_BOOTLOGO = MI_BIT(0), //Disable bootlogo
    E_MI_OSD_CALLBACK_EVENT_ALL              = 0xFFFFFFFF,
} MI_OSD_CallbackEvent_e;

typedef enum
{
    MI_OSD_GOP_AID_NS,
    MI_OSD_GOP_AID_SDC,
    MI_OSD_GOP_AID_S,
    MI_OSD_GOP_AID_CSP,
    MI_OSD_GOP_AID_MAX,
} MI_OSD_GOP_AID_TYPE_e;

typedef enum
{
    E_MI_OSD_INTERFACE_GE0,
    E_MI_OSD_INTERFACE_GE1,
    E_MI_OSD_INTERFACR_MAX,
}MI_OSD_GE_INTERFACE_e;

/// OSD init parameter
typedef struct MI_OSD_InitParams_s
{
    MI_BOOL bWaitSync;
    MI_BOOL bAutoFlip;
    MI_OSD_WindowCanvasMode_e eCanvasBufMode;
    MI_U16 u16SupportSurfaceCount;
    MI_BOOL bWaitIdle;
} MI_OSD_InitParams_t;

typedef struct MI_OSD_WindowAlphaInfo_s
{
    MI_BOOL bPixelAlpha;
    MI_U8 u8GlobalAlpha;

} MI_OSD_WindowAlphaInfo_t;

typedef struct MI_OSD_TransparentColor_s
{
    MI_OSD_TransparentColorFormat_e eFormat;
    union
    {
        MI_U32 u32Idx;
        MI_U32 u32Color;
    };
} MI_OSD_TransparentColor_t;

typedef struct MI_OSD_RgbColor_s
{
    /// Blue
    MI_U8 u8Blue;
    /// Green
    MI_U8 u8Green;
    /// Red
    MI_U8 u8Red;
    /// Alpha
    MI_U8 u8Alpha;
} MI_OSD_RgbColor_t;

typedef struct MI_OSD_ContrastColor_s
{
    MI_U16 u16ContrastY;
    MI_U16 u16ContrastU;
    MI_U16 u16ContrastV;
} MI_OSD_ContrastColor_t;

typedef struct MI_OSD_ColorKey_s
{
    MI_OSD_RgbColor_t stMinRgb;
    MI_OSD_RgbColor_t stMaxRgb;
} MI_OSD_ColorKey_t;

typedef struct MI_OSD_ColorKeyInfo_s
{
    MI_OSD_ColorKeyOperation_e eColorKeyOperation;
    MI_OSD_ColorKey_t stColorKey;
    MI_OSD_ColorKeyStretchBlitType_e eColorKeyStretchBlitType;
} MI_OSD_ColorKeyInfo_t;

typedef struct MI_OSD_ColorFormatInfo_s
{
    MI_OSD_ColorFormat_e eColorFormat;
    MI_U8 u8PixelByte;

} MI_OSD_ColorFormatInfo_t;

typedef struct MI_OSD_Rect_s
{
    MI_U32 u32X;
    MI_U32 u32Y;
    MI_U32 u32Width;
    MI_U32 u32Height;
} MI_OSD_Rect_t;

typedef struct MI_OSD_SurfaceQueryInfo_s
{
    MI_OSD_SurfaceCapability_e eCapability;
    MI_OSD_SurfaceBufferType_e eBufType;
    MI_OSD_ColorFormat_e eColorFormat;

} MI_OSD_SurfaceQueryInfo_t;

typedef struct MI_OSD_LayerCustomSize_s
{
    MI_U32 u32X;            // layer coordinate X
    MI_U32 u32Y;            // layer coordinate Y
    MI_U32 u32LayerWidth;   // layer width
    MI_U32 u32LayerHeight;  // layer height
    MI_U32 u32DstWidth;     // for scaling ratio calculation
    MI_U32 u32DstHeight;    // for scaling ratio calculation
} MI_OSD_LayerCustomSize_t;

typedef struct MI_OSD_LayerInfo_s
{
    MI_OSD_Layer_e eLayerId;
    MI_OSD_LayerSize_e eLayerSize;
    MI_OSD_LayerCustomSize_t stLayerCustomSize;   // for Customize layer size.
} MI_OSD_LayerInfo_t;

typedef struct  MI_OSD_WindowInfo_s
{
    MI_HANDLE hLayer;
    MI_OSD_Rect_t stRect;
    MI_BOOL bPixelAlpha;
    MI_OSD_ColorFormat_e eColorFormat;
    MI_OSD_WindowBufferType_e eBufType;
    MI_U32 u32SurfaceWidth;  //window surface width
    MI_U32 u32SurfaceHeight; //window surface height
    MI_BOOL bIsFullFlip;

} MI_OSD_WindowInfo_t;

typedef struct MI_OSD_SurfaceInfo_s
{
    MI_U32 u32Width;
    MI_U32 u32Height;
    MI_U32 u32Pitch;
    MI_OSD_ColorFormat_e eColorFormat;
    MI_OSD_SurfaceOwner_e eOwner;
    MI_OSD_MemoryType_e eMemoryType;
    union
    {
        MI_VIRT virtAddr;
        MI_PHY phyAddr;
    };
    MI_BOOL bReArrange;
} MI_OSD_SurfaceInfo_t;

typedef struct MI_OSD_LineAttr_s
{
    MI_OSD_RgbColor_t stColor;
    MI_U32 u32LineWidth;
    MI_U32 u32X1;
    MI_U32 u32Y1;
    MI_U32 u32X2;
    MI_U32 u32Y2;
    MI_OSD_Rect_t stClipRect;
    MI_BOOL bWaitIdle;

} MI_OSD_LineAttr_t;

typedef struct MI_OSD_RectAttr_s
{
    MI_OSD_RgbColor_t stStartColor;
    MI_OSD_RgbColor_t stEndColor;
    MI_OSD_Rect_t stDstRect;
    MI_OSD_ColorGradient_e eColorGradient;
} MI_OSD_RectAttr_t;

typedef struct MI_OSD_OvalAttr_s
{
    MI_OSD_RgbColor_t stColor;
    MI_OSD_Rect_t stDstRect;
} MI_OSD_OvalAttr_t;

typedef struct MI_OSD_TriangleAttr_s
{
    MI_U32 u32X0;
    MI_U32 u32Y0;
    MI_U32 u32X1;
    MI_U32 u32Y1;
    MI_U32 u32X2;
    MI_U32 u32Y2;
    MI_OSD_RgbColor_t stStartColor;
    MI_OSD_RgbColor_t stEndColor;
    MI_OSD_Rect_t stDstRect;
    MI_OSD_ColorGradient_e eColorGradient;
} MI_OSD_TriangleAttr_t;

typedef struct MI_OSD_SpanForm_s
{
    MI_U32 u32SpanX;
    MI_U32 u32SpanWidth;
} MI_OSD_SpanForm_t;

typedef struct MI_OSD_SpanAttr_s
{
    MI_OSD_SpanForm_t *pstSpanForm;
    MI_U32 u32SpanY;
    MI_U32 u32SpanNum;
    MI_OSD_RgbColor_t stStartColor;
    MI_OSD_RgbColor_t stEndColor;
    MI_OSD_Rect_t stDstRect;
    MI_OSD_ColorGradient_e eColorGradient;
} MI_OSD_SpanAttr_t;

typedef struct MI_OSD_BlitOpt_s
{
    MI_OSD_Mirror_e eMirror;
    MI_OSD_Rotate_e eRotate;
    MI_OSD_BlendCoef_e eBlendMode;
    MI_OSD_DfbBlendMode_e eSrcDfbBlendMode;
    MI_OSD_DfbBlendMode_e eDstDfbBlendMode;
    MI_OSD_DfbBlendFlag_e eDfbBlendFlag;
    MI_BOOL bIsDfbBlend;
    MI_OSD_RopMode_e eRopMode;
    MI_OSD_AlphaFrom_e eAlphaFrom;
    MI_OSD_ConstAlphaFrom_e eConstAlphaFrom;
    MI_OSD_Yuv422Format_e eSrcYuvFormat;
    MI_OSD_Yuv422Format_e eDstYuvFormat;
    MI_OSD_Rect_t stClipRect;
    MI_OSD_RgbColor_t stConstColor;
    MI_BOOL bWaitIdle;
    MI_BOOL bDither;
    MI_OSD_Rgb2YuvMode_e eRgb2YuvMode;
    MI_OSD_StretchBlitType_e eStretchBlitType;
    MI_OSD_Mirror_e eDstMirror;

} MI_OSD_BlitOpt_t;

typedef struct MI_OSD_WindowScrollInfo_s
{
    MI_U8 u8ScrollFrequency;  //Scroll frequency, scroll times per second.
    MI_U16 u16ScrollOffset;  //Scroll offset, unit: pixel.
    MI_OSD_WindowScrollType_e eWindowScrollType;  // Scroll direction.
} MI_OSD_WindowScrollInfo_t;

typedef struct MI_OSD_ColorMatrix_s
{
    MI_BOOL bEnableColorMatrix;
    MI_U16 u16Hue;
    MI_U16 u16Saturation;
    MI_U16 u16Contrast;
    MI_U16 u16Brightness;
    MI_U16 u16RGain;    //range = [0-2047]
    MI_U16 u16GGain;    //range = [0-2047]
    MI_U16 u16BGain;    //range = [0-2047]
    MI_OSD_ColorRange_e eInputRange;
    MI_OSD_ColorRange_e eOutputRange;
} MI_OSD_ColorMatrix_t;

typedef struct MI_OSD_RenderJob_s
{
    MI_U32 u32JobId;
} MI_OSD_RenderJob_t;

/// Define callback function type.
typedef MI_RESULT (*MI_OSD_EventCallback)(MI_HANDLE hOsd, MI_U32 u32Event, void *pEventParams, void *pUserParams);

/// Callback function parameter struct.
typedef struct MI_OSD_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                   ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_OSD_EventCallback pfEventCallback;   ///[IN]: callback function pointer.
    MI_U32 u32EventFlags;                   ///[IN]: registered events which are bitwise OR operation.
    void * pUserParams;                     ///[IN]: for passing user-defined parameters.
} MI_OSD_CallbackInputParams_t;

typedef struct MI_OSD_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                   ///[OUT]: the returned ID for update or unregister callback.
} MI_OSD_CallbackOutputParams_t;

typedef struct MI_OSD_DumpInfoParams_s
{
    MI_OSD_DumpInfo_e eInfo;
} MI_OSD_DumpInfoParams_t;

typedef struct MI_OSD_FlipQueueInfo_s
{
    MI_HANDLE hSurface;
    MI_U8 u8BufferCount;
    MI_OSD_RenderJob_t stRenderJob;
}MI_OSD_FlipQueueInfo_t;

typedef struct MI_OSD_HStretchModeParam_s
{
    MI_OSD_HStretchMode_e eHStretchMode;
    MI_U8 u8SharpnessLevel;                // Sharpness has 0 ~ 7 level, bigger level has more sharp effect.
}MI_OSD_HStretchModeParam_t;

typedef struct MI_OSD_CropParams_s
{
    MI_BOOL bEnableCrop;
    MI_U16 u16AfbcCropX;
    MI_U16 u16AfbcCropY;
    MI_U16 u16AfbcCropWidth;
    MI_U16 u16AfbcCropHeight;
}MI_OSD_AfbcCropParams_t;

typedef struct MI_OSD_GetLayerHandleParams_s
{
    MI_OSD_Layer_e eLayerId;              // Query layer id for get osd layer handle
}MI_OSD_GetLayerHandleParams_t;

typedef struct MI_OSD_AutoDetectBufferInfo_s
{
    MI_BOOL bEnable;
    MI_U8 u8AlphaThreshold;
    MI_BOOL bLargeThanThreshold;
}MI_OSD_AutoDetectBufferInfo_t;

typedef struct MI_OSD_PixelShiftInfo_s
{
    MI_S32 s32HShift; //Stretch window H offset
    MI_S32 s32VShift; //Stretch window V offset
} MI_OSD_PixelShiftInfo_t;

typedef struct MI_OSD_LayerZorder_s
{
    MI_U32 u32Layer0Zorder;
    MI_U32 u32Layer1Zorder;
    MI_U32 u32Layer2Zorder;
} MI_OSD_LayerZorder_t;

typedef struct MI_OSD_MMAAuthorizeParams_s
{
    MI_U8  au8BufferTag[16];
    MI_PHY phyAddr;
    MI_U32 u32Size;
    MI_U32 u32PipeID;
} MI_OSD_MMAAuthorizeParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init OSD module.
/// @param[in] pstInitParams: init parameters
/// @return MI_OK: Process success.
/// @return MI_ERR_RESOURCES: get resource fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_Init(const MI_OSD_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief DeInit OSD module.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Reset OSD module.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_Reset(void);

//------------------------------------------------------------------------------
/// @brief Create a Layer.
/// @param[in] pstLayerInfo: layer info
/// @param[out] phLayer: get layer handler
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerCreate(const MI_OSD_LayerInfo_t *pstLayerInfo, MI_HANDLE *phLayer);

//------------------------------------------------------------------------------
/// @brief Destroy a Layer.
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerDestroy(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief resize Layer, once when output timing is changed
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_FAILED: Handle is invalid.
/// @return MI_ERR_RESOURCES: get resource fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerReSize(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Get Layer size
/// @param[in] hLayer: handle of the layer
/// @param[out] pu32Width: Width of the layer
/// @param[out] pu32Height: Height of the layer
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerGetSize(MI_HANDLE hLayer, MI_U32 *pu32Width,MI_U32 *pu32Height);

//------------------------------------------------------------------------------
/// @brief Show Layer, it will show all windows of the layer
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerShow(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Hide Layer, it will hide all windows of the layer
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerHide(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief get the layer is dhow or hidde
/// @param[in] hLayer: handle of the layer
/// @param[in] *bEnabled: show or hide
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_GetLayerIsEnabled(MI_HANDLE hLayer, MI_BOOL *bEnabled);

//------------------------------------------------------------------------------
/// @brief Query the Capability of the Layer
/// @param[in] hLayer: handle of the layer
/// @param[in] eCapability: query for what parameter
/// @param[out] pOutputParams: get query result value
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerQueryCapability(MI_HANDLE hLayer, MI_OSD_LayerCapability_e eCapability, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set Palette of the Layer
/// @param[in] hLayer: handle of the layer
/// @param[in] pu32PaletteEntry: it should be a 256 bytes data (4 byte RGB x 64)
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerSetPalette(MI_HANDLE hLayer, const MI_U32 *pu32PaletteEntry);

//------------------------------------------------------------------------------
/// @brief Disable Alpla Premul
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerDisableAlphaPremultiply(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Enable Alpla Premul
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerEnableAlphaPremultiply(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Enable transparent Color of the layer
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerEnableTransparentColor(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Disable transparent Color of the layer
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerDisableTransparentColor(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Set transparent Color of the layer
/// @param[in] hLayer: handle of the layer
/// @param[in] pstTransparentColor: transparent color info
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerSetTransparentColor(MI_HANDLE hLayer, const MI_OSD_TransparentColor_t *pstTransparentColor);

//------------------------------------------------------------------------------
/// @brief Set Brightness of the layer
/// @param[in] hLayer: handle of the layer
/// @param[in] u16Brightness: brightness valude, it should be in 0x00~0x1FF range , default is 0x100
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerSetBrightness(MI_HANDLE hLayer, const MI_U16 u16Brightness);

//------------------------------------------------------------------------------
/// @brief Set Contrast of the layer
/// @param[in] hLayer: handle of the layer
/// @param[in] pstContrastColor: YUV valude, it should be in 0x00~0x3F range , default is {0x10, 0x10, 0x10}
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerSetContrast(MI_HANDLE hLayer, const MI_OSD_ContrastColor_t *pstContrastColor);

//------------------------------------------------------------------------------
/// @brief Enable multi alpha of the layer
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerEnableGlobalAlpha(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Disable multi alpha of the layer
/// @param[in] hLayer: handle of the layer
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerDisableGlobalAlpha(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Get OSD Attribute.
/// @param[in] hLayer: Layer handle
/// @param[in] eAttrType: Indicate what attribute is operating.
/// @param[in] pInputParams: Reserved
/// @param[out] pOutputParams: Return attribute value.
///
/// Attribute:
/// --------------------------
/// AttrType        Parameter
/// --------------------------
/// V Stretch   ->  Stretch Mode. (Param Type:MI_OSD_VStretchMode_e)
/// --------------------------
/// @return MI_OK: Get attribute success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerGetAttr(MI_HANDLE hLayer, MI_OSD_AttrType_e eAttrType, const void *pInputParams, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set OSD Attribute.
/// @param[in] hLayer: Layer handle
/// @param[in] eAttrType: Indicate what attribute is operating.
/// @param[in] pAttrParams: Parameter for opeartion.
///
/// Attribute:
/// --------------------------
/// AttrType        Parameter
/// --------------------------
/// V Stretch   ->  Stretch Mode. (Param Type:MI_OSD_VStretchMode_e)
/// --------------------------
/// @return MI_OK: Set attribute success.
/// @return MI_ERR_FAILED: General fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameter not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerSetAttr(MI_HANDLE hLayer, MI_OSD_AttrType_e eAttrType, const void *pAttrParams);

//------------------------------------------------------------------------------
/// @brief Set OSD layer setting updated at once begin
/// @param[in] hLayer: Layer handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: General fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerBeginConfig(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Set OSD layer setting updated at once apply
/// @param[in] hLayer: Layer handle
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: General fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerApplyConfig(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Wait until OSD layer setting has been updated
/// @param[in] hLayer: Layer handle
/// @return MI_OK: Process success.
/// @return MI_ERR_TIMEOUT: Timeout.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerConfigUpdated(MI_HANDLE hLayer);

//------------------------------------------------------------------------------
/// @brief Get customized size of layer
/// @param[in] hLayer: handle of the layer
/// @param[out] pstCustomSize: infomation of customized layer size
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: General fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerGetCustomSize(MI_HANDLE hLayer, MI_OSD_LayerCustomSize_t *pstCustomSize);

//------------------------------------------------------------------------------
/// @brief Set customized size of layer
/// @param[in] hLayer: handle of the layer
/// @param[in] pstCustomSize: infomation of customized layer size
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: General fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerSetCustomSize(MI_HANDLE hLayer, const MI_OSD_LayerCustomSize_t *pstCustomSize);

//------------------------------------------------------------------------------
/// @brief Set Color/Saturation/Contrast/Brightness of layer
/// @param[in] hLayer: handle of the layer
/// @param[in] pstColorMatrix: Hue value, saturation value, contrast value, brightness value
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: General fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerSetColorMatrix(MI_HANDLE hLayer, MI_OSD_ColorMatrix_t *pstColorMatrix);

//------------------------------------------------------------------------------
/// @brief Get Color/Saturation/Contrast/Brightness of layer
/// @param[in]  hLayer: handle of the layer
/// @param[out] pstColorMatrix: Hue value, saturation value, contrast value, brightness value
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: General fail.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerGetColorMatrix(MI_HANDLE hLayer, MI_OSD_ColorMatrix_t *pstColorMatrix);

//------------------------------------------------------------------------------
/// @brief Set OSD LayerZorder
/// @param[in]  stLayerZorder
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_Set_LayerZorder(MI_OSD_LayerZorder_t *pstLayerZorder);

//------------------------------------------------------------------------------
/// @brief MI_OSD_Get_LayerZorder
/// @param[in]  stLayerZorder
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_Get_LayerZorder(MI_OSD_LayerZorder_t *pstLayerZorder);

//------------------------------------------------------------------------------
/// @brief Create Window of the layer
/// @param[in] pstWindowInfo: the window info
/// @param[out] phWindow: get handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_RESOURCES: get resource fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowCreate(const MI_OSD_WindowInfo_t *pstWindowInfo, MI_HANDLE *phWindow);

//------------------------------------------------------------------------------
/// @brief Destroy Window of the layer
/// @param[in] hWindow: the handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowDestroy(MI_HANDLE hWindow);

//------------------------------------------------------------------------------
/// @brief Get Rect of the Window
/// @param[in] hWindow: the handle of the window
/// @param[out] pstRect: the rect of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowGetRect(MI_HANDLE hWindow, MI_OSD_Rect_t *pstRect);

//------------------------------------------------------------------------------
/// @brief Set Rect of the Window
/// @param[in] hWindow: the handle of the window
/// @param[in] pstRect: the rect of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowSetRect(MI_HANDLE hWindow, const MI_OSD_Rect_t *pstRect);

//------------------------------------------------------------------------------
/// @brief Set Rect of the Window
/// @param[in] hWindow: the handle of the window
/// @param[in] pstInputRect: the input rect of the window
/// @param[in] pstOutputRect: the output rect of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowSetRectEx(MI_HANDLE hWindow, const MI_OSD_Rect_t *pstInputRect, const MI_OSD_Rect_t *pstOutputRect);

//------------------------------------------------------------------------------
/// @brief Get ZOrder of the Window
/// @param[in] hWindow: the handle of the window
/// @param[out] pu32ZOrder: the ZOrder of the window, 0 is the height
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowGetZOrder(MI_HANDLE hWindow, MI_U32 *pu32ZOrder);

//------------------------------------------------------------------------------
/// @brief Set ZOrder of the Window
/// @param[in] hWindow: the handle of the window
/// @param[in] eZOrder: the ZOrder of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowSetZOrder(MI_HANDLE hWindow, const MI_OSD_ZOrder_e eZOrder);

//------------------------------------------------------------------------------
/// @brief Get surface handle of the Window, the surface handle is the back buf in case of double buf type
/// @param[in] hWindow: the handle of the window
/// @param[out] phSurface: the surface handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowGetSurface(MI_HANDLE hWindow, MI_HANDLE *phSurface);

//------------------------------------------------------------------------------
/// @brief Flip window surface , it will update the surface content to screen
/// @param[in] hWindow: the handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowFlipSurface(MI_HANDLE hWindow, const MI_OSD_Rect_t *pstFlipRect);

//------------------------------------------------------------------------------
/// @brief Flip window by surface handle, it will update the surface content to screen
/// @param[in] hWindow: the handle of the window
/// @param[in] hSurface: the handle of the surface
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowFlipByExternSurface(MI_HANDLE hWindow, MI_HANDLE hSurface);

//------------------------------------------------------------------------------
/// @brief Flip window by surface handle, it will update the surface content to screen
/// @param[in] hWindow: the handle of the window
/// @param[in] pstFlipQueue: the info of flip surface.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowFlipByExternQueue(MI_HANDLE hWindow, const MI_OSD_FlipQueueInfo_t *pstFlipQueue);

//------------------------------------------------------------------------------
/// @brief shw the window
/// @param[in] hWindow: the handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowShow(MI_HANDLE hWindow);

//------------------------------------------------------------------------------
/// @brief hide the window
/// @param[in] hWindow: the handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowHide(MI_HANDLE hWindow);

//------------------------------------------------------------------------------
/// @brief set alpha info of the window
/// @param[in] hWindow: the handle of the window
/// @param[in] pstAlphaInfo: alpha info of window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowSetAlpha(MI_HANDLE hWindow, const MI_OSD_WindowAlphaInfo_t *pstAlphaInfo);

//------------------------------------------------------------------------------
/// @brief get alpha info of the window
/// @param[in] hWindow: the handle of the window
/// @param[out] pstAlphaInfo: alpha info of window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowGetAlpha(MI_HANDLE hWindow, MI_OSD_WindowAlphaInfo_t *pstAlphaInfo);

//------------------------------------------------------------------------------
/// @brief set scroll info of the window
/// @param[in] hWindow: the handle of the window
/// @param[in] pstScrollInfo: the scroll info
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @retunr MI_ERR_INVALID_PARAMETER: Scroll info is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowSetScrollInfo(MI_HANDLE hWindow, const MI_OSD_WindowScrollInfo_t *pstScrollInfo);

//------------------------------------------------------------------------------
/// @brief get scroll info of the window
/// @param[in] hWindow: the handle of the window
/// @param[out] pstScrollInfo: the scroll info
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowGetScrollInfo(MI_HANDLE hWindow, MI_OSD_WindowScrollInfo_t *pstScrollInfo);

//------------------------------------------------------------------------------
/// @brief enable scroll of the window
/// @param[in] hWindow: the handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Scroll frequency is 0
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowEnableScroll(MI_HANDLE hWindow);

//------------------------------------------------------------------------------
/// @brief enable scroll of the window
/// @param[in] hWindow: the handle of the window
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WindowDisableScroll(MI_HANDLE hWindow);

//------------------------------------------------------------------------------
/// @brief Create surface
/// @param[in] pstSurfInfo: the surface info
/// @param[out] phSurface: get handle of the surface
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: get resource fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceCreate(const MI_OSD_SurfaceInfo_t *pstSurfaceInfo, MI_HANDLE *phSurface);

//------------------------------------------------------------------------------
/// @brief destroy the surface
/// @param[in] hSurface: the handle of the surface
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceDestroy(MI_HANDLE hSurface);

//------------------------------------------------------------------------------
/// @brief get mem type of the surface (the mem is from MMP or linux OS)
/// @param[in] hSurface: the handle of the surface
/// @param[out] peMemoryType: the mem type
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceGetMemoryType(MI_HANDLE hSurface, MI_OSD_MemoryType_e *peMemoryType);

//------------------------------------------------------------------------------
/// @brief get owner of the surface (the surface is controlled by AP or SDK)
/// @param[in] hSurface: the handle of the surface
/// @param[out] peOwner: the owner
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceGetOwner(MI_HANDLE hSurface, MI_OSD_SurfaceOwner_e *peOwner);

//------------------------------------------------------------------------------
/// @brief set const alpha value of the surface,
/// this alpha value will be applied once when alpha blend with const alpha enabled
/// @param[in] hSurface: the handle of the surface
/// @param[in] u8Alpha: constant alpha value
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceSetConstAlpha(MI_HANDLE hSurface, const MI_U8 u8Alpha);

//------------------------------------------------------------------------------
/// @brief get const alpha value of the surface,
/// @param[in] hSurface: the handle of the surface
/// @param[out] pu8Alpha: constant alpha value
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceGetConstAlpha(MI_HANDLE hSurface, MI_U8 *pu8Alpha);

//------------------------------------------------------------------------------
/// @brief Enable color key of the surface
/// @param[in] hSurface: the handle of the surface
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceEnableColorKey(MI_HANDLE hSurface);

//------------------------------------------------------------------------------
/// @brief Disable color key of the surface
/// @param[in] hSurface: the handle of the surface
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceDisableColorKey(MI_HANDLE hSurface);


//------------------------------------------------------------------------------
/// @brief set color key of the surface,
/// @param[in] hSurface: the handle of the surface
/// @param[in] pstColorKey: color key info
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceSetColorKey(MI_HANDLE hSurface, const MI_OSD_ColorKeyInfo_t *pstColorKey);

//------------------------------------------------------------------------------
/// @brief get color key of the surface,
/// @param[in] hSurface: the handle of the surface
/// @param[out] pstColorKey: color key info
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceGetColorKey(MI_HANDLE hSurface, MI_OSD_ColorKeyInfo_t* pstColorKey);

//------------------------------------------------------------------------------
/// @brief set palette table of the surface,
/// @param[in] hSurface: the handle of the surface
/// @param[in] u32Offset: the offset of palette entry
/// @param[in] u32Size: the size of palette
/// @param[in] eColorFormat: indicate palette table belongs to which color format
/// @param[in] pColor: palette table (I1/I2/I4/I8/2266/12355)
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceSetPalette(MI_HANDLE hSurface, MI_U32 u32Offset, MI_U32 u32Size, MI_OSD_ColorFormat_e eColorFormat, const void *pColor);

//------------------------------------------------------------------------------
/// @brief get palette table of the surface,
/// @param[in] hSurface: the handle of the surface
/// @param[out] pu32PaletteEntry: palette table (4 byte RGB x 64 = 256 bytes)
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceGetPalette(MI_HANDLE hSurface, MI_U32 *pu32PaletteEntry);


//------------------------------------------------------------------------------
/// @brief lock the surface , once when the surface will do CPU operation
/// @param[in] phSurface: the handle of the surface
/// @param[out] pvirtDataAddr: the surface address
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceLock(MI_HANDLE hSurface, MI_VIRT *pvirtDataAddr, MI_PHY *pphyDataAddr);

//------------------------------------------------------------------------------
/// @brief unlock the surface
/// @param[in] hSurface: the handle of the surface
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceUnlock(MI_HANDLE hSurface);

//------------------------------------------------------------------------------
/// @brief flush the surface
/// @param[in] hSurface: the handle of the surface
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceFlush(MI_HANDLE hSurface);

//------------------------------------------------------------------------------
/// @brief get size of the surface,
/// @param[in] hSurface: the handle of the surface
/// @param[out] pu32Width: width
/// @param[out] pu32Height: height
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceGetSize(MI_HANDLE hSurface, MI_U32* pu32Width, MI_U32* pu32Height);

//------------------------------------------------------------------------------
/// @brief get color format of the surface,
/// @param[in] hSurface: the handle of the surface
/// @param[out] pstColorFormat: color format info
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceGetColorFormat(MI_HANDLE hSurface, MI_OSD_ColorFormatInfo_t *pstColorFormat);

//------------------------------------------------------------------------------
/// @brief get color format of the surface,
/// @param[in] stQueryInfo: Query info
/// @param[out] pOutputParams: result of query
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceQueryCapability(MI_OSD_SurfaceQueryInfo_t stQueryInfo, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief dump surface content as a bmp file
/// @param[in] hSurface: the handle of the surface
/// @param[out] pszFilePath: file path
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceBmpDump(MI_HANDLE hSurface, const MI_U8 *pszFilePath);

//------------------------------------------------------------------------------
/// @brief Clear Surface content
/// @param[in] hSurface: handle of the surface
/// @param[in] pstClearData: the parameter of clear data, if NULL, default it will be clear to black content
///  if surface is YUV : Set Y in G, U in R, V in B
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_NOT_SUPPORT: Not support to clear the format of surface.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SurfaceClear(MI_HANDLE hSurface,const MI_OSD_RgbColor_t *pstClearData,MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief wait render job done.
/// @param[in] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_WaitRenderDone(const MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief set stretch window offset
/// @param[in] MI_OSD_PixelShiftInfo_t: the H/V offset values
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SetPixelShift(const MI_OSD_PixelShiftInfo_t *pstPixelShift);

//------------------------------------------------------------------------------
/// @brief set pipe delay value
/// @param[in] s32Offset: the pipe delay offset
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SetPipeDelay(MI_S32 s32Offset);

//------------------------------------------------------------------------------
/// @brief begin draw, it should be called before graph engine start (like bitblit, draw line, fill rect)
/// it is a mutex protect of graph engine
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_BeginDraw(void);

//------------------------------------------------------------------------------
/// @brief end draw, it should be called after graph engine end (like bitblit, draw line, fill rect)
/// it will release mutex of graph engine
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_EndDraw(void);

//------------------------------------------------------------------------------
/// @brief Convert to target update rect, once when partial update need, or resize with same ratio
/// @param[in] pstSrcRect: source rect
/// @param[in] pstSrcUpdateRect: source update rect
/// @param[in] pstDstRect: dest rect
/// @param[out] pstDstUpdateRect: get target dest update rect
/// @param[in] eColorFormat: according colorfmt to get align info
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_ConvertUpdateRect(const MI_OSD_Rect_t *pstSrcRect, MI_OSD_Rect_t *pstSrcUpdateRect,
                                   const MI_OSD_Rect_t *pstDstRect, MI_OSD_Rect_t *pstDstUpdateRect, MI_OSD_ColorFormat_e eColorFormat);

//------------------------------------------------------------------------------
/// @brief get default parameter of bitblit operation
/// @param[out] pstBlitOpt: default bitblit parameter
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_GetDefaultBlitOpt(MI_OSD_BlitOpt_t *pstBlitOpt);

//------------------------------------------------------------------------------
/// @brief Get osd layer handler.
/// @param[in] pstQueryParams: The layer id that used for getting corresponding layer handle.
/// @param[out] phLayer: get layer handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid..
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_GetLayerHandle(const MI_OSD_GetLayerHandleParams_t  *pstQueryParams, MI_HANDLE *phLayer);

//------------------------------------------------------------------------------
/// @brief Get osd layer handler.
/// @param[in] hLayer: The layer handle that used for getting corresponding window handle.
/// @param[out] phLayer: get window handler
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid..
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_LayerQueryWindowHandle(MI_HANDLE hLayer, MI_HANDLE *phWindow);

//------------------------------------------------------------------------------
/// @brief Bitblit operation
/// @param[in] hSrcSurface: source handle of the surface
/// @param[in] pstSrcRect: source rect area
/// @param[in] hDstSurface: dest handle of the surface
/// @param[in] pstDstRect: dest rect area
/// @param[in] pstBlitOpt: the parameter of bitblit operation
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_Bitblit(MI_HANDLE hSrcSurface, const MI_OSD_Rect_t *pstSrcRect, MI_HANDLE hDstSurface,
                         const MI_OSD_Rect_t *pstDstRect, const MI_OSD_BlitOpt_t*pstBlitOpt, MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief Fill rectangle
/// @param[in] hDstSurface: dest handle of the surface
/// @param[in] pstRectAttr: Fill attribute
/// @param[in] pstBlitOpt: the parameter of bitblit operation
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_FillRect(MI_HANDLE hDstSurface, const MI_OSD_RectAttr_t *pstRectAttr,
                          const MI_OSD_BlitOpt_t *pstBlitOpt, MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief Draw Line
/// @param[in] hSurface: handler of the surface
/// @param[in] pstLineAttr: line attribute
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_DrawLine(MI_HANDLE hSurface, const MI_OSD_LineAttr_t *pstLineAttr, MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief Draw Line Ex
/// @param[in] hSurface: handler of the surface
/// @param[in] pstLineAttr: line attribute
/// @param[in] pstBlitOpt : BitBlit Option
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_DrawLine_EX(MI_HANDLE hSurface, const MI_OSD_LineAttr_t *pstLineAttr, MI_OSD_RenderJob_t *pstRenderJob, const MI_OSD_BlitOpt_t *pstBlitOpt);

//------------------------------------------------------------------------------
/// @brief Draw Oval
/// @param[in] hSurface: handler of the surface
/// @param[in] pstOvalAttr: oval attribute
/// @param[in] pstBlitOpt: the parameter of bitblit operation
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_DrawOval(MI_HANDLE hSurface, const MI_OSD_OvalAttr_t *pstOvalAttr, const MI_OSD_BlitOpt_t *pstBlitOpt, MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief Fill Triangle
/// @param[in] hSurface: handler of the surface
/// @param[in] pstTriAttr: triangle attribute
/// @param[in] pstBlitOpt: the parameter of bitblit operation
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_FillTriangle(MI_HANDLE hSurface, const MI_OSD_TriangleAttr_t *pstTriAttr, const MI_OSD_BlitOpt_t *pstBlitOpt, MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief Fill Span
/// @param[in] hSurface: handler of the surface
/// @param[in] pstSpanAttr: span attribute
/// @param[in] pstBlitOpt: the parameter of bitblit operation
/// @param[out] pstRenderJob: the rendor job ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_FillSpan(MI_HANDLE hSurface, const MI_OSD_SpanAttr_t *pstSpanAttr, const MI_OSD_BlitOpt_t *pstBlitOpt, MI_OSD_RenderJob_t *pstRenderJob);

//------------------------------------------------------------------------------
/// @brief Register callback
/// @param[in]  hOsd: register callback module handle
/// @param[in]  pstInputParams: Callback input parameters.
/// @param[out]  pstOutputParams: Callback output parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_RegisterCallback(MI_HANDLE hOsd, const MI_OSD_CallbackInputParams_t *pstInputParams, MI_OSD_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Unregister callback
/// @param[in]  hOsd: unregister callback module handle
/// @param[in]  pstInputParams: Callback input parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_UnRegisterCallback(MI_HANDLE hOsd, const MI_OSD_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief disable bootlogo, it should be called once when app start to run
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_DisableBootLogo(void);

//------------------------------------------------------------------------------
/// @brief Dump OSD Info.
/// @param[in] pstDumpInfoParams: the parameters of info
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_DumpInfo(const MI_OSD_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set OSD debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_OSD_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);


#ifdef __cplusplus
}
#endif

#endif

