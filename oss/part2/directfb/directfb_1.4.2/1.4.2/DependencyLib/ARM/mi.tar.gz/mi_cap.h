/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_CAP_H_
#define _MI_CAP_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    /// DISPLAY PATH OUTPUT
    E_MI_CAP_DISP_PATH_SRC_OUTPUT = 0,
    /// DISPLAY PATH INPUT
    E_MI_CAP_DISP_PATH_SRC_INPUT,
    /// DISPLAY PATH MAX
    E_MI_CAP_DISP_PATH_SRC_MAX,
} MI_CAP_DispPathSrc_e;

typedef enum
{
    /// idle status
    E_MI_CAP_STATUS_IDLE = 0,
    /// still image is showed
    E_MI_CAP_STATUS_STILL= MI_BIT(0),
    /// capture is continuously
    E_MI_CAP_STATUS_START = MI_BIT(1),
    E_MI_CAP_STATUS_MAX

} MI_CAP_Status_e;

typedef enum
{
    /// YCrYCb. (YUYV arrangement)
    E_MI_CAP_OUTPUT_FMT_YUV422 = 0,
    /// RGB domain
    E_MI_CAP_OUTPUT_FMT_RGB565,
    /// RGB domain
    E_MI_CAP_OUTPUT_FMT_ARGB8888,
    /// YUV420
    E_MI_CAP_OUTPUT_FMT_YUV420,
    /// YC separate 422
    E_MI_CAP_OUTPUT_FMT_YC422,
    // NV12
    E_MI_CAP_OUTPUT_FMT_NV12,

    E_MI_CAP_OUTPUT_FMT_MAX
} MI_CAP_OutputFmt_e;

typedef enum
{
    /// YCrYCb.
    E_MI_CAP_INPUT_FMT_YUV422 = 0,
    /// YUV420
    E_MI_CAP_INPUT_FMT_YUV420,
    /// RGB domain
    E_MI_CAP_INPUT_FMT_RGB565,
    /// RGB domain
    E_MI_CAP_INPUT_FMT_ARGB8888,
        /// YUV420_H265
    E_MI_CAP_INPUT_FMT_YUV420_H265,
    /// YUV420_H265_10bits
    E_MI_CAP_INPUT_FMT_YUV420_H265_10BITS,

    E_MI_CAP_INPUT_FMT_MAX
} MI_CAP_InputFmt_e;

typedef enum
{
    /// Event for capture done.
    E_MI_CAP_EVENT_FRAME_CAPTURED = MI_BIT(0),
    E_MI_CAP_EVENT_MAX = 0xffUL
} MI_CAP_Event_e;

typedef enum
{
    E_MI_CAP_FRAME_TILE_BLOCK_NONE  = 0x0,
    E_MI_CAP_FRAME_TILE_BLOCK_16X16 = 0x1,
    E_MI_CAP_FRAME_TILE_BLOCK_16X32 = 0x2,
    E_MI_CAP_FRAME_TILE_BLOCK_32X16 = 0x3,
    E_MI_CAP_FRAME_TILE_BLOCK_32X32 = 0x4,
    E_MI_CAP_FRAME_TILE_BLOCK_MAX,
} MI_CAP_FrameTileBlock_e;

typedef enum
{
    //one top field in one address
    E_MI_CAP_DIP_3DDI_TOP_SINGLE_FIELD,
    //one bottom field in one address
    E_MI_CAP_DIP_3DDI_BOTTOM_SINGLE_FIELD,
    //stagger Both field in one address, keep top field
    E_MI_CAP_DIP_3DDI_TOP_BOTH_FIELD_STAGGER,
    //stagger Both field in one address, keep bottom field
    E_MI_CAP_DIP_3DDI_BOTTOM_BOTH_FIELD_STAGGER,
    //stagger Both field in one address, DIP 2.5D DI top field
    E_MI_CAP_DIP_MED_DI_TOP_BOTH_FIELD_STAGGER,
    //stagger Both field in one address, DIP 2.5D DI bottom field
    E_MI_CAP_DIP_MED_DI_BOTTOM_BOTH_FIELD_STAGGER,
    //two field in two address, DI top field
    E_MI_CAP_DIP_MED_DI_TOP_BOTH_FIELD_SEPARATE,
    //two field in two address, DI bottom field
    E_MI_CAP_DIP_MED_DI_BOTTOM_BOTH_FIELD_SEPARATE,
} MI_CAP_DipDiField_e;

typedef enum
{
    E_MI_CAP_DIP_DI_FIELD_NONE,
    E_MI_CAP_DIP_DI_FIELD_TOP_FIRST,
    E_MI_CAP_DIP_DI_FIELD_BOTTOM_FIRST,
} MI_CAP_DipDiFirstField_e;

typedef enum
{
    E_MI_CAP_SCAN_TYPE_PROGRESSIVE = 0,  //Indicate this frame info contain a progressive frame.
    E_MI_CAP_SCAN_TYPE_INTERLACE_FRAME, //Indicate this frame info contain a interlace frame
    E_MI_CAP_SCAN_TYPE_INTERLACE_FIELD,  //Indicate this frame info contain a interlace field
    E_MI_CAP_SCAN_TYPE_MAX,
}MI_CAP_ScanType_e;

typedef enum
{
    ///< no field
    E_MI_CAP_FIELD_TYPE_NONE,
    ///< top field only
    E_MI_CAP_FIELD_TYPE_TOP,
    ///< bottom field only
    E_MI_CAP_FIELD_TYPE_BOTTOM,
    ///< both field
    E_MI_CAP_FIELD_TYPE_BOTH,
    E_MI_CAP_FIELD_TYPE_MAX,
}MI_CAP_FieldType_e;

/// CAP init parameter
typedef struct MI_CAP_InitParams_s
{
    ///Reserved
    MI_U8 u8Reserved;

} MI_CAP_InitParams_t;

//Structure for E_MI_CAP_EVENT_FRAME_CAPTURED callback
typedef struct MI_CAP_FrameCapture_s
{
    /// Current Buf Index
    MI_U32 u32BufIndex;
    /// index 0:Y Base address of YUV420, or base address of other format
    /// index 1:C Base address of YUV420, 0 if non-YUV420 format
    MI_PHY aphyYcAddr[2];

} MI_CAP_FrameCapture_t;

typedef struct
{
    /// Total Buf Cnt
    MI_U8 u8BufCnt;
    /// Handle owner of this event
    MI_HANDLE hCap;
    /// Info of capture frame
    MI_CAP_FrameCapture_t stFrameCapture;
} MI_CAP_EventParams_t;

typedef MI_RESULT (* MI_CAP_EventCallback)(MI_HANDLE hCap, MI_U32 u32EventFlags, void *pEventParams, void *pUserParams);

typedef struct MI_CAP_Rect_s
{
    MI_U32 u32X;
    MI_U32 u32Y;
    MI_U32 u32Width;
    MI_U32 u32Height;
} MI_CAP_Rect_t;

typedef struct MI_CAP_OutBufInfo_s
{
    MI_VIRT virtOutAddr;
    // output buffer size, pitch * buffer_height * buffer_count
    MI_U32 u32OutSize;
    // output buffer width
    MI_U32 u32OutWidth;
    // output buffer height
    MI_U32 u32OutHeight;
    MI_U32 u32OutFrameRate;
    MI_CAP_OutputFmt_e eOutFmt;
    MI_S32 s32QueueId;
    MI_U32 u32OutPitch;
    MI_PHY phyOutAddr;
    MI_CAP_Rect_t stOutRect;
} MI_CAP_OutBufInfo_t;

typedef struct MI_CAP_MfDecInfo_s
{
    MI_BOOL bEnableMfDec;
    MI_U8 u8MfDecSelect;
    MI_BOOL bHMirror;
    MI_BOOL bVMirror;
    MI_CAP_FrameTileBlock_e eTileBlock;
    MI_BOOL bUncompressMode;
    MI_BOOL bBypassCodecMode;
    MI_U8  u8Mode; //0: H26X Mode, 1:VP9 Mode
    MI_U16 u16Pitch;
    MI_U16 u16X;
    MI_U16 u16Y;
    MI_U16 u16Width;
    MI_U16 u16Height;
    MI_PHY phyBitlenBase;
    MI_U16 u16BitlenPitch;
    MI_PHY phyHtlbEntriesAddr;
    MI_U8  u8HtlbEntriesSize;
    MI_U8  u8HtlbTableId;
} MI_CAP_MfDecInfo_t;

typedef struct MI_CAP_DiSetting_s
{
    MI_BOOL bEnableDi;
    MI_CAP_DipDiField_e eDiField;
    MI_PHY phyBotYBufAddr;
    MI_PHY phyBotCBufAddr;
    MI_PHY phyBotYBufAddr10Bits;
    MI_PHY phyBotCBufAddr10Bits;
    MI_CAP_DipDiFirstField_e eDiFirstField;
} MI_CAP_DiSetting_t;

typedef struct MI_CAP_DecInfoEx_s
{
    MI_CAP_DiSetting_t stDiSetting;
    MI_CAP_MfDecInfo_t stMfDecInfo;
} MI_CAP_DecInfoEx_t;

typedef struct MI_CAP_DramFrameInfo_s
{
    union
    {
        // Indicate Dram frame address. (Not 420 format used)
        MI_PHY phyFrameAddr;
        // index 0:Y address, index 1:C address
        MI_PHY aphyYcAddr[2];
    };
    // Check frame size is legal.
    MI_U32 u32Size;
    // Dram frame Width.
    MI_U32 u32Width;
    // Dram frame Height.
    MI_U32 u32Height;
    // Dram frame Pitch.
    MI_U32 u32Pitch;
    // Dram frame format.
    MI_CAP_InputFmt_e eInputFmt;
    // Dram frame tile block size
    MI_CAP_FrameTileBlock_e eTileBlock;
    // Dram frame is interlace
    MI_BOOL bInterlace;
    MI_CAP_ScanType_e eScanType;
    MI_CAP_FieldType_e eFieldType;
    MI_CAP_DecInfoEx_t stDecInfoEx;
} MI_CAP_DramFrameInfo_t;

typedef struct MI_CAP_DispInfo_s
{
    MI_CAP_DispPathSrc_e eDispPathSrc;
    MI_BOOL bCapOsd;
} MI_CAP_DispInfo_t;

typedef struct MI_CAP_VideoInfo_s
{
    MI_U8 u8Reserved;
} MI_CAP_VideoInfo_t;

typedef struct MI_CAP_CaptureParams_s
{
    union
    {
        // For capture from DRAM to set DRAM info
        MI_CAP_DramFrameInfo_t stInputBufInfo;
        // For connected disp handle to set disp info
        MI_CAP_DispInfo_t stDispInfo;
        // For connected video handle to set video info
        MI_CAP_VideoInfo_t stVideoInfo;
    };
    MI_CAP_Rect_t stCropRect;
    MI_CAP_OutBufInfo_t stOutBuf;

} MI_CAP_CaptureParams_t;

typedef struct MI_CAP_CallbackInputParams_s
{
    ///[IN]: for multi-callback, use 0 for first register or single callback.
    MI_U64 u64CallbackId;
    /// Callback function pointer.
    MI_CAP_EventCallback pfEventCallback;
    /// Event flags defined by MI_CAP_Event_e
    MI_U32 u32EventFlags;
    /// User parameter
    void *pUserParams;
} MI_CAP_CallbackInputParams_t;

typedef struct MI_CAP_CallbackOutputParams_s
{
    ///[OUT]: the returned ID for update or unregister callback.
    MI_U64 u64CallbackId;
} MI_CAP_CallbackOutputParams_t;

/// CAP connect input HW IP parameters
typedef struct MI_CAP_ConnectInputParams_s
{
    MI_U8 u8Reserved;
}MI_CAP_ConnectInputParams_t;

typedef struct MI_CAP_ConnectedConds_s
{
    MI_BOOL bIsInput;
    MI_U32 u32Module;

    //if need other conditions add here
} MI_CAP_ConnectedConds_t;

typedef struct MI_CAP_OpenParams_s
{
    MI_U8 u8Reserved;
}MI_CAP_OpenParams_t;

typedef struct MI_CAP_DumpInfoParams_s
{
    MI_U8 u8Reserved;
}MI_CAP_DumpInfoParams_t;
//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Init capture module.
/// @return MI_OK: Process success.
/// @return MI_ERR_RESOURCES: get resource fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_Init(const MI_CAP_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Finalize capture module.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Open a Capture handle.
/// @param[in] MI_CAP_OpenParams_t: Open parameters of CAP
/// @param[out] phCap: A handle pointer to retrieve an instance of a created Capture interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not initialized.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_Open(const MI_CAP_OpenParams_t *pstOpenParams, MI_HANDLE *phCap);

//------------------------------------------------------------------------------
/// @brief Close a capture handle.
/// @param[in] hCap: An instance of a created capture interface.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_Close(MI_HANDLE hCap);

//------------------------------------------------------------------------------
/// @brief Capture one frame of screen
/// @param[in] hCap: Handler of Cap
/// @param[in] pstCaptureParams: Capture info
/// @param[out] pstBufInfo: Capture frame info (used by MI CAP manage memory.)
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_CaptureOne(MI_HANDLE hCap, const MI_CAP_CaptureParams_t *pstCaptureParams, MI_CAP_FrameCapture_t *pstBufInfo);

//------------------------------------------------------------------------------
/// @brief Capture frames of screen continuously
/// @param[in] hCap: Handler of Cap
/// @param[in] pstCaptureParams: Capture info, need assign parameter of stOutBuf
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_BUSY: Capture is busy.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_CaptureStart(MI_HANDLE hCap, const MI_CAP_CaptureParams_t *pstCaptureParams);

//------------------------------------------------------------------------------
/// @brief Stop Capture frames continuously
/// @param[in] hCap: Handler of Cap
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_RESOURCES: Cap without started.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_CaptureStop(MI_HANDLE hCap);

//------------------------------------------------------------------------------
/// @brief Show still image before zapping
/// @param[in] hCap: Handler of Cap
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_ShowStillImage(MI_HANDLE hCap);

//------------------------------------------------------------------------------
/// @brief Hide still image after zapping is done
/// @param[in] hCap: Handler of Cap
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_HideStillImage(MI_HANDLE hCap);

//------------------------------------------------------------------------------
/// @brief get status of capture module
/// @param[in] hCap: Handler of Cap
/// @param[out] peStatus: status of Cap module
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_GetStatus(MI_HANDLE hCap, MI_CAP_Status_e *peStatus);

//------------------------------------------------------------------------------
/// @brief register callback
/// @param[in] hCap: Handler of Cap
/// @param[in] pstInputParams: callback parameters.
/// @param[in] pstOutputParams: callback parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_RegisterCallback( MI_HANDLE hCap, const MI_CAP_CallbackInputParams_t *pstInputParams, MI_CAP_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief unregister callback
/// @param[in] hCap: Handler of Cap
/// @param[in] pstInputParams: callback parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_UnRegisterCallback( MI_HANDLE hCap, const MI_CAP_CallbackInputParams_t *pstInputParams);

//------------------------------------------------------------------------------
/// @brief Notify MI_CAP captured buffer processing done.
/// @param[in] hCap: Handler of Cap
/// @param[in] u32BufIndex: captured buffer index from MI_CAP callback function.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Handle is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_ProcessBufDone( MI_HANDLE hCap, MI_U32 u32BufIndex );

//------------------------------------------------------------------------------
/// @brief Connect Cap input module.
/// @param[in]  hCap: Handler of Cap
/// @param[in]  hInput: input module handle
/// @param[in]  pstParams: Connect parameters.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_IMPLEMENT: Not implement functions.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_ConnectInput(MI_HANDLE hCap, MI_HANDLE hInput, const MI_CAP_ConnectInputParams_t *pstParams);

//------------------------------------------------------------------------------
/// @brief Disconnect Cap input module.
/// @param[in]  hCap: Handler of Cap
/// @param[in]  hInput: input module handle
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_DisconnectInput(MI_HANDLE hCap, MI_HANDLE hInput);

//------------------------------------------------------------------------------
/// @brief Get the number of elements which are connected to the specified element.
/// @param[in]  hDisp: Handler of Cap
/// @param[in]  pstDispConds: bIsinput - The direction for finding the connected module.
///                           u32ModuleType - The module type of connected with CAP. It defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                           If it is MI_MODULE_TYPE_NONE it find all type of connected modules.
///                                           e.g. MI_CAP_GetConnectedNum(hCap, TRUE, MI_MODULE_TYPE_DISP, pu32ConnectedNum)
/// @param[out] pu32ConnectedNum: The number of connected handle
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_GetConnectedNum(const MI_HANDLE hCap, const MI_CAP_ConnectedConds_t *pstCapConds, MI_U32 *pu32ConnectedNum);

//------------------------------------------------------------------------------
/// @brief Get the elements which are connected to the specified element.
/// @param[in]  hCap: Handler of Cap
/// @param[in]  pstDispConds: bIsinput - The direction for finding the connected module.
///                           u32ModuleType - The module type of connected with CAP. It defined in mi_common.h with prefix MI_MODULE_TYPE_XXX.
///                                           If it is MI_MODULE_TYPE_NONE it find all type of connected module.
///                                           e.g. MI_CAP_GetConnected(hCap, TRUE, MI_MODULE_TYPE_DISP, u32ConnectedNum, phConnectedArray)
/// @param[in]  u32ConnectedNum: The number of get handle
/// @param[out] phConnectedArray: Pointer to handle buffer to retrieve the handle of MI module which is connected to the specified element with the specified direction.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail, no connection is available.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_GetConnected(const MI_HANDLE hCap, const MI_CAP_ConnectedConds_t *pstCapConds, const MI_U32 u32ConnectedNum, MI_HANDLE *phConnectedArray);

//------------------------------------------------------------------------------
/// @brief Dump CAP Info.
/// @param[in] pstDumpInfoParams : Dump info parameters
/// @return MI_OK: Dump information success.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_DumpInfo(const MI_CAP_DumpInfoParams_t *pstDumpInfoParams);

//------------------------------------------------------------------------------
/// @brief Set CAP modul debug level.
/// @param[in] u32DebugLevel.
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_CAP_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);


#ifdef __cplusplus
}
#endif

#endif///_MI_TEMPLETE_H_

