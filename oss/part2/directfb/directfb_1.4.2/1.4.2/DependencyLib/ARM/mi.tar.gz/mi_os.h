/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_OS_H_
#define _MI_OS_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
#define MI_OS_TICK_PER_ONE_MS                           (1)
#define MI_OS_WAIT_FOREVER                              (0xffffff00/MI_OS_TICK_PER_ONE_MS)
#define MI_OS_PROCESS_PRIVATE                           (0x00000000)
#define MI_OS_PROCESS_SHARED                            (0x00000001)
#define MI_OS_IRQ_MAX                                   (128) //64 IRQs + 64 FIQs
#define MI_OS_ECOS_MAX_PRIORITY_LEVEL                   (31)
#define MI_OS_ECOS_MIN_PRIORITY_LEVEL                   (0)
#define MI_OS_SHARE_MEMORY_NAME_LEN_MAX                 (256)

typedef void (*MI_OS_TaskEntry)(void * pTaskEntryData);

typedef void (*MI_OS_TimerCallback)(MI_U32 u32StTimer, MI_U32 u32TimerId);  ///< Timer callback function  u32StTimer: not used; u32TimerId: Timer ID

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum MI_OS_TaskPriority_s
{
    E_MI_OS_TASK_PRI_INVALID = -1,
    E_MI_OS_TASK_PRI_MIN = 0,

    E_MI_OS_TASK_PRI_SYS = E_MI_OS_TASK_PRI_MIN,        ///< System priority task   ( interrupt level driver, e.g. TSP, SMART )
    E_MI_OS_TASK_PRI_HIGHEST,                           ///< Highest priority task  ( background monitor driver, e.g. DVBC, HDMI )
    E_MI_OS_TASK_PRI_HIGH,                              ///< High priority task     ( service task )
    E_MI_OS_TASK_PRI_MEDIUM,                            ///< Medium priority task   ( application task )
    E_MI_OS_TASK_PRI_LOW,                               ///< Low priority task      ( nonbusy application task )
    E_MI_OS_TASK_PRI_LOWEST,                            ///< Lowest priority task   ( idle application task )

    E_MI_OS_TASK_PRI_MAX,
} MI_OS_TaskPriority_e;

typedef enum MI_OS_Attribute_s
{
    E_MI_OS_ATTRIBUTE_INVALID = -1,
    E_MI_OS_ATTRIBUTE_MIN = 0,

    E_MI_OS_ATTRIBUTE_PRIORITY = E_MI_OS_ATTRIBUTE_MIN, ///< Priority-order suspension
    E_MI_OS_ATTRIBUTE_FIFO,                             ///< FIFO-order suspension

    E_MI_OS_ATTRIBUTE_MAX,
} MI_OS_Attribute_e;

typedef enum MI_OS_EventWaitMode_s
{
    E_MI_OS_EVENT_WAIT_MODE_INVALID = -1,
    E_MI_OS_EVENT_WAIT_MODE_MIN = 0,

    E_MI_OS_EVENT_WAIT_MODE_AND = E_MI_OS_EVENT_WAIT_MODE_MIN,  ///< Specify all of the requested events are require.
    E_MI_OS_EVENT_WAIT_MODE_OR,                                 ///< Specify any of the requested events are require.
    E_MI_OS_EVENT_WAIT_MODE_AND_CLEAR,                          ///< Specify all of the requested events are require. If the request are successful, clear the event.
    E_MI_OS_EVENT_WAIT_MODE_OR_CLEAR,                           ///< Specify any of the requested events are require. If the request are successful, clear the event.

    E_MI_OS_EVENT_WAIT_MODE_MAX,
} MI_OS_EventWaitMode_e;

typedef enum MI_OS_MessageType_s
{
    E_MI_OS_MESSAGE_TYPE_INVALID = -1,
    E_MI_OS_MESSAGE_TYPE_MIN = 0,

    E_MI_OS_MESSAGE_TYPE_FIXED_SIZE = E_MI_OS_MESSAGE_TYPE_MIN, ///< Fixed size message
    E_MI_OS_MESSAGE_TYPE_VAR_SIZE,                              ///< Variable size message

    E_MI_OS_MESSAGE_TYPE_MAX,
} MI_OS_MessageType_e;

typedef enum MI_OS_IrqDebugOpt_s
{
    E_MI_OS_IRQ_DEBUG_OPT_DISABLE = 0 << 0,             ///< reserve for MI_OS_DisableInterrupt
    E_MI_OS_IRQ_DEBUG_OPT_ENABLE = MI_BIT(0),           ///< reserve for MI_OS_EnableInterrupt
    E_MI_OS_IRQ_DEBUG_OPT_ACK = MI_BIT(1),
    E_MI_OS_IRQ_DEBUG_OPT_DEBUG_STATUS_FLOW = MI_BIT(2),
    E_MI_OS_IRQ_DEBIG_OPT_DEBUG_DISABLE = MI_BIT(31),
} MI_OS_IrqDebugOpt_e;

typedef enum
{
    E_MI_OS_INT_IRQ_INVALID                             = -1,
    E_MI_OS_INT_IRQ_MIN                                 = 0,

    // IRQ
    E_MI_OS_INT_IRQ_0X00_MIN                            = E_MI_OS_INT_IRQ_MIN,
    E_MI_OS_INT_IRQ_UART0                               = E_MI_OS_INT_IRQ_0X00_MIN + 0,
    E_MI_OS_INT_IRQ_BDMA_CH0                            = E_MI_OS_INT_IRQ_0X00_MIN + 1,
    E_MI_OS_INT_IRQ_BDMA_CH1                            = E_MI_OS_INT_IRQ_0X00_MIN + 2,
    E_MI_OS_INT_IRQ_MVD                                 = E_MI_OS_INT_IRQ_0X00_MIN + 3,
    E_MI_OS_INT_IRQ_PS                                  = E_MI_OS_INT_IRQ_0X00_MIN + 4,
    E_MI_OS_INT_IRQ_NFIE                                = E_MI_OS_INT_IRQ_0X00_MIN + 5,
    E_MI_OS_INT_IRQ_USB                                 = E_MI_OS_INT_IRQ_0X00_MIN + 6,
    E_MI_OS_INT_IRQ_UHC                                 = E_MI_OS_INT_IRQ_0X00_MIN + 7,
    E_MI_OS_INT_IRQ_EC_BRIDGE                           = E_MI_OS_INT_IRQ_0X00_MIN + 8,
    E_MI_OS_INT_IRQ_EMAC                                = E_MI_OS_INT_IRQ_0X00_MIN + 9,
    E_MI_OS_INT_IRQ_DISP                                = E_MI_OS_INT_IRQ_0X00_MIN + 10,
    E_MI_OS_INT_IRQ_DHC                                 = E_MI_OS_INT_IRQ_0X00_MIN + 11,
    E_MI_OS_INT_IRQ_PMSLEEP                             = E_MI_OS_INT_IRQ_0X00_MIN + 12,
    E_MI_OS_INT_IRQ_SBM                                 = E_MI_OS_INT_IRQ_0X00_MIN + 13,
    E_MI_OS_INT_IRQ_COMB                                = E_MI_OS_INT_IRQ_0X00_MIN + 14,
    E_MI_OS_INT_IRQ_ECC_DERR                            = E_MI_OS_INT_IRQ_0X00_MIN + 15,
    E_MI_OS_INT_IRQ_0X00_MAX                            = 0x0F,

    E_MI_OS_INT_IRQ_0X10_MIN                            = 0x10,
    E_MI_OS_INT_IRQ_TSP2HK                              = E_MI_OS_INT_IRQ_0X10_MIN + 0,
    E_MI_OS_INT_IRQ_VE                                  = E_MI_OS_INT_IRQ_0X10_MIN + 1,
    E_MI_OS_INT_IRQ_CIMAX2MCU                           = E_MI_OS_INT_IRQ_0X10_MIN + 2,
    E_MI_OS_INT_IRQ_DC                                  = E_MI_OS_INT_IRQ_0X10_MIN + 3,
    E_MI_OS_INT_IRQ_GOP                                 = E_MI_OS_INT_IRQ_0X10_MIN + 4,
    E_MI_OS_INT_IRQ_PCM                                 = E_MI_OS_INT_IRQ_0X10_MIN + 5,
    E_MI_OS_INT_IRQ_IIC0                                = E_MI_OS_INT_IRQ_0X10_MIN + 6,
    E_MI_OS_INT_IRQ_RTC                                 = E_MI_OS_INT_IRQ_0X10_MIN + 7,
    E_MI_OS_INT_IRQ_KEYPAD                              = E_MI_OS_INT_IRQ_0X10_MIN + 8,
    E_MI_OS_INT_IRQ_PM                                  = E_MI_OS_INT_IRQ_0X10_MIN + 9,
    E_MI_OS_INT_IRQ_DDC2BI                              = E_MI_OS_INT_IRQ_0X10_MIN + 10,
    E_MI_OS_INT_IRQ_SCM                                 = E_MI_OS_INT_IRQ_0X10_MIN + 11,
    E_MI_OS_INT_IRQ_VBI                                 = E_MI_OS_INT_IRQ_0X10_MIN + 12,
    E_MI_OS_INT_IRQ_M4VD                                = E_MI_OS_INT_IRQ_0X10_MIN + 13,
    E_MI_OS_INT_IRQ_FCIE2RIU                            = E_MI_OS_INT_IRQ_0X10_MIN + 14,
    E_MI_OS_INT_IRQ_ADCDVI2RIU                          = E_MI_OS_INT_IRQ_0X10_MIN + 15,
    E_MI_OS_INT_IRQ_0X10_MAX                            = 0x1F,

    // FIQ
    E_MI_OS_INT_FIQ_0X20_MIN                            = 0x20,
    E_MI_OS_INT_FIQ_EXTIMER0                            = E_MI_OS_INT_FIQ_0X20_MIN + 0,
    E_MI_OS_INT_FIQ_EXTIMER1                            = E_MI_OS_INT_FIQ_0X20_MIN + 1,
    E_MI_OS_INT_FIQ_WDT                                 = E_MI_OS_INT_FIQ_0X20_MIN + 2,
    E_MI_OS_INT_FIQ_AEON_TO_8051                        = E_MI_OS_INT_FIQ_0X20_MIN + 3,
    E_MI_OS_INT_FIQ_8051_TO_AEON                        = E_MI_OS_INT_FIQ_0X20_MIN + 4,
    E_MI_OS_INT_FIQ_8051_TO_BEON                        = E_MI_OS_INT_FIQ_0X20_MIN + 5,
    E_MI_OS_INT_FIQ_BEON_TO_8051                        = E_MI_OS_INT_FIQ_0X20_MIN + 6,
    E_MI_OS_INT_FIQ_BEON_TO_AEON                        = E_MI_OS_INT_FIQ_0X20_MIN + 7,
    E_MI_OS_INT_FIQ_AEON_TO_BEON                        = E_MI_OS_INT_FIQ_0X20_MIN + 8,
    E_MI_OS_INT_FIQ_JPD                                 = E_MI_OS_INT_FIQ_0X20_MIN + 9,
    E_MI_OS_INT_FIQ_MENULOAD                            = E_MI_OS_INT_FIQ_0X20_MIN + 10,
    E_MI_OS_INT_FIQ_HDMI_NON_PCM                        = E_MI_OS_INT_FIQ_0X20_MIN + 11,
    E_MI_OS_INT_FIQ_SPDIF_IN_NON_PCM                    = E_MI_OS_INT_FIQ_0X20_MIN + 12,
    E_MI_OS_INT_FIQ_EMAC                                = E_MI_OS_INT_FIQ_0X20_MIN + 13,
    E_MI_OS_INT_FIQ_SE_DSP2UP                           = E_MI_OS_INT_FIQ_0X20_MIN + 14,
    E_MI_OS_INT_FIQ_TSP2AEON                            = E_MI_OS_INT_FIQ_0X20_MIN + 15,
    E_MI_OS_INT_FIQ_0X20_MAX                            = 0x2F,

    E_MI_OS_INT_FIQ_0X30_MIN                            = 0x30,
    E_MI_OS_INT_FIQ_VIVALDI_STR                         = E_MI_OS_INT_FIQ_0X30_MIN + 0,
    E_MI_OS_INT_FIQ_VIVALDI_PTS                         = E_MI_OS_INT_FIQ_0X30_MIN + 1,
    E_MI_OS_INT_FIQ_DSP_MIU_PROT                        = E_MI_OS_INT_FIQ_0X30_MIN + 2,
    E_MI_OS_INT_FIQ_XIU_TIMEOUT                         = E_MI_OS_INT_FIQ_0X30_MIN + 3,
    E_MI_OS_INT_FIQ_DMA_DONE                            = E_MI_OS_INT_FIQ_0X30_MIN + 4,
    E_MI_OS_INT_FIQ_VSYNC_VE4VBI                        = E_MI_OS_INT_FIQ_0X30_MIN + 5,
    E_MI_OS_INT_FIQ_FIELD_VE4VBI                        = E_MI_OS_INT_FIQ_0X30_MIN + 6,
    E_MI_OS_INT_FIQ_VDMCU2HK                            = E_MI_OS_INT_FIQ_0X30_MIN + 7,
    E_MI_OS_INT_FIQ_VE_DONE_TT                          = E_MI_OS_INT_FIQ_0X30_MIN + 8,
    E_MI_OS_INT_FIQ_INT_CCFL                            = E_MI_OS_INT_FIQ_0X30_MIN + 9,
    E_MI_OS_INT_FIQ_INT                                 = E_MI_OS_INT_FIQ_0X30_MIN + 10,
    E_MI_OS_INT_FIQ_IR                                  = E_MI_OS_INT_FIQ_0X30_MIN + 11,
    E_MI_OS_INT_FIQ_AFEC_VSYNC                          = E_MI_OS_INT_FIQ_0X30_MIN + 12,
    E_MI_OS_INT_FIQ_DEC_DSP2UP                          = E_MI_OS_INT_FIQ_0X30_MIN + 13,
    E_MI_OS_INT_FIQ_MIPS_WDT                            = E_MI_OS_INT_FIQ_0X30_MIN + 14,
    E_MI_OS_INT_FIQ_DEC_DSP2MIPS                        = E_MI_OS_INT_FIQ_0X30_MIN + 15,
    E_MI_OS_INT_FIQ_0X30_MAX                            = 0x3F,

    E_MI_OS_INT_IRQ_0X40_MIN                            = 0x40,
    E_MI_OS_INT_IRQ_SVD_HVD                             = E_MI_OS_INT_IRQ_0X40_MIN + 0,
    E_MI_OS_INT_IRQ_USB2                                = E_MI_OS_INT_IRQ_0X40_MIN + 1,
    E_MI_OS_INT_IRQ_UHC2                                = E_MI_OS_INT_IRQ_0X40_MIN + 2,
    E_MI_OS_INT_IRQ_MIU                                 = E_MI_OS_INT_IRQ_0X40_MIN + 3,
    E_MI_OS_INT_IRQ_GDMA                                = E_MI_OS_INT_IRQ_0X40_MIN + 4,
    E_MI_OS_INT_IRQ_UART2                               = E_MI_OS_INT_IRQ_0X40_MIN + 5,
    E_MI_OS_INT_IRQ_UART1                               = E_MI_OS_INT_IRQ_0X40_MIN + 6,
    E_MI_OS_INT_IRQ_DEMOD                               = E_MI_OS_INT_IRQ_0X40_MIN + 7,
    E_MI_OS_INT_IRQ_MPIF                                = E_MI_OS_INT_IRQ_0X40_MIN + 8,
    E_MI_OS_INT_IRQ_JPD                                 = E_MI_OS_INT_IRQ_0X40_MIN + 9,
    E_MI_OS_INT_IRQ_AEON2HI                             = E_MI_OS_INT_IRQ_0X40_MIN + 10,
    E_MI_OS_INT_IRQ_BDMA0                               = E_MI_OS_INT_IRQ_0X40_MIN + 11,
    E_MI_OS_INT_IRQ_BDMA1                               = E_MI_OS_INT_IRQ_0X40_MIN + 12,
    E_MI_OS_INT_IRQ_OTG                                 = E_MI_OS_INT_IRQ_0X40_MIN + 13,
    E_MI_OS_INT_IRQ_MVD_CHECKSUM_FAIL                   = E_MI_OS_INT_IRQ_0X40_MIN + 14,
    E_MI_OS_INT_IRQ_TSP_CHECKSUM_FAIL                   = E_MI_OS_INT_IRQ_0X40_MIN + 15,
    E_MI_OS_INT_IRQ_0X40_MAX                            = 0x4F,

    E_MI_OS_INT_IRQ_0X50_MIN                            = 0x50,
    E_MI_OS_INT_IRQ_CA_I3                               = E_MI_OS_INT_IRQ_0X50_MIN + 0,
    E_MI_OS_INT_IRQ_HDMI_LEVEL                          = E_MI_OS_INT_IRQ_0X50_MIN + 1,
    E_MI_OS_INT_IRQ_MIPS_WADR_ERR                       = E_MI_OS_INT_IRQ_0X50_MIN + 2,
    E_MI_OS_INT_IRQ_RASP                                = E_MI_OS_INT_IRQ_0X50_MIN + 3,
    E_MI_OS_INT_IRQ_CA_SVP                              = E_MI_OS_INT_IRQ_0X50_MIN + 4,
    E_MI_OS_INT_IRQ_UART2MCU                            = E_MI_OS_INT_IRQ_0X50_MIN + 5,
    E_MI_OS_INT_IRQ_URDMA2MCU                           = E_MI_OS_INT_IRQ_0X50_MIN + 6,
    E_MI_OS_INT_IRQ_IIC1                                = E_MI_OS_INT_IRQ_0X50_MIN + 7,
    E_MI_OS_INT_IRQ_HDCP                                = E_MI_OS_INT_IRQ_0X50_MIN + 8,
    E_MI_OS_INT_IRQ_DMA_WADR_ERR                        = E_MI_OS_INT_IRQ_0X50_MIN + 9,
    E_MI_OS_INT_IRQ_UP_IRQ_UART_CA                      = E_MI_OS_INT_IRQ_0X50_MIN + 10,
    E_MI_OS_INT_IRQ_UP_IRQ_EMM_ECM                      = E_MI_OS_INT_IRQ_0X50_MIN + 11,
    E_MI_OS_INT_IRQ_ONIF                                = E_MI_OS_INT_IRQ_0X50_MIN + 12,
    E_MI_OS_INT_IRQ_USB1                                = E_MI_OS_INT_IRQ_0X50_MIN + 13,
    E_MI_OS_INT_IRQ_UHC1                                = E_MI_OS_INT_IRQ_0X50_MIN + 14,
    E_MI_OS_INT_IRQ_MFE                                 = E_MI_OS_INT_IRQ_0X50_MIN + 15,
    E_MI_OS_INT_IRQ_0X50_MAX                            = 0x5F,

    E_MI_OS_INT_FIQ_0X60_MIN                            = 0x60,
    E_MI_OS_INT_FIQ_IR_INT_RC                           = E_MI_OS_INT_FIQ_0X60_MIN + 0,
    E_MI_OS_INT_FIQ_HDMITX_IRQ_EDGE                     = E_MI_OS_INT_FIQ_0X60_MIN + 1,
    E_MI_OS_INT_FIQ_UP_IRQ_UART_CA                      = E_MI_OS_INT_FIQ_0X60_MIN + 2,
    E_MI_OS_INT_FIQ_UP_IRQ_EMM_ECM                      = E_MI_OS_INT_FIQ_0X60_MIN + 3,
    E_MI_OS_INT_FIQ_PVR2MI_INT0                         = E_MI_OS_INT_FIQ_0X60_MIN + 4,
    E_MI_OS_INT_FIQ_PVR2MI_INT1                         = E_MI_OS_INT_FIQ_0X60_MIN + 5,
    E_MI_OS_INT_IRQ_FIQ_INT                             = E_MI_OS_INT_FIQ_0X60_MIN + 6,
    E_MI_OS_INT_IRQ_UART3                               = E_MI_OS_INT_FIQ_0X60_MIN + 7,
    E_MI_OS_INT_FIQ_AEON_TO_MIPS_VPE0                   = E_MI_OS_INT_FIQ_0X60_MIN + 8,
    E_MI_OS_INT_FIQ_AEON_TO_MIPS_VPE1                   = E_MI_OS_INT_FIQ_0X60_MIN + 9,
    E_MI_OS_INT_FIQ_SECEMAC                             = E_MI_OS_INT_FIQ_0X60_MIN + 10,
    E_MI_OS_INT_FIQ_IR2_INT                             = E_MI_OS_INT_FIQ_0X60_MIN + 11,
    E_MI_OS_INT_FIQ_MIPS_VPE1_TO_MIPS_VPE0              = E_MI_OS_INT_FIQ_0X60_MIN + 12,
    E_MI_OS_INT_FIQ_MIPS_VPE1_TO_AEON                   = E_MI_OS_INT_FIQ_0X60_MIN + 13,
    E_MI_OS_INT_FIQ_MIPS_VPE1_TO_8051                   = E_MI_OS_INT_FIQ_0X60_MIN + 14,
    E_MI_OS_INT_FIQ_IR2_INT_RC                          = E_MI_OS_INT_FIQ_0X60_MIN + 15,
    E_MI_OS_INT_FIQ_0X60_MAX                            = 0x6F,

    E_MI_OS_INT_FIQ_0X70_MIN                            = 0x70,
    E_MI_OS_INT_FIQ_MIPS_VPE0_TO_MIPS_VPE1              = E_MI_OS_INT_FIQ_0X70_MIN + 0,
    E_MI_OS_INT_FIQ_MIPS_VPE0_TO_AEON                   = E_MI_OS_INT_FIQ_0X70_MIN + 1,
    E_MI_OS_INT_FIQ_MIPS_VPE0_TO_8051                   = E_MI_OS_INT_FIQ_0X70_MIN + 2,
    E_MI_OS_INT_FIQ_IR_IN                               = E_MI_OS_INT_FIQ_0X70_MIN + 3,
    E_MI_OS_INT_FIQ_DMDMCU2HK                           = E_MI_OS_INT_FIQ_0X70_MIN + 4,
    E_MI_OS_INT_FIQ_R2TOMCU_INT0                        = E_MI_OS_INT_FIQ_0X70_MIN + 5,
    E_MI_OS_INT_FIQ_R2TOMCU_INT1                        = E_MI_OS_INT_FIQ_0X70_MIN + 6,
    E_MI_OS_INT_FIQ_DSPTOMCU_INT0                       = E_MI_OS_INT_FIQ_0X70_MIN + 7,
    E_MI_OS_INT_FIQ_DSPTOMCU_INT1                       = E_MI_OS_INT_FIQ_0X70_MIN + 8,
    E_MI_OS_INT_FIQ_USB                                 = E_MI_OS_INT_FIQ_0X70_MIN + 9,
    E_MI_OS_INT_FIQ_UHC                                 = E_MI_OS_INT_FIQ_0X70_MIN + 10,
    E_MI_OS_INT_FIQ_USB1                                = E_MI_OS_INT_FIQ_0X70_MIN + 11,
    E_MI_OS_INT_FIQ_UHC1                                = E_MI_OS_INT_FIQ_0X70_MIN + 12,
    E_MI_OS_INT_FIQ_USB2                                = E_MI_OS_INT_FIQ_0X70_MIN + 13,
    E_MI_OS_INT_FIQ_UHC2                                = E_MI_OS_INT_FIQ_0X70_MIN + 14,
    //Not Used                                          = E_MI_OS_INT_FIQ_0X70_MIN + 15,
    E_MI_OS_INT_FIQ_0X70_MAX                            = 0x7F,

    // Add IRQ from 0x80 ~ 0xBF,
    // if IRQ enum from 0x00 ~ 0x1F, and 0x40 ~ 0x5F is occupied
    E_MI_OS_INT_IRQ_0X80_MIN                            = 0x80,
    E_MI_OS_INT_IRQ_MLINK                               = E_MI_OS_INT_IRQ_0X80_MIN + 0,
    E_MI_OS_INT_IRQ_AFEC                                = E_MI_OS_INT_IRQ_0X80_MIN + 1,
    E_MI_OS_INT_IRQ_DPTX                                = E_MI_OS_INT_IRQ_0X80_MIN + 2,
    E_MI_OS_INT_IRQ_TMDDRLINK                           = E_MI_OS_INT_IRQ_0X80_MIN + 3,
    E_MI_OS_INT_IRQ_DISPI                               = E_MI_OS_INT_IRQ_0X80_MIN + 4,
    E_MI_OS_INT_IRQ_EXP_MLINK                           = E_MI_OS_INT_IRQ_0X80_MIN + 5,
    E_MI_OS_INT_IRQ_M4VE                                = E_MI_OS_INT_IRQ_0X80_MIN + 6,
    E_MI_OS_INT_IRQ_DVI_HDMI_HDCP                       = E_MI_OS_INT_IRQ_0X80_MIN + 7,
    E_MI_OS_INT_IRQ_G3D2MCU                             = E_MI_OS_INT_IRQ_0X80_MIN + 8,
    E_MI_OS_INT_IRQ_VP6                                 = E_MI_OS_INT_IRQ_0X80_MIN + 9,
    E_MI_OS_INT_IRQ_INT                                 = E_MI_OS_INT_IRQ_0X80_MIN + 10,
    E_MI_OS_INT_IRQ_CEC                                 = E_MI_OS_INT_IRQ_0X80_MIN + 11,
    E_MI_OS_INT_IRQ_HDCP_IIC                            = E_MI_OS_INT_IRQ_0X80_MIN + 12,
    E_MI_OS_INT_IRQ_HDCP_X74                            = E_MI_OS_INT_IRQ_0X80_MIN + 13,
    E_MI_OS_INT_IRQ_WADR_ERR                            = E_MI_OS_INT_IRQ_0X80_MIN + 14,
    E_MI_OS_INT_IRQ_DCSUB                               = E_MI_OS_INT_IRQ_0X80_MIN + 15,
    E_MI_OS_INT_IRQ_0X80_MAX                            = 0x8F,

    E_MI_OS_INT_IRQ_0X90_MIN                            = 0x90,
    E_MI_OS_INT_IRQ_GE                                  = E_MI_OS_INT_IRQ_0X90_MIN + 0,
    E_MI_OS_INT_IRQ_SYNC_DET                            = E_MI_OS_INT_IRQ_0X90_MIN + 1,
    E_MI_OS_INT_IRQ_FSP                                 = E_MI_OS_INT_IRQ_0X90_MIN + 2,
    E_MI_OS_INT_IRQ_PWM_RP_L                            = E_MI_OS_INT_IRQ_0X90_MIN + 3,
    E_MI_OS_INT_IRQ_PWM_FP_L                            = E_MI_OS_INT_IRQ_0X90_MIN + 4,
    E_MI_OS_INT_IRQ_PWM_RP_R                            = E_MI_OS_INT_IRQ_0X90_MIN + 5,
    E_MI_OS_INT_IRQ_PWM_FP_R                            = E_MI_OS_INT_IRQ_0X90_MIN + 6,
    E_MI_OS_INT_IRQ_FRC_SC                              = E_MI_OS_INT_IRQ_0X90_MIN + 7,
    E_MI_OS_INT_IRQ_FRC_INT_FIQ2HST0                    = E_MI_OS_INT_IRQ_0X90_MIN + 8,
    E_MI_OS_INT_IRQ_SMART                               = E_MI_OS_INT_IRQ_0X90_MIN + 9,
    E_MI_OS_INT_IRQ_MVD2MIPS                            = E_MI_OS_INT_IRQ_0X90_MIN + 10,
    E_MI_OS_INT_IRQ_GPD                                 = E_MI_OS_INT_IRQ_0X90_MIN + 11,
    E_MI_OS_INT_IRQ_DS                                  = E_MI_OS_INT_IRQ_0X90_MIN + 12,
    E_MI_OS_INT_IRQ_FRC_INT_IRQ2HST0                    = E_MI_OS_INT_IRQ_0X90_MIN + 13,
    E_MI_OS_INT_IRQ_MIIC_DMA_INT3                       = E_MI_OS_INT_IRQ_0X90_MIN + 14,
    E_MI_OS_INT_IRQ_MIIC_INT3                           = E_MI_OS_INT_IRQ_0X90_MIN + 15,
    E_MI_OS_INT_IRQ_0X90_MAX                            = 0x9F,

    E_MI_OS_INT_IRQ_0XA0_MIN                            = 0xA0,
    E_MI_OS_INT_IRQ_IIC2                                = E_MI_OS_INT_IRQ_0XA0_MIN + 0,
    E_MI_OS_INT_IRQ_MIIC_DMA0                           = E_MI_OS_INT_IRQ_0XA0_MIN + 1,
    E_MI_OS_INT_IRQ_MIIC_DMA1                           = E_MI_OS_INT_IRQ_0XA0_MIN + 2,
    E_MI_OS_INT_IRQ_MIIC_DMA2                           = E_MI_OS_INT_IRQ_0XA0_MIN + 3,
    E_MI_OS_INT_IRQ_MSPI0                               = E_MI_OS_INT_IRQ_0XA0_MIN + 4,
    E_MI_OS_INT_IRQ_MSPI1                               = E_MI_OS_INT_IRQ_0XA0_MIN + 5,
    E_MI_OS_INT_IRQ_EXT_GPIO0                           = E_MI_OS_INT_IRQ_0XA0_MIN + 6,
    E_MI_OS_INT_IRQ_EXT_GPIO1                           = E_MI_OS_INT_IRQ_0XA0_MIN + 7,
    E_MI_OS_INT_IRQ_EXT_GPIO2                           = E_MI_OS_INT_IRQ_0XA0_MIN + 8,
    E_MI_OS_INT_IRQ_EXT_GPIO3                           = E_MI_OS_INT_IRQ_0XA0_MIN + 9,
    E_MI_OS_INT_IRQ_EXT_GPIO4                           = E_MI_OS_INT_IRQ_0XA0_MIN + 10,
    E_MI_OS_INT_IRQ_EXT_GPIO5                           = E_MI_OS_INT_IRQ_0XA0_MIN + 11,
    E_MI_OS_INT_IRQ_EXT_GPIO6                           = E_MI_OS_INT_IRQ_0XA0_MIN + 12,
    E_MI_OS_INT_IRQ_EXT_GPIO7                           = E_MI_OS_INT_IRQ_0XA0_MIN + 13,
    E_MI_OS_INT_IRQ_MIIC_DMA_INT2                       = E_MI_OS_INT_IRQ_0XA0_MIN + 14,
    E_MI_OS_INT_IRQ_MIIC_INT2                           = E_MI_OS_INT_IRQ_0XA0_MIN + 15,
    E_MI_OS_INT_IRQ_0XA0_MAX                            = 0xAF,

    E_MI_OS_INT_IRQ_0XB0_MIN                            = 0xB0,
    E_MI_OS_INT_IRQ_MIIC_DMA_INT1                       = E_MI_OS_INT_IRQ_0XB0_MIN + 0,
    E_MI_OS_INT_IRQ_MIIC_INT1                           = E_MI_OS_INT_IRQ_0XB0_MIN + 1,
    E_MI_OS_INT_IRQ_MIIC_DMA_INT0                       = E_MI_OS_INT_IRQ_0XB0_MIN + 2,
    E_MI_OS_INT_IRQ_MIIC_INT0                           = E_MI_OS_INT_IRQ_0XB0_MIN + 3,
    E_MI_OS_INT_IRQ_UHC30                               = E_MI_OS_INT_IRQ_0XB0_MIN + 4,
    E_MI_OS_INT_IRQ_AU_DMA                              = E_MI_OS_INT_IRQ_0XB0_MIN + 5,
    E_MI_OS_INT_IRQ_DIPW                                = E_MI_OS_INT_IRQ_0XB0_MIN + 6,
    E_MI_OS_INT_IRQ_HDMITX                              = E_MI_OS_INT_IRQ_0XB0_MIN + 7,
    E_MI_OS_INT_IRQ_U3_DPHY                             = E_MI_OS_INT_IRQ_0XB0_MIN + 8,
    E_MI_OS_INT_IRQEXPL_TSO                             = E_MI_OS_INT_IRQ_0XB0_MIN + 9,
    E_MI_OS_INT_IRQ_TSP_TSO0                            = E_MI_OS_INT_IRQ_0XB0_MIN + 9,
    E_MI_OS_INT_IRQEXPH_CEC1                            = E_MI_OS_INT_IRQ_0XB0_MIN + 10,
    E_MI_OS_INT_IRQ_TSP_TSO1                            = E_MI_OS_INT_IRQ_0XB0_MIN + 10,
    E_MI_OS_INT_IRQ_BT_DMA                              = E_MI_OS_INT_IRQ_0XB0_MIN + 11,
    E_MI_OS_INT_IRQ_BT_TAB                              = E_MI_OS_INT_IRQ_0XB0_MIN + 12,
    E_MI_OS_INT_IRQ_SATA                                = E_MI_OS_INT_IRQ_0XB0_MIN + 13,
    E_MI_OS_INT_IRQ_MHL_CBUS_PM                         = E_MI_OS_INT_IRQ_0XB0_MIN + 14,
    E_MI_OS_INT_IRQ_MHL_CBUS_WAKEUP                     = E_MI_OS_INT_IRQ_0XB0_MIN + 15,
    E_MI_OS_INT_IRQ_IDAC_PLUG_DET                       = E_MI_OS_INT_IRQ_0XB0_MIN + 15,
    E_MI_OS_INT_IRQ_0XB0_MAX                            = 0xBF,

    // Add FIQ from 0xC0 ~ 0xFD,
    // if FIQ enum from 0x20 ~ 0x4F, and 0x60 ~ 0x7F is occupied
    E_MI_OS_INT_FIQ_0XC0_MIN                            = 0xC0,
    E_MI_OS_INT_FIQ_DMARD                               = E_MI_OS_INT_FIQ_0XC0_MIN + 0,
    E_MI_OS_INT_FIQ_AU_DMA_BUF_INT                      = E_MI_OS_INT_FIQ_0XC0_MIN + 1,
    E_MI_OS_INT_FIQ_8051_TO_MIPS_VPE1                   = E_MI_OS_INT_FIQ_0XC0_MIN + 2,
    E_MI_OS_INT_FIQ_DVI_DET                             = E_MI_OS_INT_FIQ_0XC0_MIN + 3,
    E_MI_OS_INT_FIQ_PM_GPIO0                            = E_MI_OS_INT_FIQ_0XC0_MIN + 4,
    E_MI_OS_INT_FIQ_PM_GPIO1                            = E_MI_OS_INT_FIQ_0XC0_MIN + 5,
    E_MI_OS_INT_FIQ_PM_GPIO2                            = E_MI_OS_INT_FIQ_0XC0_MIN + 6,
    E_MI_OS_INT_FIQ_PM_GPIO3                            = E_MI_OS_INT_FIQ_0XC0_MIN + 7,
    E_MI_OS_INT_FIQ_PM_XIU_TIMEOUT                      = E_MI_OS_INT_FIQ_0XC0_MIN + 8,
    E_MI_OS_INT_FIQ_PWM_RP_RP_L                         = E_MI_OS_INT_FIQ_0XC0_MIN + 9,
    E_MI_OS_INT_FIQ_PWM_RP_FP_L                         = E_MI_OS_INT_FIQ_0XC0_MIN + 10,
    E_MI_OS_INT_FIQ_PWM_RP_RP_R                         = E_MI_OS_INT_FIQ_0XC0_MIN + 11,
    E_MI_OS_INT_FIQ_PWM_RP_FP_R                         = E_MI_OS_INT_FIQ_0XC0_MIN + 12,
    E_MI_OS_INT_FIQ_8051_TO_MIPS_VPE0                   = E_MI_OS_INT_FIQ_0XC0_MIN + 13,
    E_MI_OS_INT_FIQ_FRC_R2_TO_MIPS                      = E_MI_OS_INT_FIQ_0XC0_MIN + 14,
    E_MI_OS_INT_FIQ_VP6                                 = E_MI_OS_INT_FIQ_0XC0_MIN + 15,
    E_MI_OS_INT_FIQ_0XC0_MAX                            = 0xCF,

    E_MI_OS_INT_FIQ_0XD0_MIN                            = 0xD0,
    E_MI_OS_INT_FIQ_STRETCH                             = E_MI_OS_INT_FIQ_0XD0_MIN + 0,
    E_MI_OS_INT_FIQ_LAN_ESD                             = E_MI_OS_INT_FIQ_0XD0_MIN + 0,
    E_MI_OS_INT_FIQ_GPIO0                               = E_MI_OS_INT_FIQ_0XD0_MIN + 1,
    E_MI_OS_INT_FIQ_REQ_HST0_TO_3                       = E_MI_OS_INT_FIQ_0XD0_MIN + 1,
    E_MI_OS_INT_FIQ_GPIO1                               = E_MI_OS_INT_FIQ_0XD0_MIN + 2,
    E_MI_OS_INT_FIQ_REQ_HST0_TO_2                       = E_MI_OS_INT_FIQ_0XD0_MIN + 2,
    E_MI_OS_INT_FIQ_GPIO2                               = E_MI_OS_INT_FIQ_0XD0_MIN + 3,
    E_MI_OS_INT_FIQ_REQ_HST0_TO_1                       = E_MI_OS_INT_FIQ_0XD0_MIN + 3,
    E_MI_OS_INT_FIQ_GPIO3                               = E_MI_OS_INT_FIQ_0XD0_MIN + 4,
    E_MI_OS_INT_FIQ_ERROR_RASP                          = E_MI_OS_INT_FIQ_0XD0_MIN + 4,
    E_MI_OS_INT_FIQ_GPIO4                               = E_MI_OS_INT_FIQ_0XD0_MIN + 5,
    E_MI_OS_INT_FIQ_REQ_HST1_TO_3                       = E_MI_OS_INT_FIQ_0XD0_MIN + 5,
    E_MI_OS_INT_FIQ_GPIO5                               = E_MI_OS_INT_FIQ_0XD0_MIN + 6,
    E_MI_OS_INT_FIQ_REQ_HST1_TO_2                       = E_MI_OS_INT_FIQ_0XD0_MIN + 6,
    E_MI_OS_INT_FIQ_GPIO6                               = E_MI_OS_INT_FIQ_0XD0_MIN + 7,
    E_MI_OS_INT_FIQ_REQ_HST1_TO_0                       = E_MI_OS_INT_FIQ_0XD0_MIN + 7,
    E_MI_OS_INT_FIQ_GPIO7                               = E_MI_OS_INT_FIQ_0XD0_MIN + 8,
    E_MI_OS_INT_FIQ_REQ_HST2_TO_3                       = E_MI_OS_INT_FIQ_0XD0_MIN + 8,
    E_MI_OS_INT_FIQ_VE_VSYNC_IN                         = E_MI_OS_INT_FIQ_0XD0_MIN + 9,
    E_MI_OS_INT_FIQ_REQ_HST2_TO_1                       = E_MI_OS_INT_FIQ_0XD0_MIN + 9,
    E_MI_OS_INT_FIQEXPL_HST0_TO_3                       = E_MI_OS_INT_FIQ_0XD0_MIN + 10,
    E_MI_OS_INT_FIQ_REQ_HST2_TO_0                       = E_MI_OS_INT_FIQ_0XD0_MIN + 10,
    E_MI_OS_INT_FIQEXPL_HST1_TO_3                       = E_MI_OS_INT_FIQ_0XD0_MIN + 11,
    E_MI_OS_INT_FIQ_REQ_HST3_TO_2                       = E_MI_OS_INT_FIQ_0XD0_MIN + 11,
    E_MI_OS_INT_FIQEXPL_HST2_TO_3                       = E_MI_OS_INT_FIQ_0XD0_MIN + 12,
    E_MI_OS_INT_FIQ_REQ_HST3_TO_1                       = E_MI_OS_INT_FIQ_0XD0_MIN + 12,
    E_MI_OS_INT_FIQEXPH_CMDQ                            = E_MI_OS_INT_FIQ_0XD0_MIN + 13,
    E_MI_OS_INT_FIQ_REQ_HST3_TO_0                       = E_MI_OS_INT_FIQ_0XD0_MIN + 13,
    E_MI_OS_INT_FIQEXPH_HDMITX_EDGE                     = E_MI_OS_INT_FIQ_0XD0_MIN + 14,
    E_MI_OS_INT_FIQEXPH_UHC30                           = E_MI_OS_INT_FIQ_0XD0_MIN + 15,
    E_MI_OS_INT_FIQ_0XD0_MAX                            = 0xDF,

    E_MI_OS_INT_FIQ_0XE0_MIN                            = 0xE0,
    E_MI_OS_INT_FIQ_LDM_DMA0                            = E_MI_OS_INT_FIQ_0XE0_MIN + 0,
    E_MI_OS_INT_IRQ_RASP1                               = E_MI_OS_INT_FIQ_0XE0_MIN + 0,
    E_MI_OS_INT_FIQ_LDM_DMA1                            = E_MI_OS_INT_FIQ_0XE0_MIN + 1,
    E_MI_OS_INT_IRQ_SECEMAC                             = E_MI_OS_INT_FIQ_0XE0_MIN + 1,
    E_MI_OS_INT_IRQ_SDIO                                = E_MI_OS_INT_FIQ_0XE0_MIN + 2,
    E_MI_OS_INT_IRQ_UHC3                                = E_MI_OS_INT_FIQ_0XE0_MIN + 3,
    E_MI_OS_INT_IRQ_USB3                                = E_MI_OS_INT_FIQ_0XE0_MIN + 4,
    E_MI_OS_INT_FIQ_GPIO8                               = E_MI_OS_INT_FIQ_0XE0_MIN + 5,
    E_MI_OS_INT_FIQ_GPIO9                               = E_MI_OS_INT_FIQ_0XE0_MIN + 6,
    E_MI_OS_INT_FIQ_DISP_TGEN0                          = E_MI_OS_INT_FIQ_0XE0_MIN + 7,
    E_MI_OS_INT_IRQ_CA_CRYPTO_DMA                       = E_MI_OS_INT_FIQ_0XE0_MIN + 7,
    E_MI_OS_INT_FIQ_DISP_TGEN1                          = E_MI_OS_INT_FIQ_0XE0_MIN + 8,
    E_MI_OS_INT_IRQ_CA_PROG_PVR                         = E_MI_OS_INT_FIQ_0XE0_MIN + 8,
    E_MI_OS_INT_FIQ_DISP_TGEN2                          = E_MI_OS_INT_FIQ_0XE0_MIN + 9,
    E_MI_OS_INT_IRQ_CA_NSK_INT                          = E_MI_OS_INT_FIQ_0XE0_MIN + 9,
    E_MI_OS_INT_FIQ_DISP_TGEN3                          = E_MI_OS_INT_FIQ_0XE0_MIN + 10,
    E_MI_OS_INT_IRQ_TSP_ECM_FLT                         = E_MI_OS_INT_FIQ_0XE0_MIN + 10,
    E_MI_OS_INT_IRQ_ERROR_RESP                          = E_MI_OS_INT_FIQ_0XE0_MIN + 11,
    E_MI_OS_INT_IRQ_MIU_SECURITY                        = E_MI_OS_INT_FIQ_0XE0_MIN + 12,
    E_MI_OS_INT_FIQ_TEMPERATURE_FLAG_FALL               = E_MI_OS_INT_FIQ_0XE0_MIN + 13,
    E_MI_OS_INT_IRQ_DISP1                               = E_MI_OS_INT_FIQ_0XE0_MIN + 13,
    E_MI_OS_INT_FIQ_TEMPERATURE_FLAG_RISE               = E_MI_OS_INT_FIQ_0XE0_MIN + 14,
    E_MI_OS_INT_IRQ_RTC1                                = E_MI_OS_INT_FIQ_0XE0_MIN + 14,
    E_MI_OS_INT_FIQ_U3_DPHY                             = E_MI_OS_INT_FIQ_0XE0_MIN + 15,
    E_MI_OS_INT_IRQ_GPU2MCU                             = E_MI_OS_INT_FIQ_0XE0_MIN + 15,
    E_MI_OS_INT_FIQ_0XE0_MAX                            = 0xEF,

    E_MI_OS_INT_FIQ_0XF0_MIN                            = 0xF0,
    E_MI_OS_INT_FIQ_DEC_DSP2R2M                         = E_MI_OS_INT_FIQ_0XF0_MIN + 0,
    E_MI_OS_INT_FIQ_AEON_TO_R2M                         = E_MI_OS_INT_FIQ_0XF0_MIN + 1,
    E_MI_OS_INT_FIQ_R2M_TO_AEON                         = E_MI_OS_INT_FIQ_0XF0_MIN + 2,
    E_MI_OS_INT_FIQ_R2M_TO_8051                         = E_MI_OS_INT_FIQ_0XF0_MIN + 3,
    E_MI_OS_INT_IRQ_VIVALDI_DMA_INTR2                   = E_MI_OS_INT_FIQ_0XF0_MIN + 4,
    E_MI_OS_INT_FIQ_AU_DMA_INT                          = E_MI_OS_INT_FIQ_0XF0_MIN + 4,
    E_MI_OS_INT_IRQ_VIVALDI_DMA_INTR1                   = E_MI_OS_INT_FIQ_0XF0_MIN + 5,
    E_MI_OS_INT_FIQ_AU_PCM_DMA_INT                      = E_MI_OS_INT_FIQ_0XF0_MIN + 5,
    E_MI_OS_INT_IRQ_AFEC_INT                            = E_MI_OS_INT_FIQ_0XF0_MIN + 6,
    E_MI_OS_INT_FIQ_AU_SPDIF_TX_CS0                     = E_MI_OS_INT_FIQ_0XF0_MIN + 7,
    E_MI_OS_INT_FIQ_AU_SPDIF_TX_CS1                     = E_MI_OS_INT_FIQ_0XF0_MIN + 8,
    E_MI_OS_INT_FIQ_PCM_DMA                             = E_MI_OS_INT_FIQ_0XF0_MIN + 9,
    E_MI_OS_INT_FIQ_DMDMCU2HK_1                         = E_MI_OS_INT_FIQ_0XF0_MIN + 9,
    E_MI_OS_INT_FIQ_VE_SW_WR2BUF                        = E_MI_OS_INT_FIQ_0XF0_MIN + 10,
    E_MI_OS_INT_IRQ_FRM_PM                              = E_MI_OS_INT_FIQ_0XF0_MIN + 11,
    E_MI_OS_INT_FIQ_FRM_PM                              = E_MI_OS_INT_FIQ_0XF0_MIN + 12,
    E_MI_OS_INT_FIQ_SATA_PHY                            = E_MI_OS_INT_FIQ_0XF0_MIN + 13,
    E_MI_OS_INT_IRQ_FIQ_NONE                            = E_MI_OS_INT_FIQ_0XF0_MIN + 14,
    E_MI_OS_INT_IRQ_FIQ_ALL                             = E_MI_OS_INT_FIQ_0XF0_MIN + 15,
    E_MI_OS_INT_FIQ_0XF0_MAX                            = 0xFF,

    E_MI_OS_INT_FIQ_MAX                                 = E_MI_OS_INT_FIQ_0XF0_MAX,
} MI_OS_InterruptNum_e;

typedef enum
{
    E_MI_OS_ATTR_TYPE_INVALID = -1,                    ///< Invalid Attribute of MY OS.
    E_MI_OS_ATTR_TYPE_TYPE_MIN = 0,                    ///< Min Attribute of MY OS.

    E_MI_OS_ATTR_TYPE_ENABLE_PRINTK = E_MI_OS_ATTR_TYPE_TYPE_MIN,              ///< this type means data without changed after reset and the pUsrParam is the pointer of MI_U16.

    E_MI_OS_ATTR_TYPE_MAX = 0xFF,                             ///< Max Attribute of MY OS.
} MI_OS_AttrType_e;

typedef enum
{
    E_MI_OS_SHARE_MEM_QUERY = 0,                    ///< Query Share Memory.
    E_MI_OS_SHARE_MEM_CREATE = 1,                   ///< Create Share Memory.
} MI_OS_ShareMemCreateType_e;

typedef enum
{
    E_MI_OS_MAPPING_TYPE_INVALID = -1,
    E_MI_OS_MAPPING_TYPE_MIN = 0,
    E_MI_OS_MAPPING_TYPE_NONE = E_MI_OS_MAPPING_TYPE_MIN,
    E_MI_OS_MAPPING_TYPE_NONCACHE,
    E_MI_OS_MAPPING_TYPE_CACHE,
    E_MI_OS_MAPPING_TYPE_BOTH,
    E_MI_OS_MAPPING_TYPE_MAX,
} MI_OS_MappingType_e;

typedef void (*MI_OS_InterruptCallback)(MI_OS_InterruptNum_e eIntNum);

typedef struct MI_OS_MemPoolParams_s
{
    MI_U32 u32PoolSize;                                 ///[IN]: Pool size in bytes
    void *pPoolAddr;                                    ///[IN]: Starting virtual address for the memory pool
} MI_OS_MemPoolParams_t;

typedef struct MI_OS_MemoryPoolInfo_s
{
    void *pPoolAddr;                                    ///[OUT]: The starting address for the memory pool
    MI_U32 u32PoolSize;                                 ///[OUT]: The total size of the memory pool
    MI_U32 u32FreeSize;                                 ///[OUT]: The available free size of the memory pool
    MI_U32 u32LargestFreeBlockSize;                     ///[OUT]: The size of the largest free block
} MI_OS_MemoryPoolInfo_t;

typedef struct MI_OS_FixSizeMemPoolParams_s
{
    MI_U32 u32PoolSize;                                 ///[IN]: Pool size in bytes
    MI_U32 u32BlockSize;                                ///[IN]: Fixed block size for each allocated block in the pool
    void *pPoolAddr;                                    ///[IN]: Starting virtual address for the memory pool
} MI_OS_FixSizeMemPoolParams_t;

typedef struct MI_OS_CreateTaskParams_s
{
    MI_OS_TaskEntry pfTaskEntry;                        ///[IN]: Task entry function
    void *pTaskEntryData;                               ///[IN]: The parameter data when the task entry function is invoked
    MI_OS_TaskPriority_e eTaskPriority;                 ///[IN]: Task's priority
    MI_BOOL bAutoStart;                                 ///[IN]: Start immediately or later
    void *pStackEntry;                                  ///[IN]: Task's stack
    MI_U32 u32StackSize;                                ///[IN]: Stack's size
    MI_U8 *pszTaskName;                                 ///[IN]: Task's name
} MI_OS_CreateTaskParams_t;

typedef struct MI_OS_TaskInfoParams_s
{
    MI_OS_TaskPriority_e eTaskPriority;                 ///[OUT]: Task's priority
    void * pStackEntry;                                 ///[OUT]: Task entry function
    MI_U32 u32StackSize;                                ///[OUT]: Stack's size
    MI_U32 u32StackUsed;                                ///[OUT]: Used stack size
    MI_U8 szTaskName[16];                               ///[OUT]: Task's name
} MI_OS_TaskInfoParams_t;

typedef struct MI_OS_CreateMutexParams_s
{
    MI_U8 *pszName;                                     ///[IN]: Mutex's name
    MI_U32 u32Flag;                                     ///[IN]: Process data shared flag
} MI_OS_CreateMutexParams_t;

typedef struct MI_OS_MutexInfo_s
{
    MI_OS_Attribute_e eAttribute;                       ///[OUT]: Suspending order
    MI_U8 *pszName;                                     ///[OUT]: Mutex's name
} MI_OS_MutexInfo_t;

typedef struct MI_OS_CreateSemParams_s
{
    MI_U8 *pszName;                                     ///[IN]: Semaphore's name
    MI_U32 u32InitCnt;                                  ///[IN]: Initial semaphore value
} MI_OS_CreateSemParams_t;

typedef struct MI_OS_SemInfo_s
{
    MI_U32 u32Cnt;                                      ///[OUT]: Semaphore's value
    MI_OS_Attribute_e eAttribute;                       ///[OUT]: Suspending order
    MI_U8 *pszName;                                     ///[OUT]: Semaphore's name
} MI_OS_SemInfo_t;

typedef struct MI_OS_WaitEventParams_s
{
    MI_S32 s32EventGroupId;                             ///[IN]: Event group ID
    MI_U32 u32WaitEventFlag;                            ///[IN]: Wait event flag value
    MI_OS_EventWaitMode_e eWaitMode;                    ///[IN]: E_AND/E_OR/E_AND_CLEAR/E_OR_CLEAR
    MI_U32 u32WaitMs;                                   ///[IN]: 0 ~ MSOS_WAIT_FOREVER: suspending time (ms) if the event is not ready
} MI_OS_WaitEventParams_t;

typedef struct MI_OS_CreateTimerParams_s
{
    MI_OS_TimerCallback pfTimerCallback;                ///[IN]: Timer's callback function
    MI_U32 u32FirstTimeMs;                              ///[IN]: The first Ms for timer expiration
    MI_U32 u32PeriodTimeMs;                             ///[IN]: Periodic Ms for timer expiration after first expiration
                                                        ///      0: one shot timer
    MI_BOOL bStartTimer;                                ///[IN]: TRUE: activates the timer after it is created
    MI_U8 *pszName;                                     ///[IN]: Timer's name
} MI_OS_CreateTimerParams_t;

typedef struct MI_OS_ResetTimerParams_s
{
    MI_S32 s32TimerId;                                  ///[IN]: Timer's ID
    MI_U32 u32FirstTimeMs;                              ///[IN]: The first Ms for timer expiration
    MI_U32 u32PeriodTimeMs;                             ///[IN]: Periodic Ms for timer expiration after first expiration
                                                        ///      0: one shot timer
    MI_BOOL bStartTimer;                                ///[IN]: TRUE: activates the timer after it is created
} MI_OS_ResetTimerParams_t;

typedef struct MI_OS_CreateQueueParams_s
{
    void *pStartAddr;                                   ///[IN]: It is useless now, can pass NULL.
    MI_U32 u32QueueSize;                                ///[IN]: Queue's size in byte
    MI_OS_MessageType_e eMessageType;                   ///[IN]: E_MSG_FIXED_SIZE / E_MSG_VAR_SIZE
    MI_U32 u32MessageSize;                              ///[IN]: Message's size in byte for E_MSG_FIXED_SIZE
                                                        ///      Max message size's in byte for E_MSG_VAR_SIZE
    MI_OS_Attribute_e eAttribute;                       ///[IN]: Suspending order
    MI_U8 *pszName;                                     ///[IN]: Queue's size
} MI_OS_CreateQueueParams_t;

typedef struct MI_OS_SendToQueueParams_s
{
    MI_S32 s32QueueId;                                  ///[IN]: Queue's ID
    MI_U8 *pu8Message;                                  ///[IN]: The pointer to the message to be sent.
    MI_U32 u32Size;                                     ///[IN]: Message's size
    MI_U32 u32WaitMs;                                   ///[IN]: 0 ~ MSOS_WAIT_FOREVER: suspending time(Ms) if the queue is full
} MI_OS_SendToQueueParams_t;

typedef struct MI_OS_RecvFromQueueParams_s
{
    MI_S32 s32QueueId;                                  ///[IN]: Queue's ID
    MI_U32 u32IntendedSize;                             ///[IN]: The intended size of the message in byte
    MI_U32 u32WaitMs;                                   ///[IN]: 0 ~ MSOS_WAIT_FOREVER: suspending time(Ms) if the queue is empty
    MI_U8 *pu8Message;                                  ///[OUT]: The message to be received
    MI_U32 u32ActualSize;                               ///[OUT]: The actual size of the message received in byte
} MI_OS_RecvFromQueueParams_t;

typedef struct MI_OS_PeekFromQueueParams_s
{
    MI_S32 s32QueueId;                                  ///[IN]: Queue's ID
    MI_U32 u32IntendedSize;                             ///[IN]: The intended size of the message in byte
    MI_U8 *pu8Message;                                  ///[OUT]: The message to be received
    MI_U32 u32ActualSize;                               ///[OUT]: The actual size of the message received in byte
} MI_OS_PeekFromQueueParams_t;

typedef struct MI_OS_ClearQueueParams_s
{
    MI_S32 s32QueueId;                                  ///[IN]: Queue's ID
    MI_U32 u32WaitMs;                                   ///[IN]: 0 ~ MSOS_WAIT_FOREVER: suspending time(Ms)
} MI_OS_ClearQueueParams_t;

typedef struct MI_OS_Caps_s
{
    MI_U32 u32MaxTaskNum;                               ///[OUT]: Maximum number of task
    MI_U32 u32MaxMemPoolNum;                            ///[OUT]: Maximum number of memory pool
    MI_U32 u32MaxFixSizeMemPoolNum;                     ///[OUT]: Maximum number of fixed size memory pool
    MI_U32 u32MaxSemaphoreNum;                          ///[OUT]: Maximum number of semaphore
    MI_U32 u32MaxMutexNum;                              ///[OUT]: Maximum number of mutex
    MI_U32 u32MaxEventGroupNum;                         ///[OUT]: Maximum number of event group
    MI_U32 u32MaxTimerNum;                              ///[OUT]: Maximum number of timer
    MI_U32 u32MaxQueueNum;                              ///[OUT]: Maximum number of queue
} MI_OS_Caps_t;

typedef struct MI_OS_ShareMemInfo_s
{
    MI_U8 szClientName[MI_OS_SHARE_MEMORY_NAME_LEN_MAX];        /// [IN]  szClientName : client name
    MI_U32 u32RequestMemSize;                                   /// [IN]  u32RequestMemSize : request memory size
    MI_OS_ShareMemCreateType_e eCreateType;                     /// [IN]  E_MI_OS_SHARE_MEM_QUERY / E_MI_OS_SHARE_MEM_CREATE
    MI_VIRT virtStartAddr;                                      /// [OUT]  virtStartAddr : start virtual address
} MI_OS_ShareMemInfo_t;

typedef struct MI_OS_IommuAllocate_s
{
    MI_U8 au8TagName[32];                    ///[IN]Tagname
    MI_U32 u32Size;                         ///[IN]Size to allocate
    MI_OS_MappingType_e eMmaMappingType;    ///[IN]Mapping type
    MI_BOOL bSecure;                        ///[IN]Secure
    MI_PHY phyAddr;                         ///[OUT]Physical address allocated
} MI_OS_IommuAllocate_t;

typedef struct MI_OS_IommuFree_s
{
    MI_PHY phyAddr;
    MI_U32 u32Size;
} MI_OS_IommuFree_t;

typedef struct MI_OS_IommuBufFd_s{
    MI_PHY phyAddr;
    MI_S32 fd;

} MI_OS_IommuBufFd_t;

typedef enum{
    E_MI_OS_IOMMU_OPERATION_TYPE_INVALID = -1,
    E_MI_OS_IOMMU_OPERATION_TYPE_GET_BUFFD,
    E_MI_OS_IOMMU_OPERATION_TYPE_PUT_BUFFD,
} MI_OS_IommuOperation_e;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief Create a variable-size virtual memory pool dynamically
/// @param[in] pstMemPoolParams : create pool params
/// @param[Out] ps32PoolId : assigned memory pool ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateMemoryPool(MI_OS_MemPoolParams_t *pstMemPoolParams, MI_S32 *ps32PoolId);

//------------------------------------------------------------------------------
/// @brief Delete a variable-size memory pool
/// @param[in] s32PoolId : Pool ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteMemoryPool(MI_S32 s32PoolId);

//------------------------------------------------------------------------------
/// @brief Get the information of a variable-size memory pool
/// @param[in] s32PoolId: s32PoolSize Pool ID
/// @param[Out] pstMemoryPoolInfo : InfoMemoryPool params.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetMemoryPoolInfo(MI_S32 s32PoolId, MI_OS_MemoryPoolInfo_t *pstMemoryPoolInfo);

//------------------------------------------------------------------------------
/// @brief Allocate a memory block with 16-Byte aligned starting address from memory pool
/// @param[in] u32Size Request size
/// @param[in] s32PoolId Memory pool ID
/// @param[Out]  pMemAddr : pointer to the allocated memory block
/// @return NULL: not enough available memory
/// @return Otherwise: pointer to the allocated memory block
//------------------------------------------------------------------------------
void* MI_OS_AllocateMemory(MI_U32 u32Size, MI_S32 s32PoolId);

//------------------------------------------------------------------------------
/// @brief ReAllocate a block of memory with 4-byte aligned start address from the variable-size memory pool
/// @param[in] pOrgAddr : points to the beginning of the original memory block
/// @param[in] u32Size : size of new memory block
/// @param[in] s32PoolId : memory pool ID
/// @return NULL: not enough available memory
/// @return Otherwise: pointer to the allocated memory block
//------------------------------------------------------------------------------
void* MI_OS_ReAllocateMemory(void *pOrgAddr, MI_U32 u32Size, MI_S32 s32PoolId);

//------------------------------------------------------------------------------
/// @brief Free a memory block from memory pool
/// @param[in] pAddr Pointer to previously allocated memory block
/// @param[in] s32PoolId Memory pool ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_FreeMemory(void* pAddr, MI_S32 s32PoolId);

//------------------------------------------------------------------------------
/// @brief Flush memory from pipe to dram
/// @param[in] None
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_FlushMemory(void);

//------------------------------------------------------------------------------
/// @brief Read memory from dram to pipe
/// @param[in] None
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ReadMemory(void);

//-------------------------------------------------------------------------------------------------
/// @brief Get the share memory by client name and request memory size
/// @param[in]  pstShareMemInfo : share memory info parameter
/// @return MI_OK : succeed
/// @return MI_ERR_FAILED : the share memory has not been created
//-------------------------------------------------------------------------------------------------
MI_RESULT MI_OS_GetShareMem(MI_OS_ShareMemInfo_t* pstShareMemInfo);

//-------------------------------------------------------------------------------------------------
/// @brief Free the share memory by client name
/// @param[in]  pu8ClientName : client name
/// @return MI_OK : succeed
/// @return MI_ERR_FAILED : the share memory has not been free
//-------------------------------------------------------------------------------------------------
MI_RESULT MI_OS_FreeShareMem(MI_U8* pu8ClientName);

//------------------------------------------------------------------------------
/// @brief Create a fixed-size virtual memory pool dynamically, eCos support only.
/// @param[in] pstFixSizePoolParams : create fix size pool parameters.
/// @param[Out] ps32PoolId : assigned memory pool ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateFixSizeMemoryPool(MI_OS_FixSizeMemPoolParams_t *pstFixSizePoolParams, MI_S32 *ps32PoolId);

//------------------------------------------------------------------------------
/// @brief Delete a fixed-size memory pool, eCos support only.
/// @param[in] s32PoolId : Pool ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteFixSizeMemoryPool(MI_S32 s32PoolId);

//------------------------------------------------------------------------------
/// @brief Get the information of a fixed-size memory pool, eCos support only.
/// @param[in] s32PoolId: s32PoolSize Pool ID
/// @param[Out]  pstMemoryPoolInfo : parameters of fix size memory pool information.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetFixSizeMemoryPoolInfo(MI_S32 s32PoolId, MI_OS_MemoryPoolInfo_t *pstMemoryPoolInfo);

//------------------------------------------------------------------------------
/// @brief Allocate a memory block from the fixed-size memory pool, eCos support only.
/// @param[in] s32PoolId Memory pool ID
/// @return NULL: not enough available memory
/// @return Otherwise: pointer to the allocated memory block
//------------------------------------------------------------------------------
void* MI_OS_AllocateFixSizeMemory(MI_S32 s32PoolId);

//------------------------------------------------------------------------------
/// @brief Free a memory block from the fixed-size memory pool, eCos support only.
/// @param[in] pAddress : pointer to previously allocated memory block
/// @param[in] s32PoolId : Memory pool ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_FreeFixSizeMemory(void* pAddr, MI_S32 s32PoolId);

//------------------------------------------------------------------------------
/// @brief Get all task ID, eCos support only.
/// @param[out] pu32TaskNum : all task number
/// @param[out] ps32TaskIdList : the memory for the all task ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetTaskList(MI_U32 *pu32TaskNum, MI_S32 *ps32TaskIdList);

//------------------------------------------------------------------------------
/// @brief Create a task
/// @param[in] pstCreateTaskParams : create task parameters.
/// @param[Out] ps32TaskId : assigned Task ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateTask(const MI_OS_CreateTaskParams_t *pstCreateTaskParams, MI_S32 *ps32TaskId);

//------------------------------------------------------------------------------
/// @brief  Delete a previously created task
/// @param[in] s32TaskId : task ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteTask(MI_S32 s32TaskId);

//------------------------------------------------------------------------------
/// @brief  Yield the execution right to ready tasks with "the same" priority
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_YieldTask (void);

//------------------------------------------------------------------------------
/// @brief  Suspend the calling task for u32Ms milliseconds
/// @param[in] u32Ms : delay 1 ~ MI_OS_WAIT_FOREVER ms
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DelayTask(MI_U32 u32Ms);

//------------------------------------------------------------------------------
/// @brief  Delay for u32Us microseconds
/// @param[in] u32Us : delay 0 ~ 999 us
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DelayTaskUs(MI_U32 u32Us);

//------------------------------------------------------------------------------
/// @brief  Busy Wait for u32Us microseconds
/// @param[in] u32Us : delay 0 ~ 999 us
/// @return MI_OK: Process success.
/// @note   implemented by "busy waiting". Plz call MI_OS_DelayTask directly for ms-order delay
//------------------------------------------------------------------------------
MI_RESULT MI_OS_BusyWaitTaskUs(MI_U32 u32Us);

//------------------------------------------------------------------------------
/// @brief  Resume the specified suspended task
/// @param[in] s32TaskId : Task ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note   This API is not supported in Linux
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ResumeTask(MI_S32 s32TaskId);

//------------------------------------------------------------------------------
/// @brief  Suspend the specified task
/// @param[in] s32TaskId : Task ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note   This API is not supported in Linux
//------------------------------------------------------------------------------
MI_RESULT MI_OS_SuspendTask(MI_S32 s32TaskId);

//------------------------------------------------------------------------------
/// @brief Get Task information
/// @param[in] s32TaskId : Task ID
/// @param[out] pstTaskInfoParams : Get task information paramenter.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetTaskInfo(MI_S32 s32TaskId, MI_OS_TaskInfoParams_t *pstTaskInfoParams);

//------------------------------------------------------------------------------
/// @brief  Get current task ID
/// @param[Out] ps32TaskId : current Task ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetTaskId(MI_S32 *ps32TaskId);

//------------------------------------------------------------------------------
/// @brief  Get current thread ID in Operation System
/// @param[Out] ps32ThreadId: current thread ID in Operation System
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetOsThreadId(MI_S32 *ps32ThreadId);

//------------------------------------------------------------------------------
/// @brief  Create a mutex in the unlocked state
/// @param[in] pstCreateMutexParams : mutex create parameters.
/// @param[Out] ps32MutexId : assigned mutex ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note   A mutex has the concept of an owner, whereas a semaphore does not.
///         A mutex provides priority inheritance protocol against proiorty inversion,
///         whereas a binary semaphore does not.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateMutex(const MI_OS_CreateMutexParams_t *pstCreateMutexParams, MI_S32 *ps32MutexId);

//------------------------------------------------------------------------------
/// @brief  Delete the specified mutex
/// @param[in] s32MutexId : mutex ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note   It is important that the mutex be in the unlocked state when it is
///            destroyed, or else the behavior is undefined.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteMutex(MI_S32 s32MutexId);

//------------------------------------------------------------------------------
/// @brief  Attempt to lock a mutex
/// @param[in] s32MutexId : mutex ID
/// @param[in] u32WaitMs : 0 ~ MI_OS_WAIT_FOREVER: suspend time (ms) if the mutex is locked
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ObtainMutex(MI_S32 s32MutexId, MI_U32 u32WaitMs);

//------------------------------------------------------------------------------
/// @brief  Attempt to unlock a mutex
/// @param[in] s32MutexId : mutex ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ReleaseMutex(MI_S32 s32MutexId);

//------------------------------------------------------------------------------
/// @brief  Get a mutex informaton
/// @param[in] s32MutexId : mutex ID
/// @param[in] pstMutexInfo : ptr to info of muxte parameters structure.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetMutexInfo(MI_S32 s32MutexId, MI_OS_MutexInfo_t *pstMutexInfo);

//------------------------------------------------------------------------------
/// @brief  Create a semaphore
/// @param[in] pstCreateSemParams : create semaphore parameters.
/// @param[out] ps32SemaphoreId : assigned Semaphore ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateSemaphore(const MI_OS_CreateSemParams_t *pstCreateSemParams, MI_S32 *ps32SemaphoreId);

//------------------------------------------------------------------------------
/// @brief  Delete the specified semaphore
/// @param[in] s32SemaphoreId : semaphore ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note   It is important that there are not any threads waiting on the semaphore
///             when this function is called or the behavior is undefined.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteSemaphore(MI_S32 s32SemaphoreId);

//------------------------------------------------------------------------------
/// @brief  Attempt to decrement a semaphore count
/// @param[in] s32SemaphoreId : semaphore ID
/// @param[in] u32WaitMs :  0 ~ MI_OS_WAIT_FOREVER: suspend time (ms) if the semaphore count = 0
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ObtainSemaphore(MI_S32 s32SemaphoreId, MI_U32 u32WaitMs);

//------------------------------------------------------------------------------
/// @brief  Increase a semaphore count
/// @param[in] s32SemaphoreId : semaphore ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note   It's possible for any thread to increase the semaphore count
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ReleaseSemaphore(MI_S32 s32SemaphoreId);

//------------------------------------------------------------------------------
/// @brief  Get a semaphore informaton
/// @param[in] s32SemaphoreId : semaphore ID
/// @param[in] pstSemInfo : semaphore information parameters structure.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetSemaphoreInfo(MI_S32 s32SemaphoreId, MI_OS_SemInfo_t *pstSemInfo);

//------------------------------------------------------------------------------
/// @brief  Create an event group
/// @param[in] pszName : ptr to event group name
/// @param[out] ps32EventGroupId : assigned Event ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateEventGroup(const MI_U8 *pszName, MI_S32 *ps32EventGroupId);

//------------------------------------------------------------------------------
/// @brief  Delete the event group
/// @param[in] s32EventGroupId : event group ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note event group that are being waited on must not be deleted
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteEventGroup(MI_S32 s32EventGroupId);

//------------------------------------------------------------------------------
/// @brief Set the event flag (bitwise OR w/ current value) in the specified event group
/// @param[in] s32EventGroupId : event group ID
/// @param[in] u32EventFlag :event flag value
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @note event group that are being waited on must not be deleted
//------------------------------------------------------------------------------
MI_RESULT MI_OS_SetEvent(MI_S32 s32EventGroupId, MI_U32 u32EventFlag);

//------------------------------------------------------------------------------
/// @brief Clear the specified event flag (bitwise XOR operation) in the specified event group
/// @param[in] s32EventGroupId : event group ID
/// @param[in] u32EventFlag :event flag value
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ClearEvent(MI_S32 s32EventGroupId, MI_U32 u32EventFlag);

//------------------------------------------------------------------------------
/// @brief Wait for the specified event flag combination from the event group
/// @param[in] pstWaitEventParams : wait evet parameters
/// @param[in] pu32RetrievedEventFlag :etrieved event flag value
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_WaitEvent(const MI_OS_WaitEventParams_t *pstWaitEventParams, MI_U32 *pu32RetrievedEventFlag);

//------------------------------------------------------------------------------
/// @brief Create a Timer
/// @param[in] pstCreateTimerParams : create timer parameters.
/// @param[out] ps32TimerId :assigned Timer ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateTimer(const MI_OS_CreateTimerParams_t *pstCreateTimerParams, MI_S32 *ps32TimerId);

//------------------------------------------------------------------------------
/// @brief Delete the Timer
/// @param[in] s32TimerId : Timer ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteTimer(MI_S32 s32TimerId);

//------------------------------------------------------------------------------
/// @brief Start the Timer
/// @param[in] s32TimerId : Timer ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_StartTimer(MI_S32 s32TimerId);

//------------------------------------------------------------------------------
/// @brief Stop the Timer
/// @param[in] s32TimerId : Timer ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_StopTimer(MI_S32 s32TimerId);

//------------------------------------------------------------------------------
/// @brief Reset a Timer & reset the expiration periods
/// @param[in] pstResetTimerParams : reset timer parameter
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ResetTimer(const MI_OS_ResetTimerParams_t *pstResetTimerParams);

//------------------------------------------------------------------------------
/// @brief Get current system time in ms
/// @param[out] pu32SystemTime : system time in ms
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetSystemTime(MI_U32 *pu32SystemTime);

//------------------------------------------------------------------------------
/// @brief Time difference between current timer and task time[OBSOLETE]
/// @param[in] u32TimerCurrent : current timer in ms
/// @param[out] pu32DiffMs : system time diff in ms
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_TimerDiffTimeFromNow(MI_U32 u32TimerCurrent, MI_U32 *pu32DiffMs);

//------------------------------------------------------------------------------
/// @brief Time difference between setting time and task time[OBSOLETE]
/// @param[in] u32Timer : timer time in ms
/// @param[in] u32TaskTimer : current time in ms
/// @param[out] pu32DiffTime : system time diff in ms
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_TimerDiffTime(MI_U32 u32Timer, MI_U32 u32TaskTimer, MI_U32 *pu32DiffTime);

//------------------------------------------------------------------------------
/// @brief Create a Queue
/// @param[in] pstCreateQueueParams : create queue pareameter
/// @param[out] ps32QueueId : assigned message queue ID
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CreateQueue(const MI_OS_CreateQueueParams_t *pstCreateQueueParams, MI_S32 *ps32QueueId);

//------------------------------------------------------------------------------
/// @brief Delete the Queue
/// @param[in] s32QueueId : Queue ID
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DeleteQueue(MI_S32 s32QueueId);

//------------------------------------------------------------------------------
/// @brief Send a message to the end of the specified queue
/// @param[in] pstSendToQueueParams : send queue parameters structure
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_SendToQueue(const MI_OS_SendToQueueParams_t *pstSendToQueueParams);

//------------------------------------------------------------------------------
/// @brief Receive a message from the specified queue
/// @param[in/out] pstRecvFromQueueParams : receive queue parameters structure
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_RecvFromQueue(MI_OS_RecvFromQueueParams_t *pstRecvFromQueueParams);

//------------------------------------------------------------------------------
/// @brief Peek a message from the specified queue
/// @param[in/out] pstPeekFromQueueParams : Peek queue parameters structure
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_PeekFromQueue(MI_OS_PeekFromQueueParams_t *pstPeekFromQueueParams);

//------------------------------------------------------------------------------
/// @brief clear all message in specified queue
/// @param[in] pstClearQueueParams : clear queue parameters structure
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_ClearQueue(const MI_OS_ClearQueueParams_t *pstClearQueueParams);

//------------------------------------------------------------------------------
/// @brief Attach the interrupt callback function to interrupt
/// @param[in] eIntNum : Interrupt number in enumerator InterruptNum
/// @param[in] pfIntCallback : Interrupt callback function
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_AttachInterrupt(MI_OS_InterruptNum_e eIntNum, MI_OS_InterruptCallback pfIntCallback);

//------------------------------------------------------------------------------
/// @brief Detach the interrupt callback function from interrupt
/// @param[in] eIntNum : Interrupt number in enumerator InterruptNum
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DetachInterrupt(MI_OS_InterruptNum_e eIntNum);

//------------------------------------------------------------------------------
/// @brief Enable (unmask) the interrupt
/// @param[in] eIntNum : Interrupt number in enumerator InterruptNum
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_EnableInterrupt(MI_OS_InterruptNum_e eIntNum);

//------------------------------------------------------------------------------
/// @brief Disable (mask) the interrupt #
/// @param[in] eIntNum : Interrupt number in enumerator InterruptNum
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DisableInterrupt(MI_OS_InterruptNum_e eIntNum);

//------------------------------------------------------------------------------
/// @brief Debug the interrupt
/// @param[in] eIntNum : Interrupt number in enumerator InterruptNum
/// @param[in] eIrqDebugOpt : Debug option
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DebugInterrupt(MI_OS_InterruptNum_e eIntNum, MI_OS_IrqDebugOpt_e eIrqDebugOpt);

//------------------------------------------------------------------------------
/// @brief Notify the interrupt complete
/// @param[in] eIntNum : Interrupt number in enumerator InterruptNum
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
/// @return MI_ERR_NOT_SUPPORT: Not supported.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_CompleteInterrupt(MI_OS_InterruptNum_e eIntNum);

//------------------------------------------------------------------------------
/// @brief In interrupt Context or not
/// @param[Out] pbIsInInterrupt : TRUE -> YES, FALSE -> NO
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_IsInInterrupt(MI_BOOL *pbIsInInterrupt);

//------------------------------------------------------------------------------
/// @brief Disable all interrupts (including timer interrupt), the scheduler is disab
/// @param[out] pu32SavedInterruptStatus :Interrupt register value before all interrupts disable
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DisableAllInterrupts(MI_U32 *pu32SavedInterruptStatus);

//------------------------------------------------------------------------------
/// @brief Restore the interrupts from last MI_OS_DisableAllInterrupts.
/// @param[in] u32RestoredInterruptStatus : Interrupt register value from @ref MI_OS_DisableAllInterrupts
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_RestoreAllInterrupts(MI_U32 u32RestoredInterruptStatus);

//------------------------------------------------------------------------------
/// @brief Enable all CPU interrupts.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_EnableAllInterrupts(void);

//------------------------------------------------------------------------------
/// @brief Write back if dirty & Invalidate the cache lines in the given range.
/// @param[in] virtStartAddr : start address (must be 16-B aligned and in cacheable area)
/// @param[in] u32Size : size (must be 16-B aligned)
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_DcacheFlush(MI_VIRT virtStartAddr, MI_U32 u32Size);

//------------------------------------------------------------------------------
/// @brief Check the VA is belong to cache pool or not.
/// @param[in] pAddr : The Va will be checked.
/// @param[out] pbIsCache : Indicate The VA is belong to cache or not.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: The virtStartAddress isn't belong to MPool address.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_IsCacheAddr(const void *pAddr, MI_BOOL *pbIsCache);

//------------------------------------------------------------------------------
/// @brief convert virtual address to physical address.
/// @param[in] virtAddr : virtual address
/// @param[out] pphyAddr : physical address
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_Va2Pa(MI_VIRT virtAddr, MI_PHY *pphyAddr);

//------------------------------------------------------------------------------
/// @brief convert physical address to cached virtual address
/// @param[in] phyAddr : physical address
/// @param[out] pvirtCachedAddr : cached virtual address
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_Pa2CachedVa(MI_PHY phyAddr, MI_VIRT *pvirtCachedAddr);

//------------------------------------------------------------------------------
/// @brief convert physical address to non cached virtual address
/// @param[in] phyAddr : physical address
/// @param[out] pvirtNonCachedAddr :  non cached virtual address
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_Pa2NonCachedVa(MI_PHY phyAddr, MI_VIRT *pvirtNonCachedAddr);

//------------------------------------------------------------------------------
/// @brief convert bus address to physical address
/// @param[in] phyBusAddr : bus address
/// @param[out] pphyAddr :  pointer to physical address
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_Ba2Pa(MI_PHY phyBusAddr, MI_PHY *pphyAddr);

//------------------------------------------------------------------------------
/// @brief convert physical address to bus address
/// @param[in] phyAddr : physical address
/// @param[out] pphyBusAddr : pointer to bus address
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_Pa2Ba(MI_PHY phyAddr, MI_PHY *pphyBusAddr);

//------------------------------------------------------------------------------
/// @brief Allocate IOMMU buffer
/// @param[in] pstIommuAllocate
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_AllocateIommuMemory(MI_OS_IommuAllocate_t *pstAllocateParams);

//------------------------------------------------------------------------------
/// @brief Free IOMMU buffer
/// @param[in] pstIommuAllocate
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_FreeIommuMemory(MI_OS_IommuFree_t *pstFreeParams);

//------------------------------------------------------------------------------
/// @brief Iommu operation/
// @param[in] type/
// @param[inout] pstParams/
// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_IommuOperation(MI_OS_IommuOperation_e type, void* pstParams);

//------------------------------------------------------------------------------
/// @brief Get OS capability
/// @param[out] pstCaps : Get OS Capability parameter.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetCaps(MI_OS_Caps_t *pstCaps);

//------------------------------------------------------------------------------
/// @brief Set OS debug level.
/// @param[in] u32DebugLevel: Debug level
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief Sync memory from pipe to dram
/// @param[in] None
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_Sync(void);


//------------------------------------------------------------------------------
/// @brief Set OS Attribute.
/// @param[in] eAttrType: for sys module function type
/// @param[in] pAttrParams: Pointer to input information.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_SetAttr(MI_OS_AttrType_e eAttrType, const void* pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get OS Attribute.
/// @param[in] eAttrType: for sys module function type
/// @param[in]  pInputParams: input params,set NULL if not necessary.
/// @param[in]  pOutputParams: Pointer to struct to retrieve the information accroding to eParamType
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_OS_GetAttr(MI_OS_AttrType_e eAttrType, const void * pInputParams, void * pOutputParams);

//------------------------------------------------------------------------------
/// @brief Use printk to output message.
/// @param[in] pszString: input string
//------------------------------------------------------------------------------
void MI_OS_Printk(MI_U8 *pszString, ...);

#ifdef __cplusplus
}
#endif

#endif///_MI_OS_H_

