/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_FS_H_
#define _MI_FS_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_FS_ATTR_TYPE_INVALID = -1,
    E_MI_FS_ATTR_TYPE_MIN = 0,

    E_MI_FS_ATTR_TYPE_IS_UNICODE_FS_USED = E_MI_FS_ATTR_TYPE_MIN,   ///< support ASCII only or Unicode

    E_MI_FS_ATTR_TYPE_MAX,
} MI_FS_AttrType_e;

typedef struct MI_FS_InitParams_s
{
    MI_BOOL bEnableUnicode;                             ///[IN]: FALSE: Support ASCII only; TRUE: Support Unicode
} MI_FS_InitParams_t;

typedef struct MI_FS_InfoParams_s
{
    MI_U32 u32ClusTotal;                                ///[OUT]: Total block count
    MI_U32 u32ClusFree;                                 ///[OUT]: Free block count
    MI_U32 u32ClusSize;                                 ///[OUT]: Fundamental file system block size in bytes
} MI_FS_InfoParams_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------
//------------------------------------------------------------------------------
/// @brief File system API initialization
/// @param[in] pstInitParams : init parameters
/// @return MI_OK: Process success.
/// @return MI_HAS_INITED: Module has been initialized.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Init(const MI_FS_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Mount a filesystem
/// @param[in] pszDeviceName : name of hardware device:     eg. ""      , "/dev/fd0/"   , ...
/// @param[in] pszDir : name of mount point:             "/ram"  , "/floppy"     , ...
/// @param[in] pszFsName : name of implementing filesystem: "ramfs" , "fatfs"       , ...
/// @param[in] u32MountFlags :
/// @param[in] pData :
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Mount(const MI_U8 *pszDeviceName, const MI_U8 *pszDir, const MI_U8 *pszFsName, MI_U32 u32MountFlags, const void* pData);

//------------------------------------------------------------------------------
/// @brief Mount a filesystem
/// @param[in] pszDir : name of mount point:         eg.   "/ram"  , "/floppy"     , ...
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Umount(const MI_U8 *pszDir);

//------------------------------------------------------------------------------
/// @brief Open a file
/// @param[in] pszPath : the pathname of the file
/// @param[in] u32Flag : bitwise-OR flags of O_RDONLY, O_WRONLY, O_RDWR, O_APPEND, O_CREAT, O_EXCL, O_TRUNC, O_NONBLOCK
/// @return : >=0 the file descriptor associated with the file, <0 is fail.
/// @note   The maximum number of open files allowed is determined by the CYGNUM_FILEIO_NFILE
//------------------------------------------------------------------------------
MI_S32 MI_FS_Open(const MI_U8 *pszPath, MI_U32 u32Flag);

//------------------------------------------------------------------------------
/// @brief Unlink/Remove a file
/// @param[in] pszPath : the pathname of the file
/// @return MI_OK: the file descriptor associated with the named file
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
/// @note   Remove a link to a file; When the file's link count becomes 0 and no process has the file open,
///         the space occupied by the file will be freed.
/// @note   Cannot unlink directories; use rmdir() instead
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Unlink(const MI_U8 *pszPath);

//------------------------------------------------------------------------------
/// @brief Make a directory
/// @param[in] pszPath : the pathname of the directory
/// @param[in] u32Mode : reserved
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_MkDir(const MI_U8 *pszPath, MI_U32 u32Mode);

//------------------------------------------------------------------------------
/// @brief Remove a directory
/// @param[in] pszPath : the pathname of the directory
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_RmDir(const MI_U8 *pszPath);

//------------------------------------------------------------------------------
/// @brief Change current working directory
/// @param[in] pszPath : the pathname of the directory
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_ChDir(const MI_U8 *pszPath);

//------------------------------------------------------------------------------
/// @brief Rename a file/directory
/// @param[in] pszOldPath : the old pathname of the file
/// @param[in] pszNewPath : The new pathname of the file
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Rename(const MI_U8 *pszOldPath, const MI_U8 *pszNewPath);

//------------------------------------------------------------------------------
/// @brief Rename a file/directory
/// @param[in] pszExistPath : the old pathname of the file
/// @param[in] pszNewPath : The new pathname of the file
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Link(const MI_U8 *pszExistPath, const MI_U8 *pszNewPath);

//------------------------------------------------------------------------------
/// @brief Get file status
/// @param[in] pszPath : the pathname of the file
/// @param[out] pStat : a pointer to a stat structure as defined in <sys/stat.h>
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Stat(const MI_U8 *pszPath, struct stat *pStat);

//------------------------------------------------------------------------------
/// @brief Get file status
/// @param[in] u32Fd : the file descriptor associated with the file
/// @param[out] pStat : a pointer to a stat structure as defined in <sys/stat.h>
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Fstat(MI_U32 u32Fd, struct stat *pStat);

//------------------------------------------------------------------------------
/// @brief Get configurable pathname variables
/// @param[in] pszPath : the pathname of the file or directory
/// @param[in] u32Name : variable in <limits.h> to be queried relative to that file or directory
/// @return current variable value for the file or directory
/// @return -1 : errno set to indicate the error
/// @note equivalent to MI_FS_FPathConf
//------------------------------------------------------------------------------
MI_S32 MI_FS_PathConfig(const MI_U8 *pszPath, MI_U32 u32Name);

//------------------------------------------------------------------------------
/// @brief Get configurable pathname variables
/// @param[in] pszPath : the file descriptor associated with the file
/// @param[in] u32Name : variable in <limits.h> to be queried relative to that file or directory
/// @return current variable value for the file or directory
/// @return -1 : errno set to indicate the error
/// @note equivalent to MI_FS_PathConf
//------------------------------------------------------------------------------
MI_S32 MI_FS_FpathConfig(MI_U32 u32Fd, MI_U32 u32Name);

//------------------------------------------------------------------------------
/// @brief Determine the accessibility of a file
/// @param[in] pszPath : the pathname of the file or directory
/// @param[in] u32AccessMode : the accessibility bit pattern: only existence test F_OK currently
/// @return 0: the requested access is permitted
/// @return -1 : errno set to indicate the error
/// @note equivalent to MI_FS_PathConf
//------------------------------------------------------------------------------
MI_S32 MI_FS_Access(const MI_U8 *pszPath, MI_U32 u32AccessMode);

//------------------------------------------------------------------------------
/// @brief Get the pathname of the current working directory
/// @param[in] pszPath : points to the buffer stored the absolute pathname of the current working directory
/// @param[in] u32Size : the buffer size
/// @return buf argument
/// @return null : errno set to indicate the error
//------------------------------------------------------------------------------
MI_U8 *MI_FS_GetCwd(const MI_U8 *pszPath, MI_U32 u32Size);

//------------------------------------------------------------------------------
/// @brief Open a directory stream for reading
/// @param[in] pszDirName : the pathname of the directory
/// @return a pointer to DIR object
/// @return null : errno set to indicate the error.
/// @note   The directory stream (an ordered sequence of all the directory entries in a particular directory)
///             is positioned at the first directory entry
//------------------------------------------------------------------------------
DIR *MI_FS_OpenDir(const MI_U8 *pszDirName);

//------------------------------------------------------------------------------
/// @brief Read a directory entry
/// @param[in] pstDir : a pointer to DIR object
/// @return a pointer to dirent structure representing the directory entry at the current position in the directory
/// @return null : errno set to indicate the error
//------------------------------------------------------------------------------
struct dirent* MI_FS_ReadDir(DIR *pstDir);

//------------------------------------------------------------------------------
/// @brief Reset the position of a directory stream to the beginning of a directory
/// @param[in] pstDir : a pointer to DIR object
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
//------------------------------------------------------------------------------
MI_RESULT MI_FS_RewindDir(DIR *pstDir);

//------------------------------------------------------------------------------
/// @brief Close a directory stream
/// @param[in] pstDir : a pointer to DIR object
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
//------------------------------------------------------------------------------
MI_RESULT MI_FS_CloseDir(DIR *pstDir);

//------------------------------------------------------------------------------
/// @brief Read from a file
/// @param[in] u32Fd : the file descriptor associated with the file
/// @param[out] pBuffer : read buffer
/// @param[in] u32Length : number of bytes to be read
/// @return number of bytes actually read
/// @return -1 : errno set to indicate the error
/// @note   Standard C Library's counterparts: \n
///         - fread()   is equivalent to    read();
//------------------------------------------------------------------------------
MI_S32 MI_FS_Read(MI_U32 u32Fd, void *pBuffer, MI_U32 u32Length);

//------------------------------------------------------------------------------
/// @brief Write to a file
/// @param[in] u32Fd : the file descriptor associated with the file
/// @param[in] pBuffer : write buffer
/// @param[in] u32Length : number of bytes to be written
/// @return number of bytes actually written
/// @return -1 : errno set to indicate the error
/// @note   Standard C Library's counterparts: \n
///         - fwrite()  is equivalent to    write();
//------------------------------------------------------------------------------
MI_S32 MI_FS_Write(MI_U32 u32Fd, const void *pBuffer, MI_U32 u32Length);

//------------------------------------------------------------------------------
/// @brief Close a file
/// @param[in] u32Fd : the file descriptor associated with the file
/// @return 0 : succeed
/// @return -1 : errno set to indicate the error
/// @note   Standard C Library's counterparts: \n
///         - fclose()  is equivalent to    close();
//------------------------------------------------------------------------------
MI_S32 MI_FS_Close(MI_U32 u32Fd);

//------------------------------------------------------------------------------
/// @brief Seek a file
/// @param[in] u32Fd : the file descriptor associated with the file
/// @param[in] u64Position : file byte offset relative to whence
/// @param[in] u32Whence : SEEK_SET / SEEK_CUR / SEEK_END
/// @return byte offset from the beginning of the file
/// @return -1 : errno set to indicate the error
/// @note   Standard C Library's counterparts: \n
///         - fseek()   is equivalent to    lseek();    except the return value \n
///         - rewind()  is equivalent to    lseek(fd, 0, SEEK_SET); \n
///         - ftell()   is equivalent to    lseek(fd, 0, SEEK_CUR); \n
//------------------------------------------------------------------------------
MI_S64 MI_FS_Lseek(MI_U32 u32Fd, MI_U64 u64Position, MI_U32 u32Whence);

//------------------------------------------------------------------------------
/// @brief File control
/// @param[in] u32Fd : the file descriptor associated with the file
/// @param[in] u32Command : only F_DUPFD currently
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Fcntl(MI_U32 u32Fd, MI_U32 u32Command);

//------------------------------------------------------------------------------
/// @brief Synchronize changes to a file (all data for the open file will be transferred to the storage device)
/// @param[in] u32Fd : the file descriptor associated with the file
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Fsync(MI_U32 u32Fd);

//------------------------------------------------------------------------------
/// @brief Synchronize changes to a file (all data for the open file will be transferred to the storage device)
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Sync(void);

//------------------------------------------------------------------------------
/// @brief Open a file
/// @param[in] pszFileName : the pathname of the file
/// @param[in] pu8Mode :  r or rb - Open file for reading.
///                         w or wb - Truncate to zero length or create file for writing.
///                         a or ab - Append; open or create file for writing at end-of-file.
///                         r+ or rb+ or r+b - Open file for update (reading and writing).
///                         w+ or wb+ or w+b - Truncate to zero length or create file for update.
///                         a+ or ab+ or a+b Append; open or create file for update, writing at end-of-file.
/// @return the file descriptor associated with the file
/// @return NULL : errno set to indicate the error
/// @note   The maximum number of open files allowed is determined by the CYGNUM_FILEIO_NFILE
//------------------------------------------------------------------------------
FILE *MI_FS_Fopen(const MI_U8 *pszFileName, const MI_U8 *pu8Mode);

//------------------------------------------------------------------------------
/// @brief Read from a file
/// @param[in] pstStream : the file descriptor associated with the file
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Fclose(FILE *pstStream);

//------------------------------------------------------------------------------
/// @brief Read from a file
/// @param[out] pData : read buffer
/// @param[in] u32ItemSize : item size in bytes
/// @param[in] u32NumItems : number of items
/// @param[in] pststream : the file descriptor associated with the file
/// @return number of items actually read
/// @return -1 : errno set to indicate the error
//------------------------------------------------------------------------------
MI_S32 MI_FS_Fread(void *pData, MI_U32 u32ItemSize, MI_U32 u32NumItems, FILE *pstStream);


//------------------------------------------------------------------------------
/// @brief Write to a file
/// @param[in] pData : write buffer
/// @param[in] u32ItemSize : item size in bytes
/// @param[in] u32NumItems : number of items
/// @param[in] pststream : the file descriptor associated with the file
/// @return number of items actually written
/// @return -1 : errno set to indicate the error
//------------------------------------------------------------------------------
MI_S32 MI_FS_Fwrite(const void *pData, MI_U32 u32ItemSize, MI_U32 u32NumItems, FILE *pstStream);

//------------------------------------------------------------------------------
/// @brief Seek a file
/// @param[in] pstStream : the file descriptor associated with the file
/// @param[in] u64Position : file byte offset relative to whence
/// @param[in] u32Whence : SEEK_SET / SEEK_CUR / SEEK_END
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Fseek(FILE *pstStream, MI_U64 u64Position, MI_U32 u32Whence);

//------------------------------------------------------------------------------
/// @brief Reset the file position
/// @param[in] pstStream : the file descriptor associated with the file
/// @return NONE
//------------------------------------------------------------------------------
void MI_FS_Rewind(FILE *pstStream);

//------------------------------------------------------------------------------
/// @brief Obtain current file position
/// @param[in] pstStream : the file descriptor associated with the file
/// @return current file position measured in bytes from the beginning of the file
/// @return -1 : errno set to indicate the error
//------------------------------------------------------------------------------
MI_S32 MI_FS_Ftell(FILE *pstStream);

//------------------------------------------------------------------------------
/// @brief Obtain current file position
/// @param[in] pstStream : the file descriptor associated with the file
/// @return current file position measured in bytes from the beginning of the file
//------------------------------------------------------------------------------
MI_U64 MI_FS_Ftell64(FILE *pstStream);

//------------------------------------------------------------------------------
/// @brief Flushes a stream.
/// @param[in] pstStream : the file descriptor associated with the file
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_Fflush(FILE *pstStream);

//------------------------------------------------------------------------------
/// @brief Get FS information
/// @param[in] pszPath :  the pathname of the file or directory
/// @param[out] pstFsInfoParams :  the parameters of FS INFO
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_GetInfo(const MI_U8 *pszPath, MI_FS_InfoParams_t* pstFsInfoParams);

//------------------------------------------------------------------------------
/// @brief Get attribute from FS
/// @param[in] eAttrType : Attribute type
/// @param[out] pOutputParams : result for user to get
/// @return MI_OK: Process success
/// @return MI_ERR_NOT_INITED : Module is not initialized
/// @return MI_ERR_INVALID_PARAMETER : Parameter is incorrect
/// @return MI_ERR_FAILED : Process failure
//------------------------------------------------------------------------------
MI_RESULT MI_FS_GetAttr(MI_FS_AttrType_e eAttrType, void *pOutputParams);

//------------------------------------------------------------------------------
/// @brief Set debug level.
/// @param[in] u32DebugLevel: Debug level
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_FS_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

#ifdef __cplusplus
}
#endif

#endif///_MI_FS_H_

