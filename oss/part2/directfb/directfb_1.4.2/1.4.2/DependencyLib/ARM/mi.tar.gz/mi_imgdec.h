/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/
#if (MI_IMGDEC_FEATURE_ENABLE == 1)

#ifndef _MI_IMGDEC_H_
#define _MI_IMGDEC_H_

#ifdef __cplusplus
extern "C" {
#endif

typedef enum
{
    E_MI_IMGDEC_COLOR_FMT_I1                     = 0x0,
    E_MI_IMGDEC_COLOR_FMT_I2                     ,
    E_MI_IMGDEC_COLOR_FMT_I4                     ,
    E_MI_IMGDEC_COLOR_FMT_I8                     ,
    E_MI_IMGDEC_COLOR_FMT_RGB565                 ,
    E_MI_IMGDEC_COLOR_FMT_ARGB1555               ,
    E_MI_IMGDEC_COLOR_FMT_ARGB4444               ,
    E_MI_IMGDEC_COLOR_FMT_YUV422                 ,
    E_MI_IMGDEC_COLOR_FMT_ARGB8888               ,
    E_MI_IMGDEC_COLOR_FMT_GENERIC                ,
} MI_IMGDEC_ColorFmt_e;

typedef enum
{
    E_MI_IMGDEC_STATUS_STOP,
    E_MI_IMGDEC_STATUS_DECODE_OK,
    E_MI_IMGDEC_STATUS_DECODING,
    E_MI_IMGDEC_STATUS_DECODE_ERR,
    E_MI_IMGDEC_STATUS_DRAW,
    E_MI_IMGDEC_STATUS_READY_TO_DECODE,
    E_MI_IMGDEC_STATUS_RELEASE_FRAME,
    E_MI_IMGDEC_STATUS_NULL,
} MI_IMGDEC_Status_e;

typedef enum
{
    E_MI_IMGDEC_FORMAT_JPEG = 0x0000d8ff,
    E_MI_IMGDEC_FORMAT_PNG = 0x004e5000,
    E_MI_IMGDEC_FORMAT_GIF = 0x00464947,
    E_MI_IMGDEC_FORMAT_BMP = 0x00004D42,
    E_MI_IMGDEC_FORMAT_UNSUPPORT = 0xffffffff,
}MI_IMGDEC_Format_e;

typedef enum
{
    E_MI_IMGDEC_SOURCE_TYPE_INVALID = -1,
    E_MI_IMGDEC_SOURCE_TYPE_FILE,              //for local file
    E_MI_IMGDEC_SOURCE_TYPE_DIRECTMEM,         // for direct memory input
} MI_IMGDEC_SourceType_e;

typedef struct MI_IMGDEC_PlayInfo_s
{
    void *pstGifDecodeThreadParams; //pointer to decode parameters, defined in mi_imgdec.c
} MI_IMGDEC_PlayInfo_t;

typedef enum
{
    E_MI_IMGDEC_JPEG_DECODE_TYPE_MAIN_DECODE      = 1,
    E_MI_IMGDEC_JPEG_DECODE_TYPE_THUMBNAIL_DECODE    ,
} MI_IMGDEC_JpegDecodeType_e;

typedef void* MI_IMGDEC_WriteStreamCallback; //reserved

typedef struct MI_IMGDEC_MemoryLayout_s
{
    MI_PHY phyImgDecReadBufAddr;
    MI_U32 u32ImgDecReadBufSize;
    MI_PHY phyImgDecInterBufAddr;
    MI_U32 u32ImgDecInterBufSize;
    MI_PHY phyImgDecOutBufAddr;
    MI_U32 u32ImgDecOutBufSize;
} MI_IMGDEC_MemoryLayout_t;

typedef struct MI_IMGDEC_DecodeMode_s
{
    MI_BOOL bNonBlocking;
    MI_BOOL bGifCoBufferWithStillImage;
} MI_IMGDEC_DecodeMode_t;

typedef struct MI_IMGDEC_OpenParams_s
{
    MI_U32 u32ImgSize;
    MI_IMGDEC_Format_e eImgType; //MI_IMG used
    MI_IMGDEC_SourceType_e eFileOption;

    union
    {
        MI_U8* pszFileName;
        MI_VIRT virtReadMemAddr;
    };

    MI_BOOL bOnlyDecodeFirstFrame; //GIF used

    MI_IMGDEC_MemoryLayout_t stImgdecMemoryLayout;
    MI_U32 u32GifObjectNum;
    MI_IMGDEC_DecodeMode_t stDecodeMode;

} MI_IMGDEC_OpenParams_t;

typedef struct MI_IMGDEC_StartParams_s
{
    MI_U8 u8Reserved;  //Reserved
} MI_IMGDEC_StartParams_t;

typedef enum
{
    E_MI_IMGDEC_COMMAND_TYPE_INVALID = -1,
    E_MI_IMGDEC_COMMAND_TYPE_NONE,
    E_MI_IMGDEC_COMMAND_TYPE_NOTIFY,     //chakra will notify AP EN_MPLAYER_NOTIFY_TYPE, when something happen in movie playing
    E_MI_IMGDEC_COMMAND_TYPE_READDATA,
} MI_IMGDEC_CommandType_e;

//typedef void (*MI_IMGDEC_CmdCallback)(MI_IMGDEC_CommandType_e eCmd, MI_U32 u32Param, MI_U32 u32Info);
typedef MI_RESULT (*MI_IMGDEC_EventCallback)(MI_HANDLE hImgdec, MI_U32 u32Event, void *pEventParams, void *pUserParams);

typedef struct MI_IMGDEC_CallbackInputParams_s
{
    MI_U64 u64CallbackId;                     ///[IN]: Use 0 for first register, other valid value(returned by MI_IMGDEC_CallbackOutputParams_t) for update callback event.
    MI_IMGDEC_EventCallback pfEventCallback;      ///[IN]: Registered events MI_TSMUX_Event_e which are bitwise OR operation.
    MI_U32 u32EventFlags;                   ///[IN]: Event callback function pointer.
    void *pUserParams;                       ///[IN]: For passing user-defined parameters.
} MI_IMGDEC_CallbackInputParams_t;

typedef struct MI_IMGDEC_CallbackOutputParams_s
{
    MI_U64 u64CallbackId;                           ///[OUT]: the returned ID for update or unregister callback.
} MI_IMGDEC_CallbackOutputParams_t;

typedef struct MI_IMGDEC_InitParams_s
{
    MI_U8 u8Reserved;
} MI_IMGDEC_InitParams_t;

typedef struct MI_IMGDEC_Info_s
{
    MI_U8 u8Reserved;
} MI_IMGDEC_Info_t;

typedef struct MI_IMGDEC_PhotoInfo_s
{
    MI_U32 u32PhotoOutputWidth;
    MI_U32 u32PhotoOutputHeight;
    MI_U32 u32PhotoOutputPitch;
    MI_BOOL bIsProgressive;
    MI_U32 u32PhotoSourceWidth;
    MI_U32 u32PhotoSourceHeight;
    MI_IMGDEC_Format_e ePhotoType;
    MI_IMGDEC_ColorFmt_e eOuputFormat;

//---Gif used
    MI_U32 u32OutputDelayTime;
    MI_U32 u32FrameCount;
    MI_U32 u32CurrentIndx;
    MI_U8 u8BackgroundIndex;
    MI_U8 u8BackgroundColorRed;
    MI_U8 u8BackgroundColorGreen;
    MI_U8 u8BackgroundColorBlue;
//------------
}MI_IMGDEC_PhotoInfo_t;

typedef struct MI_IMGDEC_BufAddr_s
{
    MI_VIRT virtJpdReadBufAddr;
    MI_VIRT virtJpdInterBufAddr;
    MI_VIRT virtJpdOutBufAddr;
}MI_IMGDEC_BufAddr_t;

typedef struct MI_IMGDEC_EventQueueMsg_s
{
    MI_HANDLE hImgdec;
    MI_U32 u32ThreadIndex;
    MI_IMGDEC_Status_e eState;
    MI_U32 u32FrameIndex;
} MI_IMGDEC_EventQueueMsg_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Initialize IMGDEC
/// @param[in] pstInitParams Initial parameters.
/// @return MI_ERR_FAILED: Process failed.
/// @return MI_ERR_INVALID_HANDLE: IMGDEC has already inited.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_Init(const MI_IMGDEC_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Deinitialize IMGDEC
/// @param[in] None.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Create a handler for IMG used
/// @param[in] *pstOpenParams IMGDEC descriptor.
/// @param[out] *phImgdec IMGDEC handler.
/// @return MI_ERR_NOT_SUPPORT: Unsupport format.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_Open(const MI_IMGDEC_OpenParams_t *pstOpenParams, MI_HANDLE *phImgdec);

//------------------------------------------------------------------------------
/// @brief Clear the IMG handler
/// @param[in] hImgDec IMGDEC handler.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_Close(MI_HANDLE hImgdec);

//------------------------------------------------------------------------------
/// @brief N/A(Reserved function)
/// @param[in] hImgdec IMGDEC handler.
/// @param[in] *pstarStartParams start descriptor
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_SUPPORT: Not support
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_Start(MI_HANDLE hImgdec,const MI_IMGDEC_StartParams_t *pstStartParams);

//------------------------------------------------------------------------------
/// @brief Clear the buffer & global variable
/// @param[in] hImgdec IMGDEC handler.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_Stop(MI_HANDLE hImgdec);

//------------------------------------------------------------------------------
/// @brief Get output buffer address for decoded data
/// @param[in] phImgdec IMGDEC handler.
/// @param[out] *pePhotoDecoderStatus IMG decoder status.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Unsupport handler.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_GetStatus(MI_HANDLE hImgdec, MI_IMGDEC_Status_e *pePhotoDecoderStatus);

//------------------------------------------------------------------------------
/// @brief Get output buffer address for decoded data
/// @param[in] stImgPlayInfo information for IMG decode.
/// @param[in] hImgdec IMGDEC handler.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Need to initialize IMGDEC firstly.
/// @return MI_ERR_NOT_SUPPORT: Unsupport format.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_Decode(MI_HANDLE hImgdec, MI_IMGDEC_PlayInfo_t stImgPlayInfo);

//------------------------------------------------------------------------------
/// @brief Get Photo information from IMGDEC
/// @param[in] hImgdec IMGDEC handler.
/// @param[in] stInputInfo Input information
/// @param[out] *pstPhotoInfo Photo information
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_HANDLE: Unsupport handler.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_GetPhotoInfo(MI_HANDLE hImgdec, MI_IMGDEC_Info_t *pstInputInfo ,MI_IMGDEC_PhotoInfo_t *pstPhotoInfo);


//------------------------------------------------------------------------------
/// @brief Get buffer address by frame
/// @param[in] hImgdec IMGDEC hadler.
/// @param[in] u32Frame number of frame.
/// @param[out] pvirtOutAddr: address of output buffer.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_GetFrame(MI_HANDLE hImgdec, MI_U32 u32Frame, MI_VIRT *pvirtOutAddr);

//------------------------------------------------------------------------------
/// @brief set debug level for IMGDEC
/// @param[in] u32DebugLevel debug level.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief delete all GIF cache buffer.
/// @param[in] None.
/// @return MI_ERR_FAILED: Process failed.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_DestoryGifObject(void);

//------------------------------------------------------------------------------
/// @brief release the handled frame to decode next.
/// @param[in] hImgdec IMGDEC handler.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_ReleaseGifFrame(MI_HANDLE hImgdec);

//------------------------------------------------------------------------------
/// @brief Clear the Ouput Buffer for black screen.
/// @param[in] hImgdec IMGDEC handler.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_ClearBuffer(MI_HANDLE hImgdec);

//------------------------------------------------------------------------------
/// @brief Register callback function to get key code
/// @param[in] hImgdec: The IMGDEC handle to close
/// @param[in] pstInputParams: Paramters for callback function
/// @param[in] pstOutputParams: Paramters for getting callback id
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_RegisterCallback(MI_HANDLE hImgdec, const MI_IMGDEC_CallbackInputParams_t *pstInputParams, MI_IMGDEC_CallbackOutputParams_t *pstOutputParams);

//------------------------------------------------------------------------------
/// @brief Register callback function to get key code
/// @param[in] hImgdec: The IMGDEC handle to close
/// @param[in] pstInputParams: Paramters to unregister callback
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: Module not inted.
/// @return MI_ERR_INVALID_PARAMETER: parameter error.
/// @return MI_ERR_INVALID_HANDLE: handle error.
/// @sa
/// @note
//------------------------------------------------------------------------------
MI_RESULT MI_IMGDEC_UnRegisterCallback(MI_HANDLE hImgdec, const MI_IMGDEC_CallbackInputParams_t *pstInputParams);


#ifdef __cplusplus
}
#endif

#endif
#endif //#if (MI_IMGDEC_FEATURE_ENABLE == 1)
