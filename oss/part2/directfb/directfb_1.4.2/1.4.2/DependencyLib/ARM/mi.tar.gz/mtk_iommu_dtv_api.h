#ifndef _MTK_IOMMU_DTV_API_H_
#define _MTK_IOMMU_DTV_API_H_


#include <linux/ioctl.h>
#include <linux/types.h>

#define MAX_NAME_SIZE	16
#define UUID_SIZE		16
#define MAX_TAG_NUM     8

#define MDIOMMU_DEV_NAME "/dev/iommu_mtkd"
#define IOVA_START_ADDR (0x200000000ULL)
#define IOVA_END_ADDR   (0x400000000ULL)

#define IOMMUMD_FLAG_NOMAPIOVA   (1 <<16) //allocate buffer without iova right now,but iova will be allocated backgrouud
#define IOMMUMD_FLAG_2XIOVA      (1 <<17) //allocate buffer with double iova size

struct mdiommu_ioc_data{
	unsigned int flag;
	unsigned long long addr;
	unsigned int len;
	int fd;
	unsigned int pipelineid;
	unsigned long long va;
	int status;
	unsigned int dmabuf_id;
};

struct mdiommu_reserve_iova {
	char space_tag[MAX_NAME_SIZE];
	unsigned int buf_tag_array[MAX_TAG_NUM];
	unsigned long long base_addr; //return start address
	unsigned int size; //reserve size
	unsigned int buf_tag_num;
};

#define MDIOMMU_IOC_MAGIC  'M'
#define MDIOMMU_IOC_SUPPORT             _IOWR(MDIOMMU_IOC_MAGIC, 0, int)
#define MDIOMMU_IOC_QUERY_BUFTAG        _IOWR(MDIOMMU_IOC_MAGIC, 1, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_RESERVE_IOVA        _IOWR(MDIOMMU_IOC_MAGIC, 2, struct mdiommu_reserve_iova)
#define MDIOMMU_IOC_FREE_IOVA           _IOWR(MDIOMMU_IOC_MAGIC, 3, struct mdiommu_reserve_iova)
#define MDIOMMU_IOC_ALLOC               _IOWR(MDIOMMU_IOC_MAGIC, 4, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_ALLOCPIPELINEID     _IOWR(MDIOMMU_IOC_MAGIC, 5, unsigned int)
#define MDIOMMU_IOC_FREEPIPELINEID      _IOWR(MDIOMMU_IOC_MAGIC, 6, unsigned int)
#define MDIOMMU_IOC_AUTHORIZE           _IOWR(MDIOMMU_IOC_MAGIC, 7, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_UNAUTHORIZE         _IOWR(MDIOMMU_IOC_MAGIC, 8, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_GETIOVA             _IOWR(MDIOMMU_IOC_MAGIC, 9, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_RESIZE              _IOWR(MDIOMMU_IOC_MAGIC, 10, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_FLUSH				_IOWR(MDIOMMU_IOC_MAGIC, 11, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_VA2IOVA				_IOWR(MDIOMMU_IOC_MAGIC, 12, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_TEST                _IOWR(MDIOMMU_IOC_MAGIC, 13, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_SHARE		_IOWR(MDIOMMU_IOC_MAGIC, 14, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_GETFD		_IOWR(MDIOMMU_IOC_MAGIC, 15, struct mdiommu_ioc_data)
#define MDIOMMU_IOC_DELETE		_IOW(MDIOMMU_IOC_MAGIC, 16, struct mdiommu_ioc_data)

#endif
