/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

///////////////////////////////////////////////////////////////////////////////////////////////////
/// @file    mi_common.h
/// @brief The common interface definition
/// @author MediaTek Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////

//-------------------------------------------------------------------------------------------------
//  Include Files
//-------------------------------------------------------------------------------------------------
#ifndef _MI_COMMON_H_
#define _MI_COMMON_H_
#ifdef MSOS_TYPE_LINUX_KERNEL
#include <linux/slab.h>
#include <linux/delay.h>
#include <linux/kthread.h>
#include <linux/module.h>  // Needed by all modules
#include <linux/kernel.h>  // Needed for KERN_INFO
#include <linux/fs.h>      // Needed by filp
#else
#include <stdio.h>
#include <stdlib.h>
#endif
//-------------------------------------------------------------------------------------------------
//  System Data Type
//-------------------------------------------------------------------------------------------------
/// data type unsigned char, data length 1 byte
typedef unsigned char                                   MI_U8;      ///< 1 byte
/// data type unsigned short, data length 2 byte
typedef unsigned short                                  MI_U16;     ///< 2 bytes
/// data type unsigned int, data length 4 byte
typedef unsigned int                                    MI_U32;     ///< 4 bytes
/// data type unsigned int, data length 8 byte
typedef unsigned long long                              MI_U64;     ///< 8 bytes
/// data type signed char, data length 1 byte
typedef signed char                                     MI_S8;      ///< 1 byte
/// data type signed short, data length 2 byte
typedef signed short                                    MI_S16;     ///< 2 bytes
/// data type signed int, data length 4 byte
typedef signed int                                      MI_S32;     ///< 4 bytes
/// data type signed int, data length 8 byte
typedef signed long long                                MI_S64;     ///< 8 bytes

/// data type virtual address
typedef MI_U64                                          MI_VIRT;    ///< 8 bytes
/// date type physical address
typedef MI_U64                                          MI_PHY;     ///< 8 bytes

/// data type unsigned int, data length 4 byte
typedef unsigned int                                    MI_UINT;    ///< 4 bytes

/// date type size_t
typedef size_t                                          MI_SIZE;

/// data type null pointer
#ifdef NULL
#undef NULL
#endif
#define NULL                                            0

//-------------------------------------------------------------------------------------------------
//  Software Data Type
//-------------------------------------------------------------------------------------------------
/// definition for MI_BOOL
typedef unsigned char                                   MI_BOOL;
typedef MI_S32                                          MI_HANDLE;

#ifndef true
/// definition for true
#define true                                            1
/// definition for false
#define false                                           0
#endif

#if !defined(TRUE) && !defined(FALSE)
/// definition for TRUE
#define TRUE                                            1
/// definition for FALSE
#define FALSE                                           0
#endif

#ifdef __cplusplus
extern "C" {
#endif

#if (MI_OS_WRAPPER_PRINTF == 1)
#if (!defined MSOS_TYPE_LINUX_KERNEL) && (!defined MSOS_TYPE_ECOS) && (!defined MI_PACKAGE_AN)
#undef printf
extern void MI_OS_Printk(MI_U8 *pszString, ...);
#define printf(format, args...) MI_OS_Printk((MI_U8 *)format, ##args)
#endif
#endif

#ifdef __cplusplus
}
#endif
//-------------------------------------------------------------------------------------------------
//  Defines - Constant
//-------------------------------------------------------------------------------------------------
#define MI_HANDLE_NULL                                  (0)
#define MI_INVALID_PTS                                  ((MI_U64)-1)

///MI Resule and error code definitions
#define MI_RESULT                                       MI_U32
#define MI_OK                                           0x0     ///< succeeded
#define MI_CONTINUE                                     0x1     ///< not error but hasn' be succeeded. Flow is continue...
#define MI_HAS_INITED                                   0x2     ///< not error but init has be called again
#define MI_ERR_FAILED                                   0x3     ///< general failed
#define MI_ERR_NOT_INITED                               0x4     ///< moudle hasn't be inited
#define MI_ERR_NOT_SUPPORT                              0x5     ///< not supported
#define MI_ERR_NOT_IMPLEMENT                            0x6     ///< not implemented
#define MI_ERR_INVALID_HANDLE                           0x7     ///< invalid handle
#define MI_ERR_INVALID_PARAMETER                        0x8     ///< invalid parameter
#define MI_ERR_RESOURCES                                0x9     ///< system resource issue
#define MI_ERR_MEMORY_ALLOCATE                          0xa     ///< memory allocation
#define MI_ERR_CHAOS                                    0xb     ///< chaos state-mechine
#define MI_ERR_DATA_ERROR                               0xc     ///< data error
#define MI_ERR_TIMEOUT                                  0xd     ///< timeout
#define MI_ERR_LIMITION                                 0xe     ///< limitation
#define MI_ERR_BUSY                                     0xf     ///< the required operation can not be done due to current system is busy.

#define MI_ERR_OSD_BASE                                 0x100
#define MI_ERR_OSD_REARRANGE_ALIGNMENT                  MI_ERR_OSD_BASE     ///< OSD: this chip is bus alignment for GE engine. Need to re-attange alignment.
#define MI_ERR_MAX                                      (MI_ERR_OSD_BASE+1) ///< maximum value of MI_RESULT

//MI_DBG_LEVEL
#define    MI_DBG_LEVEL                                 MI_U32
#define    MI_DBG_NONE                                  0
#define    MI_DBG_FATAL                                 0x10
#define    MI_DBG_ERR                                   0x20
#define    MI_DBG_WRN                                   0x30
#define    MI_DBG_INFO                                  0x40
#define    MI_DBG_TRACE                                 0x50
#define    MI_DBG_ALL                                   0xF0
#define    MI_DBG_DRV_ERR                               (1 << 8)
#define    MI_DBG_DRV_WRN                               (2 << 8)
#define    MI_DBG_DRV_INFO                              (3 << 8)
#define    MI_DBG_DRV_ALL                               (4 << 8)
#define    MI_DBG_FW                                    (1 << 16)
#define    MI_DBG_KDRV_WRAPPER_ERR                      (1 << 24)
#define    MI_DBG_KDRV_WRAPPER_WRN                      (2 << 24)
#define    MI_DBG_KDRV_WRAPPER_INFO                     (3 << 24)
#define    MI_DBG_KDRV_WRAPPER_ALL                      (4 << 24)

/// For MI module connection use
#define MI_MODULE_TYPE_NONE                             0x00    ///< Not defined
#define MI_MODULE_TYPE_ACAP                             0x12    ///< MI_ACAP
#define MI_MODULE_TYPE_AEXTIN                           0X14    ///< MI_AEXTIN
#define MI_MODULE_TYPE_AOUT                             0x17    ///< MI_AOUT
#define MI_MODULE_TYPE_AUDIO                            0x19    ///< MI_AUDIO
#define MI_MODULE_TYPE_CAP                              0x21    ///< MI_CAP
#define MI_MODULE_TYPE_DISP                             0x36    ///< MI_DISP
#define MI_MODULE_TYPE_EXTIN                            0x43    ///< MI_EXTIN
#define MI_MODULE_TYPE_PCM                              0x81    ///< MI_PCM
#define MI_MODULE_TYPE_TSIO                             0xAB    ///< MI_TSIO
#define MI_MODULE_TYPE_TUNER                            0xAE    ///< MI_TUNER
#define MI_MODULE_TYPE_VIDEO                            0Xc7    ///< MI_VIDEO
#define MI_MODULE_TYPE_PCMCIA                           0X82    ///< MI_PCMCIA

///ASCII color code
#define ASCII_COLOR_BLACK                               "\033[30m"
#define ASCII_COLOR_DARK_RED                            "\033[31m"
#define ASCII_COLOR_DARK_GREEN                          "\033[32m"
#define ASCII_COLOR_BROWN                               "\033[33m"
#define ASCII_COLOR_DARK_BLUE                           "\033[34m"
#define ASCII_COLOR_DARK_PURPLE                         "\033[35m"
#define ASCII_COLOR_DARK_CYAN                           "\033[36m"
#define ASCII_COLOR_GRAY                                "\033[37m"
#define ASCII_COLOR_DARK_GRAY                           "\033[1;30m"
#define ASCII_COLOR_RED                                 "\033[1;31m"
#define ASCII_COLOR_GREEN                               "\033[1;32m"
#define ASCII_COLOR_YELLOW                              "\033[1;33m"
#define ASCII_COLOR_BLUE                                "\033[1;34m"
#define ASCII_COLOR_PURPLE                              "\033[1;35m"
#define ASCII_COLOR_CYAN                                "\033[1;36m"
#define ASCII_COLOR_WHITE                               "\033[1;37m"
#define ASCII_COLOR_INVERSE_BLACK                       "\033[1;7;30m"
#define ASCII_COLOR_INVERSE_RED                         "\033[1;7;31m"
#define ASCII_COLOR_INVERSE_GREEN                       "\033[1;7;32m"
#define ASCII_COLOR_INVERSE_YELLOW                      "\033[1;7;33m"
#define ASCII_COLOR_INVERSE_BLUE                        "\033[1;7;34m"
#define ASCII_COLOR_INVERSE_PURPLE                      "\033[1;7;35m"
#define ASCII_COLOR_INVERSE_CYAN                        "\033[1;7;36m"
#define ASCII_COLOR_INVERSE_WHITE                       "\033[1;7;37m"
#define ASCII_COLOR_END                                 "\033[0m"

//Handle string length
#define  MI_MODULE_HANDLE_NAME_LENGTH_MAX 64

//-------------------------------------------------------------------------------------------------
//  Defines - Macros
//-------------------------------------------------------------------------------------------------
#define MI_ADDR_CAST(t)                                 (t)(size_t)
#define MI_BIT(_bit_)                                   (1 << (_bit_))

#ifndef MI_MEM_ALIGN
#define MI_MEM_ALIGN(align, address)                    ((((address)+(align)-1)/(align))*(align))
#endif

#ifndef MI_LOW_MEM_ALIGN
#define MI_LOW_MEM_ALIGN(align, address)                (((address)/(align))*(align))
#endif

#if (MI_ENABLE_DBG == 1)
#ifndef MI_PACKAGE_AN
#ifndef MSOS_TYPE_LINUX_KERNEL
// mdules who want to use MI_INFO for debugging should define DBG_LEVEL by itself.
#define MI_PRINT(fmt, args...)              ({do{printf(fmt, ##args);}while(0);})
#define MI_INFO(fmt, args...)               ({do{if(DBG_LEVEL>=MI_DBG_INFO){printf(ASCII_COLOR_GREEN);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})
#define MI_WRN(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_WRN){printf(ASCII_COLOR_YELLOW);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})
#define MI_ERR(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf(ASCII_COLOR_RED"%s[%d]: ", __FUNCTION__,__LINE__);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})
#define MI_ENTER()                          ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf(ASCII_COLOR_PURPLE">>>%s[%d] \n",__FUNCTION__,__LINE__);printf(ASCII_COLOR_END);}}while(0);})
#define MI_EXIT_OK()                        ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf(ASCII_COLOR_PURPLE"<<<%s[%d] \n",__FUNCTION__,__LINE__);printf(ASCII_COLOR_END);}}while(0);})
#define MI_EXIT_ERR(fmt, args...)           ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf(ASCII_COLOR_RED"<<<%s[%d] ",__FUNCTION__,__LINE__);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})

#define MI_WRAPPER_INFO(fmt, args...)       ({do{if(DBG_LEVEL>=MI_DBG_INFO){printf(ASCII_COLOR_GREEN);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})
#define MI_WRAPPER_WRN(fmt, args...)        ({do{if(DBG_LEVEL>=MI_DBG_WRN){printf(ASCII_COLOR_YELLOW);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})
#define MI_WRAPPER_ERR(fmt, args...)        ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf(ASCII_COLOR_RED"%s[%d]: ", __FUNCTION__,__LINE__);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})
#define MI_WRAPPER_ENTER()                  ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf(ASCII_COLOR_PURPLE">>>%s[%d] \n",__FUNCTION__,__LINE__);printf(ASCII_COLOR_END);}}while(0);})
#define MI_WRAPPER_EXIT_OK()                ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf(ASCII_COLOR_PURPLE"<<<%s[%d] \n",__FUNCTION__,__LINE__);printf(ASCII_COLOR_END);}}while(0);})
#define MI_WRAPPER_EXIT_ERR(fmt, args...)   ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf(ASCII_COLOR_RED"<<<%s[%d] ",__FUNCTION__,__LINE__);printf(fmt, ##args);printf(ASCII_COLOR_END);}}while(0);})
#else
#define MI_PRINT(fmt, args...)              ({do{printk(fmt, ##args);}while(0);})
#define MI_INFO(fmt, args...)               ({do{if(DBG_LEVEL>=MI_DBG_INFO){printk(ASCII_COLOR_GREEN);printk(fmt, ##args);printk(ASCII_COLOR_END);}}while(0);})
#define MI_WRN(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_WRN){printk(ASCII_COLOR_YELLOW);printk(fmt, ##args);printk(ASCII_COLOR_END);}}while(0);})
#define MI_ERR(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_ERR){printk(ASCII_COLOR_RED"%s[%d]: ", __FUNCTION__,__LINE__);printk(fmt, ##args);printk(ASCII_COLOR_END);}}while(0);})
#define MI_ENTER()                          ({do{if(DBG_LEVEL>=MI_DBG_ALL){printk(ASCII_COLOR_PURPLE">>>%s[%d] \n",__FUNCTION__,__LINE__);printk(ASCII_COLOR_END);}}while(0);})
#define MI_EXIT_OK()                        ({do{if(DBG_LEVEL>=MI_DBG_ALL){printk(ASCII_COLOR_PURPLE"<<<%s[%d] \n",__FUNCTION__,__LINE__);printk(ASCII_COLOR_END);}}while(0);})
#define MI_EXIT_ERR(fmt, args...)           ({do{if(DBG_LEVEL>=MI_DBG_ERR){printk(ASCII_COLOR_RED"<<<%s[%d] ",__FUNCTION__,__LINE__);printk(fmt, ##args);printk(ASCII_COLOR_END);}}while(0);})

#endif

#else //MI_PACKAGE_AN
#ifndef MSOS_TYPE_LINUX_KERNEL
//mdules who want to use MI_INFO for debugging should define DBG_LEVEL by itself.
#define MI_PRINT(fmt, args...)              ({do{printf(fmt, ##args);}while(0);})
#define MI_INFO(fmt, args...)               ({do{if(DBG_LEVEL>=MI_DBG_INFO){printf(fmt, ##args);}}while(0);})
#define MI_WRN(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_WRN){printf(fmt, ##args);}}while(0);})
#define MI_ERR(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf("%s[%d]: " fmt, __FUNCTION__,__LINE__, ##args);}}while(0);})
#define MI_ENTER()                          ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf(">>>%s[%d] \n",__FUNCTION__,__LINE__);}}while(0);})
#define MI_EXIT_OK()                        ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf("<<<%s[%d] \n",__FUNCTION__,__LINE__);}}while(0);})
#define MI_EXIT_ERR(fmt, args...)           ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf("<<<%s[%d] " fmt,__FUNCTION__,__LINE__, ##args);}}while(0);})

#define MI_WRAPPER_INFO(fmt, args...)       ({do{if(DBG_LEVEL>=MI_DBG_INFO){printf(fmt, ##args);}}while(0);})
#define MI_WRAPPER_WRN(fmt, args...)        ({do{if(DBG_LEVEL>=MI_DBG_WRN){printf(fmt, ##args);}}while(0);})
#define MI_WRAPPER_ERR(fmt, args...)        ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf("%s[%d]: " fmt, __FUNCTION__,__LINE__, ##args);}}while(0);})
#define MI_WRAPPER_ENTER()                  ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf(">>>%s[%d] \n",__FUNCTION__,__LINE__);}}while(0);})
#define MI_WRAPPER_EXIT_OK()                ({do{if(DBG_LEVEL>=MI_DBG_ALL){printf("<<<%s[%d] \n",__FUNCTION__,__LINE__);}}while(0);})
#define MI_WRAPPER_EXIT_ERR(fmt, args...)   ({do{if(DBG_LEVEL>=MI_DBG_ERR){printf("<<<%s[%d] " fmt,__FUNCTION__,__LINE__, ##args);}}while(0);})
#else
#define MI_PRINT(fmt, args...)              ({do{pr_info(fmt, ##args);}while(0);})
#define MI_INFO(fmt, args...)               ({do{if(DBG_LEVEL>=MI_DBG_INFO){pr_info(fmt, ##args);}}while(0);})
#define MI_WRN(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_WRN){pr_warning(fmt, ##args);}}while(0);})
#define MI_ERR(fmt, args...)                ({do{if(DBG_LEVEL>=MI_DBG_ERR){pr_err("%s[%d]: " fmt, __FUNCTION__,__LINE__, ##args);}}while(0);})
#define MI_ENTER()                          ({do{if(DBG_LEVEL>=MI_DBG_ALL){pr_info(">>>%s[%d] \n",__FUNCTION__,__LINE__);}}while(0);})
#define MI_EXIT_OK()                        ({do{if(DBG_LEVEL>=MI_DBG_ALL){pr_info("<<<%s[%d] \n",__FUNCTION__,__LINE__);}}while(0);})
#define MI_EXIT_ERR(fmt, args...)           ({do{if(DBG_LEVEL>=MI_DBG_ERR){pr_err("<<<%s[%d]" fmt,__FUNCTION__,__LINE__, ##args);}}while(0);})
#endif

#endif//Endif MI_PACKAGE_AN

#else
#define MI_PRINT(fmt, args...)
#define MI_INFO(fmt, args...)
#define MI_WRN(fmt, args...)
#define MI_ERR(fmt, args...)
#define MI_ENTER()
#define MI_EXIT_OK()
#define MI_EXIT_ERR(fmt, args...)

#define MI_WRAPPER_INFO(fmt, args...)
#define MI_WRAPPER_WRN(fmt, args...)
#define MI_WRAPPER_ERR(fmt, args...)
#define MI_WRAPPER_ENTER()
#define MI_WRAPPER_EXIT_OK()
#define MI_WRAPPER_EXIT_ERR(fmt, args...)
#endif

//-------------------------------------------------------------------------------------------------
//  Types - Enums
//-------------------------------------------------------------------------------------------------


#endif///_MI_COMMON_H_

