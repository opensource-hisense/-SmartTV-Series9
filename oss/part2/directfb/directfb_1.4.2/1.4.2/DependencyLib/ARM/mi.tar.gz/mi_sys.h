/*------------------------------------------------------------------------------
 * MediaTek Inc. (C) 2018. All rights reserved.
 *
 * Copyright Statement:
 *
 * This software/firmware and related documentation ("MediaTek Software") are
 * protected under relevant copyright laws. The information contained herein is
 * confidential and proprietary to MediaTek Inc. and/or its licensors. Without
 * the prior written permission of MediaTek inc. and/or its licensors, any
 * reproduction, modification, use or disclosure of MediaTek Software, and
 * information contained herein, in whole or in part, shall be strictly
 * prohibited.
 *
 * BY OPENING THIS FILE, RECEIVER HEREBY UNEQUIVOCALLY ACKNOWLEDGES AND AGREES
 * THAT THE SOFTWARE/FIRMWARE AND ITS DOCUMENTATIONS ("MEDIATEK SOFTWARE")
 * RECEIVED FROM MEDIATEK AND/OR ITS REPRESENTATIVES ARE PROVIDED TO RECEIVER
 * ON AN "AS-IS" BASIS ONLY. MEDIATEK EXPRESSLY DISCLAIMS ANY AND ALL
 * WARRANTIES, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE OR
 * NONINFRINGEMENT. NEITHER DOES MEDIATEK PROVIDE ANY WARRANTY WHATSOEVER WITH
 * RESPECT TO THE SOFTWARE OF ANY THIRD PARTY WHICH MAY BE USED BY,
 * INCORPORATED IN, OR SUPPLIED WITH THE MEDIATEK SOFTWARE, AND RECEIVER AGREES
 * TO LOOK ONLY TO SUCH THIRD PARTY FOR ANY WARRANTY CLAIM RELATING THERETO.
 * RECEIVER EXPRESSLY ACKNOWLEDGES THAT IT IS RECEIVER'S SOLE RESPONSIBILITY TO
 * OBTAIN FROM ANY THIRD PARTY ALL PROPER LICENSES CONTAINED IN MEDIATEK
 * SOFTWARE. MEDIATEK SHALL ALSO NOT BE RESPONSIBLE FOR ANY MEDIATEK SOFTWARE
 * RELEASES MADE TO RECEIVER'S SPECIFICATION OR TO CONFORM TO A PARTICULAR
 * STANDARD OR OPEN FORUM. RECEIVER'S SOLE AND EXCLUSIVE REMEDY AND MEDIATEK'S
 * ENTIRE AND CUMULATIVE LIABILITY WITH RESPECT TO THE MEDIATEK SOFTWARE
 * RELEASED HEREUNDER WILL BE, AT MEDIATEK'S OPTION, TO REVISE OR REPLACE THE
 * MEDIATEK SOFTWARE AT ISSUE, OR REFUND ANY SOFTWARE LICENSE FEES OR SERVICE
 * CHARGE PAID BY RECEIVER TO MEDIATEK FOR SUCH MEDIATEK SOFTWARE AT ISSUE.
 *
 * The following software/firmware and/or related documentation ("MediaTek
 * Software") have been modified by MediaTek Inc. All revisions are subject to
 * any receiver's applicable license agreements with MediaTek Inc.
 *----------------------------------------------------------------------------*/

#ifndef _MI_SYS_H_
#define _MI_SYS_H_

#ifdef __cplusplus
extern "C" {
#endif

//-------------------------------------------------------------------------------------------------
//  Defines
//-------------------------------------------------------------------------------------------------
// version definition of struct MI_SYS_Mmap_t:
// 1.0: 0x1000, 1.1: 0x1001, 1.2: 0x1002, 2.0: 0x2000, 2.1: 0x2001,....
#define MI_SYS_MMAP_VERSION_1_0                 0x1000
#define MI_SYS_MMAP_VERSION_1_1                 0x1001
#define MI_SYS_MMAP_VERSION_1_2                 0x1002
#define MI_SYS_MMAP_VERSION_1_3                 0x1003
#define MI_SYS_MMAP_VERSION_1_4                 0x1004
#define MI_SYS_MMAP_VERSION_1_5                 0x1005

#define MI_SYS_MMAP_PREFIX                      0x4D490000  // 'MI'
#define MI_SYS_MMAP_VERSION                     MI_SYS_MMAP_VERSION_1_1   // current version
#define MI_SYS_MMAP_PREFIX_MASK                 0xFFFF0000
#define MI_SYS_MMAP_VERSION_MASK                0x0000FFFF

#define MI_SYS_MMAP_PREFIX_VERSION              (MI_SYS_MMAP_PREFIX | MI_SYS_MMAP_VERSION)

// version definition of struct MI_SYS_Board_t:
// 1.0: 0x1000, 1.1: 0x1001, 1.2: 0x1002, 2.0: 0x2000, 2.1: 0x2001,....
#define MI_SYS_BOARD_INFO_VERSION_1_0           0x1000
#define MI_SYS_BOARD_INFO_VERSION_1_1           0x1001
#define MI_SYS_BOARD_INFO_VERSION_1_2           0x1002
#define MI_SYS_BOARD_INFO_VERSION_1_3           0x1003
#define MI_SYS_BOARD_INFO_VERSION_1_4           0x1004
#define MI_SYS_BOARD_INFO_VERSION_1_5           0x1005
#define MI_SYS_BOARD_INFO_VERSION_1_6           0x1006
#define MI_SYS_BOARD_INFO_VERSION_1_7           0x1007

#define MI_SYS_BOARD_INFO_PREFIX                0x4D490000  // 'MI'
#define MI_SYS_BOARD_INFO_VERSION               MI_SYS_BOARD_INFO_VERSION_1_7   // current version
#define MI_SYS_BOARD_INFO_PREFIX_MASK           0xFFFF0000
#define MI_SYS_BOARD_INFO_VERSION_MASK          0x0000FFFF

#define MI_SYS_BOARD_INFO_PREFIX_VERSION        (MI_SYS_BOARD_INFO_PREFIX | MI_SYS_BOARD_INFO_VERSION)

// version definition of struct MI_SYS_Osd_t:
// 1.0: 0x1000, 1.1: 0x1001, 1.2: 0x1002, 2.0: 0x2000, 2.1: 0x2001,....
#define MI_SYS_OSD_INFO_VERSION_1_0             0x1000
#define MI_SYS_OSD_INFO_VERSION_1_1             0x1001
#define MI_SYS_OSD_INFO_VERSION_1_2             0x1002
#define MI_SYS_OSD_INFO_VERSION_1_3             0x1003
#define MI_SYS_OSD_INFO_VERSION_1_4             0x1004
#define MI_SYS_OSD_INFO_VERSION_1_5             0x1005

#define MI_SYS_OSD_INFO_PREFIX                  0x00010000
#define MI_SYS_OSD_INFO_VERSION                 MI_SYS_OSD_INFO_VERSION_1_0   // current version
#define MI_SYS_OSD_INFO_PREFIX_MASK             0xFFFF0000
#define MI_SYS_OSD_INFO_VERSION_MASK            0x0000FFFF

#define MI_SYS_OSD_INFO_PREFIX_VERSION          (MI_SYS_OSD_INFO_PREFIX | MI_SYS_OSD_INFO_VERSION)

//-------------------------------------------------------------------------------------------------
//  Structures
//-------------------------------------------------------------------------------------------------
typedef enum
{
    E_MI_SYS_COBUF_LAYER_INVALID = -1,
    E_MI_SYS_COBUF_LAYER_MIN = 0,

    E_MI_SYS_COBUF_LAYER_L0 = E_MI_SYS_COBUF_LAYER_MIN,
    E_MI_SYS_COBUF_LAYER_L1,
    E_MI_SYS_COBUF_LAYER_L2,
    E_MI_SYS_COBUF_LAYER_L3,
    E_MI_SYS_COBUF_LAYER_L4,
    E_MI_SYS_COBUF_LAYER_L5,
    E_MI_SYS_COBUF_LAYER_L6,
    E_MI_SYS_COBUF_LAYER_L7,
    E_MI_SYS_COBUF_LAYER_L8,
    E_MI_SYS_COBUF_LAYER_L9,
    E_MI_SYS_COBUF_LAYER_L10,
    E_MI_SYS_COBUF_LAYER_L11,

    E_MI_SYS_COBUF_LAYER_MAX,

    E_MI_SYS_COBUF_LAYER_MMA_MIN = 0x100,
    E_MI_SYS_COBUF_LAYER_MMA_IOMMU = E_MI_SYS_COBUF_LAYER_MMA_MIN,
    E_MI_SYS_COBUF_LAYER_MMA_CMA,

    E_MI_SYS_COBUF_LAYER_MMA_MAX
} MI_SYS_CobufLayer_e;

typedef enum
{
    E_MI_SYS_MIU_TYPE_INVALID = -1,
    E_MI_SYS_MIU_TYPE_MIN = 0,

    E_MI_SYS_MIU_TYPE_0 = E_MI_SYS_MIU_TYPE_MIN,        ///< MIU0
    E_MI_SYS_MIU_TYPE_1,                                ///< MIU1
    E_MI_SYS_MIU_TYPE_2,                                ///< MIU2

    E_MI_SYS_MIU_TYPE_MAX,
} MI_SYS_MiuType_e;

typedef enum
{
    E_MI_SYS_MEM_TYPE_INVALID = -1,
    E_MI_SYS_MEM_TYPE_MIN = 0,

    E_MI_SYS_MEM_TYPE_UNKNOWN = E_MI_SYS_MEM_TYPE_MIN,
    E_MI_SYS_MEM_TYPE_UNCACHED,
    E_MI_SYS_MEM_TYPE_WRITE_THROUGH,
    E_MI_SYS_MEM_TYPE_WRITE_COMBINING,
    E_MI_SYS_MEM_TYPE_WRITE_PROTECT,
    E_MI_SYS_MEM_TYPE_WRITE_BACK,

    E_MI_SYS_MEM_TYPE_MAX,
} MI_SYS_MemType_e;

typedef enum
{
    E_MI_SYS_CUSTOMER_INVALID = -1,
    E_MI_SYS_CUSTOMER_MIN = 0,

    E_MI_SYS_CUSTOMER_1 = E_MI_SYS_CUSTOMER_MIN,        ///Customer 1
    E_MI_SYS_CUSTOMER_2,                                ///Customer 2, parameter type is a pointer to MI_U32

    E_MI_SYS_CUSTOMER_MAX,
} MI_SYS_Customer_e;

typedef enum
{
    E_MI_SYS_MMAP_ID_INVALID = -1,                      ///< Invalid MMAP ID

    E_MI_SYS_MMAP_ID_MIU_MIN = 0x0,                     ///< Min of MMAP used for MIU
    // MIU0 Size
    E_MI_SYS_MMAP_ID_MIU0 = E_MI_SYS_MMAP_ID_MIU_MIN,   ///< MEM0_SIZE
    // MIU1 Size
    E_MI_SYS_MMAP_ID_MIU1,                              ///< MEM1_SIZE
    // MIU1 Size
    E_MI_SYS_MMAP_ID_MIU2,                              ///< MEM2_SIZE

    // MIU0 0/1 Part
    E_MI_SYS_MMAP_ID_MIU0_0,                            ///< MIU0_LOW, MMEM0_SIZE_0(deprecated)
    E_MI_SYS_MMAP_ID_MIU0_1,                            ///< MIU0_HIGH, MEM0_SIZE_1(deprecated)
    // MIU1 0/1 Part
    E_MI_SYS_MMAP_ID_MIU1_0,                            ///< MIU1_LOW, MIU1_BUFFER_START_0, MEM1_SIZE_0(deprecated)
    E_MI_SYS_MMAP_ID_MIU1_1,                            ///< MIU1_HIGH, MIU1_BUFFER_START_1, MEM1_SIZE_1(deprecated)
    // MIU2 0/1 Part
    E_MI_SYS_MMAP_ID_MIU2_0,                            ///< MIU2_LOW, MIU2_BUFFER_START_0, MEM2_SIZE_0(deprecated)
    E_MI_SYS_MMAP_ID_MIU2_1,                            ///< MIU2_HIGH, MIU2_BUFFER_START_1, MEM2_SIZE_1(deprecated)

    E_MI_SYS_MMAP_ID_MIU_MAX,                           ///< Max number of MMAP used for MIU

    // Memory Pool for system
    E_MI_SYS_MMAP_ID_SDK_MIN = 0x100,                   ///< Min of MMAP for MI SDK

    // LX1
    E_MI_SYS_MMAP_ID_LX1 = E_MI_SYS_MMAP_ID_SDK_MIN,    ///< MEM_LX1_START, MEM_LX1_SIZE
    // LX2
    E_MI_SYS_MMAP_ID_LX2,                               ///< MEM_LX2_START, MEM_LX2_SIZE
    // LX3
    E_MI_SYS_MMAP_ID_LX3,                               ///< MEM_LX3_START, MEM_LX3_SIZE

    E_MI_SYS_MMAP_ID_CACHED_POOL,                       ///< CACHED_POOL_BUF_ADDR, CACHED_POOL_BUF_LEN
    E_MI_SYS_MMAP_ID_NON_CACHED_POOL,                   ///< NON_CACHED_POOL_BUF_ADDR, NON_CACHED_POOL_BUF_LEN
    // MAD: AUDIO
    E_MI_SYS_MMAP_ID_MAD_SE_BUF,                        ///< MAD_SE_BUFFER_ADR, MAD_SE_BUFFER_LEN
    E_MI_SYS_MMAP_ID_MAD_DEC_BUF,                       ///< MAD_DEC_BUFFER_ADR, MAD_DEC_BUFFER_LEN
    // VE
    E_MI_SYS_MMAP_ID_VE_FRAME_BUF,                      ///< VE_FRAMEBUFFER_ADR, VE_FRAMEBUFFER_LEN
    // VIDEO
    E_MI_SYS_MMAP_ID_VDEC_AEON,                         ///< VDEC_AEON_ADR, VDEC_AEON_LEN, VDEC_AEON_MEMORY_TYPE
    E_MI_SYS_MMAP_ID_VDEC_FRAME_BUF,                    ///< VDEC_FRAMEBUFFER_ADR, VDEC_FRAMEBUFFER_LEN, VDEC_FRAMEBUFFER_MEMORY_TYPE
    E_MI_SYS_MMAP_ID_VDEC_BITSREAM,                     ///< VDEC_BITSTREAM_ADR, VDEC_BITSTREAM_LEN, VDEC_BITSTREAM_MEMORY_TYPE
    ///VIDEO1
    E_MI_SYS_MMAP_ID_VDEC1_FRAME_BUF,
    E_MI_SYS_MMAP_ID_VDEC1_BITSREAM,
    ///VIDEO MVC
    E_MI_SYS_MMAP_ID_VDEC_MVC_FRAME_BUF,
    E_MI_SYS_MMAP_ID_VDEC_MVC_BITSTREAM,
    // MHEG5
    E_MI_SYS_MMAP_ID_MHEG5_JPG_BUF,                     ///< MHEG5_JPEG_BUFF_ADR, MHEG5_JPEG_BUFF_LEN
    E_MI_SYS_MMAP_ID_MHEG5_BUF,                         ///< MHEG5_BUFF_ADR, MHEG5_BUFF_LEN
    // SCALER
    E_MI_SYS_MMAP_ID_XC_MAIN_FB,                        ///< MAIN_FB_START_ADDR, SCALER_DNR_BUF_LEN
    E_MI_SYS_MMAP_ID_XC_SUB_FB,                         ///< SUB_FB_START_ADDR, SCALER_DNR_BUF_LEN
    // MenuLoad
    E_MI_SYS_MMAP_ID_MENULOAD_BUF,                      ///< MENULOAD_BUFFER_ADR, MENULOAD_BUFFER_LEN, MENULOAD_BUFFER_MEMORY_TYPE
    // Seamless zapping
    E_MI_SYS_MMAP_ID_SEAMLESS_ZAPPING_BUF,              ///< SEAMLESS_ZAPPING_BUF_ADR, SEAMLESS_ZAPPING_BUF_LEN, SEAMLESS_ZAPPING_BUF_MEMORY_TYPE
    ///XC1
    E_MI_SYS_MMAP_ID_XC1_MAIN_FB,
    E_MI_SYS_MMAP_ID_XC1_SUB_FB,
    E_MI_SYS_MMAP_ID_MENULOAD1_BUF,
    E_MI_SYS_MMAP_ID_SEAMLESS_ZAPPING1_BUF,
    // TSP
    E_MI_SYS_MMAP_ID_TSP_SECT_BUF,                      ///< SECTION_BUF_ADDR, SECTION_BUF_LEN
    E_MI_SYS_MMAP_ID_TSP_FW_BUF,                        ///< TSP_FW_BUF, TSP_FW_LEN
    E_MI_SYS_MMAP_ID_TSP_FQ_BUF,                        ///< TSP_FQ_BUFFER_ADR, TSP_FQ_BUFFER_LEN
    E_MI_SYS_MMAP_ID_TSP_VQ_BUF,                        ///< TSP_VQ_BUF, TSP_VQ_LEN
    // PM51
    E_MI_SYS_MMAP_ID_PM51_MIU_ENTER_SR,                 ///< PM51_MIU_ENTER_SR_ADDR, PM51_MIU_ENTER_SR_LEN, PM51_MIU_TYPE
    E_MI_SYS_MMAP_ID_PM51_MIU_EXIT_SR,                  ///< PM51_MIU_EXIT_SR_ADDR, PM51_MIU_EXIT_SR_LEN, PM51_MIU_TYPE
    E_MI_SYS_MMAP_ID_PM51_HWIP_OPEN,                    ///< PM51_HWIP_OPEN_ADDR, PM51_HWIP_OPEN_LEN, PM51_MIU_TYPE
    E_MI_SYS_MMAP_ID_PM51_HWIP_CLOSE,                   ///< PM51_HWIP_CLOSE_ADDR, PM51_HWIP_CLOSE_LEN, PM51_MIU_TYPE
    E_MI_SYS_MMAP_ID_PM51_LOADER,                       ///< PM51_LOADER_ADDR, PM51_LOADER_LEN, PM51_MIU_TYPE
    E_MI_SYS_MMAP_ID_PM51_LITE,                         ///< PM51_LITE_ADDR, PM51_LITE_LEN, PM51_MIU_TYPE
    E_MI_SYS_MMAP_ID_PM51_MEM,                          ///< PM51_MEM_ADR, PM51_MEM_LEN, PM51_MIU_TYPE
    E_MI_SYS_MMAP_ID_PM51_VAR_MEM,                      ///< PM51_VAR_MEM_ADR, PM51_VAR_MEM_LEN, PM51_MIU_TYPE
    // GOP
    E_MI_SYS_MMAP_ID_GOP_REGDMA_BASE,                   ///< GOP_REGDMABASE_ADR, GOP_REGDMABASE_LEN
    E_MI_SYS_MMAP_ID_GOP_GWIN_RB,                       ///< GOP_GWIN_RB_ADR, GOP_GWIN_RB_LEN
    // JPEG decode
    E_MI_SYS_MMAP_ID_JPD_READ_BUF,                      ///< JPD_READBUFF_ADR, JPD_READBUFF_LEN
    E_MI_SYS_MMAP_ID_JPD_INTER_BUF,                     ///< JPD_INTERBUFF_ADR, JPD_INTERBUFF_LEN
    E_MI_SYS_MMAP_ID_JPD_OUT,                           ///< JPD_OUT_ADR, JPD_OUT_LEN
    E_MI_SYS_MMAP_ID_PHOTO_SHARE_MEM,                   ///< PHOTO_SHAREMEM_ADR, PHOTO_SHAREMEM_LEN
    // MM
    E_MI_SYS_MMAP_ID_MM_COPROCESSOR,                    ///< MM_COPROCESSOR_ADDR, MM_COPROCESSOR_LEN, MM_COPROCESSOR_TYPE
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_DATA,                  ///< VDPLAYER_DATA_ADR, VDPLAYER_DATA_LEN, VDPLAYER_MEMORY_TYPE
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_SUB_BS,                ///< VDPLAYER_SUB_BS_ADR, VDPLAYER_SUB_BS_LEN, VDPLAYER_MEMORY_TYPE
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_BS,                    ///< VDPLAYER_BS_ADR, VDPLAYER_BS_LEN, VDPLAYER_MEMORY_TYPE
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_BS_EXT,                ///< VDPLAYER_BS_EXT_ADR, VDPLAYER_BS_EXT_LEN, VDPLAYER_MEMORY_TYPE
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_SUB,                   ///< VDPLAYER_SUB_ADR, VDPLAYER_SUB_LEN, VDPLAYER_MEMORY_TYPE
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_DMX_SECT,              ///< VDPLAYER_DMX_SEC_ADR, VDPLAYER_DMX_SEC_LEN, VDPLAYER_MEMORY_TYPE
    // INJECTION
    E_MI_SYS_MMAP_ID_INJECT_BUF,                        ///< INJECTION_BUFFER_ADR, INJECTION_BUFFER_LEN
    // Still image zapping
    E_MI_SYS_MMAP_ID_STILL_IMAGE_ZAPPING_BUF,           ///< STILL_IMG_ZAPPING_BUF_ADR, STILL_IMG_ZAPPING_BUF_LEN
    // PVR
    E_MI_SYS_MMAP_ID_PVR_DOWNLOAD,
    E_MI_SYS_MMAP_ID_PVR_UPLOAD,
    E_MI_SYS_MMAP_ID_PVR_AUDIO_BUFFER,
    E_MI_SYS_MMAP_ID_PVR_MN_VIDEO_BUFFER,
    E_MI_SYS_MMAP_ID_PVR_MN_AUDIO_BUFFER,
    E_MI_SYS_MMAP_ID_PVR_TSR_VIDEO_BUFFER,
    E_MI_SYS_MMAP_ID_PVR_TSR_AUDIO_BUFFER,
    // Audio
    E_MI_SYS_MMAP_ID_MAD_ADV_BUF,                       ///< MAD_ADV_BUFFER_ADR, MAD_ADV_BUFFER_LEN
    E_MI_SYS_MMAP_ID_MAD_COMM_BUF,                      ///< MAD_COMM_BUFFER_ADR, MAD_COMM_BUFFER_LEN

    //MM photo display
    E_MI_SYS_MMAP_ID_MM_PHOTO_DISPLAY,

    //PM powerSaving bin file buffer
    E_MI_SYS_MMAP_ID_PM_POWER_SAVING_BIN_BUF,

    /// System
    E_MI_SYS_MMAP_ID_MAC,

    //PM STR fast standby MBOOT buffer
    E_MI_SYS_MMAP_ID_PM_STR_POWER_UP_BUF,

    /// MM
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_SHARE_MEM,
    E_MI_SYS_MMAP_ID_MM_VDPLAYER_PHY_COPY,
    E_MI_SYS_MMAP_ID_VDEC_SHARE_MEM,

    // HBBTV DSMCC buffer
    E_MI_SYS_MMAP_ID_HBBTV_DSMCC_BUF,

    ///HDR buffer
    E_MI_SYS_MMAP_ID_DISP_CFD_MENULOAD,
    E_MI_SYS_MMAP_ID_DISP_AUTO_DOWNLOAD,
    E_MI_SYS_MMAP_ID_VDEC_HDR_INFO,

    /// Multi View frame buffer
    E_MI_SYS_MMAP_ID_DISP_MULTI_VIEW_FRAME_BUF, //Full size of the Multi-view buffer, default arranged by MI.

    //SW DS buffer
    E_MI_SYS_MMAP_ID_MCU_DS,
    E_MI_SYS_MMAP_ID_DISP_2DTO3D_BUF,
    //Local Dimming
    E_MI_SYS_MMAP_ID_DISPOUT_LOCAL_DIMMING,
    //FRC
    E_MI_SYS_MMAP_ID_FRC_R2,
    E_MI_SYS_MMAP_ID_FRC_PQ,
    E_MI_SYS_MMAP_ID_FRC_L,
    E_MI_SYS_MMAP_ID_FRC_R,
    //XC DMA
    E_MI_SYS_MMAP_ID_DISP_DMA,
    //CC
    E_MI_SYS_MMAP_ID_VDEC_CC_RAW_DATA,

    // Memory Pool for Kernel
    E_MI_SYS_MMAP_ID_KER_CACHED_POOL,
    E_MI_SYS_MMAP_ID_KER_NON_CACHED_POOL,

    // Cobuffer for kernel module
    E_MI_SYS_MMAP_ID_KERNEL_MODULE_COBUF0,
    E_MI_SYS_MMAP_ID_KERNEL_MODULE_COBUF1,

    // CAP Manage Memory Pool
    E_MI_SYS_MMAP_ID_CAP_POOL,

    /// MIU0 CMA Others
    E_MI_SYS_MMAP_ID_MIU0_CMA_OTHERS,

    /// MIU1 CMA Others
    E_MI_SYS_MMAP_ID_MIU1_CMA_OTHERS,

    // MI Video Encoder
    E_MI_SYS_MMAP_ID_VIDEO_ENCODER,

    // MI HWC CMDQ
    E_MI_SYS_MMAP_ID_HWC_CMDQ,
    // MI for AN FBDEV GOP BUF
    E_MI_SYS_MMAP_ID_AN_FBDEV_GOP_BUF,
    // MI for AN HWC GOP BUF
    E_MI_SYS_MMAP_ID_AN_HWC_GOP_BUF,
    // MI for AN MFE CAMERA
    E_MI_SYS_MMAP_ID_AN_MFE_CAMERA,
    // MI for AN DIP CAPTURE_MAIN_MM
    E_MI_SYS_MMAP_ID_AN_DIP_CAPTURE_MAIN_MM,
    // MI for AN DIP_CAPTURE_SUB_MM
    E_MI_SYS_MMAP_ID_AN_DIP_CAPTURE_SUB_MM,

    //GE
    E_MI_SYS_MMAP_ID_GE_VQCMD_BUF,
    /// PQ Memory (virtual register, used to store parameter)
    E_MI_SYS_MMAP_ID_DISP_PQ_MEMORY,

    // For CA defined
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_1,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_2,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_3,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_4,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_5,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_6,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_7,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_8,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_9,
    E_MI_SYS_MMAP_ID_CA_POOL_BUF_10,

    /// MI for Linux Frame Buffer Device
    E_MI_SYS_MMAP_ID_LINUX_FBDEV_BUF,

    /// Multi View frame buffer
    //If you want to customize the usage of Multi-view MMAP, please allocate each of the item below.
    //Otherwise, allocate none of them and use "E_MI_SYS_MMAP_ID_DISP_MULTI_VIEW_FRAME_BUF" for default setting.
    E_MI_SYS_MMAP_ID_DISP_MULTI_VIEW_SINGLE_DISPLAY, //For main window.
    E_MI_SYS_MMAP_ID_DISP_MULTI_VIEW_MULTIPLE_DISPLAY, //For other windows.
    E_MI_SYS_MMAP_ID_DISP_MULTI_VIEW_DI, //For deinterlace.
    E_MI_SYS_MMAP_ID_DISP_MULTI_VIEW_FREEZE, //For freeze function.

    E_MI_SYS_MMAP_ID_LINUX_FBDEV_BUF1,
    E_MI_SYS_MMAP_ID_LINUX_FBDEV_BUF2,
    E_MI_SYS_MMAP_ID_LINUX_FBDEV_BUF3,
    E_MI_SYS_MMAP_ID_LINUX_FBDEV_BUF4,
    E_MI_SYS_MMAP_ID_GPU_DIP_MEM,			///< Dedicated memory allocated for VR360
    //For mboot bootlogo
    E_MI_SYS_MMAP_ID_BOOTLOGO_BUF,                      ///< BOOTLOGO_BUF_ADR, BOOTLOGO_BUF_LEN
    //Demod
    E_MI_SYS_MMAP_ID_DMD_DVBT,
    //TSP
    E_MI_SYS_MMAP_ID_TSP_SVQ_BUF,                       ///< TSP_SVQ_BUF, TSP_SVQ_LEN
    //EXTIN
    E_MI_SYS_MMAP_ID_EXTIN_VD_COMB_BUF,                       ///< VD comb filter Buffer
    //For MI_DISP photo buffer
    E_MI_SYS_MMAP_ID_DISP_PHOTO_BUF,
    //For MI_GOP Mali buffer
    E_MI_SYS_MMAP_ID_GOP_MALI_BUF,

    //For E_MMAP_ID_OPTEE mem ext buffer
    E_MI_SYS_MMAP_ID_OPTEE_MEM_EXT_BUF,

    //For E_MMAP_ID_OD buffer
    E_MI_SYS_MMAP_ID_OD_BUF,

    E_MI_SYS_MMAP_ID_AN_RECOVERY_BUF,

    //For MI_DISP_AUTO_UPLOAD
    E_MI_SYS_MMAP_ID_AUTO_UPLOAD,

    //For MI_DISP_GUCD_DMA
    E_MI_SYS_MMAP_ID_GUCD_DMA,

    E_MI_SYS_MMAP_ID_TSP_ALP_PVR_BUF,                   ///< ALP PVR for ATSC3.0

    E_MI_SYS_MMAP_ID_MCDI_ME1_BUF,
    E_MI_SYS_MMAP_ID_MCDI_ME2_BUF,

    E_MI_SYS_MMAP_ID_SDK_MAX,                           ///< Max number of MMAP used for MI SDK

    // For customer defined
    E_MI_SYS_MMAP_ID_CUSTOM_MIN = 0x10000,              ///< Min of MMAP used for Customer

    E_MI_SYS_MMAP_ID_CUSTOM_1 = E_MI_SYS_MMAP_ID_CUSTOM_MIN,
    E_MI_SYS_MMAP_ID_CUSTOM_2,
    E_MI_SYS_MMAP_ID_CUSTOM_3,
    E_MI_SYS_MMAP_ID_CUSTOM_4,
    E_MI_SYS_MMAP_ID_CUSTOM_5,
    E_MI_SYS_MMAP_ID_CUSTOM_6,
    E_MI_SYS_MMAP_ID_CUSTOM_7,
    E_MI_SYS_MMAP_ID_CUSTOM_8,
    E_MI_SYS_MMAP_ID_CUSTOM_9,
    E_MI_SYS_MMAP_ID_CUSTOM_10,

    E_MI_SYS_MMAP_ID_CUSTOM_MAX,                        ///< Max number of MMAP used for Customer.
} MI_SYS_MmapId_e;

typedef enum
{
    E_MI_SYS_BOARD_INFO_ID_INVALID = -1,                ///< Invalid Board Info ID
    E_MI_SYS_BOARD_INFO_ID_MIN = 0,                     ///< Min number of Board Info ID

    E_MI_SYS_BOARD_INFO_ID_AUDIO_MIN = E_MI_SYS_BOARD_INFO_ID_MIN,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_MAIN_SPEAKER = E_MI_SYS_BOARD_INFO_ID_AUDIO_MIN,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_HP,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_LINEOUT,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_SIFOUT,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_SCART1,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_SCART2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_I2S,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_SPDIF,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_PATH_HDMI,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_OUTPUT_MAIN_SPEAKER,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_OUTPUT_HP,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_OUTPUT_LINEOUT,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_OUTPUT_SIFOUT,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_OUTPUT_SCART1,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_OUTPUT_SCART2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_DTV,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_DTV2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_ATV,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_PC,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_YPBPR,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_YPBPR2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_AV,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_AV2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_AV3,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_SV,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_SV2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_SCART,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_SCART2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_HDMI,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_HDMI2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_HDMI3,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_DVI,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_DVI2,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_DVI3,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_SOURCE_KTV,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_GPIO_MUTE_PIN,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_GPIO_MUTE_LEVEL,
    E_MI_SYS_BOARD_INFO_ID_AUDIO_MAX,

    E_MI_SYS_BOARD_INFO_ID_DISP_MIN = 0x100,
    E_MI_SYS_BOARD_INFO_ID_DISP_HDMITX_ANALOG_TUNING_SD = E_MI_SYS_BOARD_INFO_ID_DISP_MIN,
    E_MI_SYS_BOARD_INFO_ID_DISP_HDMITX_ANALOG_TUNING_HD,
    E_MI_SYS_BOARD_INFO_ID_DISP_HDMITX_ANALOG_TUNING_DEEP_HD,
    E_MI_SYS_BOARD_INFO_ID_DISP_HDMITX_HPD_GPIO_NUM,
    E_MI_SYS_BOARD_INFO_ID_DISP_SCART_PIN8_GPIO_NUM,
    E_MI_SYS_BOARD_INFO_ID_DISP_MAX,

    E_MI_SYS_BOARD_INFO_ID_EXTIN_MIN = 0x200,
    E_MI_SYS_BOARD_INFO_ID_EXTIN_HDMIRX_BY_PASS_GPIO_NUM = E_MI_SYS_BOARD_INFO_ID_EXTIN_MIN,
    E_MI_SYS_BOARD_INFO_ID_EXTIN_MAX,

    E_MI_SYS_BOARD_INFO_ID_GPIO_MIN = 0x300,
    E_MI_SYS_BOARD_INFO_ID_GPIO_MUTE = E_MI_SYS_BOARD_INFO_ID_GPIO_MIN,
    E_MI_SYS_BOARD_INFO_ID_GPIO_PANEL_CTL,
    E_MI_SYS_BOARD_INFO_ID_GPIO_INV_CTL,
    E_MI_SYS_BOARD_INFO_ID_GPIO_SCART_RECORD1,
    E_MI_SYS_BOARD_INFO_ID_GPIO_SCART_RECORD2,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DEMODULATOR_RESET,
    E_MI_SYS_BOARD_INFO_ID_GPIO_HDMI_HPD,
    E_MI_SYS_BOARD_INFO_ID_GPIO_HDMI_INT,
    E_MI_SYS_BOARD_INFO_ID_GPIO_HDMI1_PLUG_IN,
    E_MI_SYS_BOARD_INFO_ID_GPIO_HDMI2_PLUG_IN,
    E_MI_SYS_BOARD_INFO_ID_GPIO_HDMI3_PLUG_IN,
    E_MI_SYS_BOARD_INFO_ID_GPIO_HDMI4_PLUG_IN,
    E_MI_SYS_BOARD_INFO_ID_GPIO_SPI_WP,
    E_MI_SYS_BOARD_INFO_ID_GPIO_EXT_IF_AGC,
    E_MI_SYS_BOARD_INFO_ID_GPIO_EEPROM_WP,
    E_MI_SYS_BOARD_INFO_ID_GPIO_PCM_POWER_CTRL,
    E_MI_SYS_BOARD_INFO_ID_GPIO_PANEL_3D_ENABLE,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DVBS_RESETZ,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISEQC_TXRX_SWITCH,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISEQC_TXRX_SWITCH1,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISEQC_TXRX_SWITCH2,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISEQC_TXRX_SWITCH3,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DEMOD_HW_FE_RST, // 0x316 790
    E_MI_SYS_BOARD_INFO_ID_GPIO_DEMOD_HW_FE_RST1,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DEMOD_HW_FE_RST2,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DEMOD_HW_FE_RST3,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_RESET,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_STANDBY,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_HEADPHONE_DETECTION,
    E_MI_SYS_BOARD_INFO_ID_GPIO_USB_POWER_CTRL,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_EN,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_EN1,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_EN2,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_EN3,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_SEL,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_SEL1,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_SEL2,
    E_MI_SYS_BOARD_INFO_ID_GPIO_DISH_HW_LNB_SEL3,
    E_MI_SYS_BOARD_INFO_ID_GPIO_LED_CTL,
    E_MI_SYS_BOARD_INFO_ID_GPIO_TOTAL_NUMBER,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_RESET1,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_STANDBY1,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_RESET2,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_STANDBY2,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_RESET3,
    E_MI_SYS_BOARD_INFO_ID_GPIO_AUDIO_AMP_STANDBY3,
    E_MI_SYS_BOARD_INFO_ID_GPIO_MAX,

    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_MIN = 0x400,
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_TUNER_0, // I2C slave address for tuner 0
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_TUNER_1, // I2C slave address for tuner 1
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_EEPROM = E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_MIN+0x50,  // I2C slave address for eeprom contrl
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DEMOD_DYNAMIC_SLAVE_ID_0,                             // I2C slave address for demod 0
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DEMOD_DYNAMIC_SLAVE_ID_1,                             // I2C slave address for demod 1
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DEMOD_DYNAMIC_SLAVE_ID_2,                             // I2C slave address for demod 2
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DEMOD_DYNAMIC_SLAVE_ID_3,                             // I2C slave address for demod 3
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISPOUT_FRC_SLAVE_REG,                                // I2C slave address for MS TV tool register read/write
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISPOUT_FRC_SLAVE_ISP,                                // I2C slave address for ISP tool download code
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISPOUT_FRC_SLAVE_CMD,                                // I2C slave address for sending command
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_PANEL_TCON,                                           // I2C slave address for pannel tcon
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_MHL_ELAND_CONFIG,                                     // I2C slave address for MHL config
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_MHL_ELAND_COMMON,                                     // I2C slave address for MHL common
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISPOUT_RAPTORS_SLAVE_ISP,                            // I2C slave address for for raptors isp upgrade
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISPOUT_RAPTORS_SLAVE_CMD,                            // I2C slave address for for raptors control

    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_FRONTEND_TUNER_PORT0,                                 // HW I2C port0 for tuner
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_FRONTEND_TUNER_PORT1,                                 // HW I2C port1 for tuner
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_FRONTEND_TUNER_PORT2,                                 // HW I2C port2 for tuner
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_FRONTEND_TUNER_PORT3,                                 // HW I2C port3 for tuner

    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISH_IIC_PORT0,
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISH_IIC_PORT1,
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISH_IIC_PORT2,
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_DISH_IIC_PORT3,

    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_AUDIO_AMP,                                            // SW I2C port for audio amplifier
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_TOTAL_NUMBER,

    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_AUDIO_AMP1,
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_AUDIO_AMP2,
    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_AUDIO_AMP3,

    E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_MAX,

    E_MI_SYS_BOARD_INFO_ID_IIC_SWBUS_TOTAL_NUMBER = E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_MIN+0xA0,
    E_MI_SYS_BOARD_INFO_ID_IIC_SWBUS_0,                                                     //{PORT, SCL_PAD, SDA_PAD, DELAY}
    E_MI_SYS_BOARD_INFO_ID_IIC_SWBUS_1,                                                     //{PORT, SCL_PAD, SDA_PAD, DELAY}
    E_MI_SYS_BOARD_INFO_ID_IIC_SWBUS_2,                                                     //{PORT, SCL_PAD, SDA_PAD, DELAY}
    E_MI_SYS_BOARD_INFO_ID_IIC_SWBUS_3,                                                     //{PORT, SCL_PAD, SDA_PAD, DELAY}
    E_MI_SYS_BOARD_INFO_ID_IIC_SWBUS_MAX,

    E_MI_SYS_BOARD_INFO_ID_IIC_HWBUS_TOTAL_NUMBER = E_MI_SYS_BOARD_INFO_ID_IIC_DEVICE_MIN+0xC0,
    E_MI_SYS_BOARD_INFO_ID_IIC_HWBUS_0,                                                     //{PIN_REG, PIN_BITS, PIN_ENABLE, SPEED, PORT}
    E_MI_SYS_BOARD_INFO_ID_IIC_HWBUS_1,                                                     //{PIN_REG, PIN_BITS, PIN_ENABLE, SPEED, PORT}
    E_MI_SYS_BOARD_INFO_ID_IIC_HWBUS_2,                                                     //{PIN_REG, PIN_BITS, PIN_ENABLE, SPEED, PORT}
    E_MI_SYS_BOARD_INFO_ID_IIC_HWBUS_3,                                                     //{PIN_REG, PIN_BITS, PIN_ENABLE, SPEED, PORT}
    E_MI_SYS_BOARD_INFO_ID_IIC_HWBUS_MAX,

    E_MI_SYS_BOARD_INFO_ID_DISPOUT_MIN = 0x500,
    E_MI_SYS_BOARD_INFO_ID_DISPOUT_SUPPORT_COUNT = E_MI_SYS_BOARD_INFO_ID_DISPOUT_MIN,      //{PanelCount, HdmiTxCount, YpbprCount, CvbsCount, ScartCount, Ch34Count}
    E_MI_SYS_BOARD_INFO_ID_DISPOUT_CONFIG,                                                  //{Ldm, ExtFrcType, CtrlType, CtrlPort}
    E_MI_SYS_BOARD_INFO_ID_DISPOUT_MAX,

    E_MI_SYS_BOARD_INFO_ID_TUNER_MIN = 0x600,
    E_MI_SYS_BOARD_INFO_ID_TUNER_TS_PAD_INFO_TOTAL_NUMBER = E_MI_SYS_BOARD_INFO_ID_TUNER_MIN,
    E_MI_SYS_BOARD_INFO_ID_TUNER_TS_PAD_INFO_0,                                             //{FLOW_INPUT, CLOCK_INVERSE, EXT_SYNC, SERIAL_MODE, BIT_SWAP, PACKET_MODE, DEMOD_NUM, SYNC_BYTE}
    E_MI_SYS_BOARD_INFO_ID_TUNER_TS_PAD_INFO_1,                                             //{FLOW_INPUT, CLOCK_INVERSE, EXT_SYNC, SERIAL_MODE, BIT_SWAP, PACKET_MODE, DEMOD_NUM, SYNC_BYTE}
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISH_TYPE0 = E_MI_SYS_BOARD_INFO_ID_TUNER_MIN+0x50,
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISH_TYPE1,
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISH_TYPE2,
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISH_TYPE3,
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISEQC_RX_LOW_EN0 = E_MI_SYS_BOARD_INFO_ID_TUNER_MIN+0x70,
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISEQC_RX_LOW_EN1,
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISEQC_RX_LOW_EN2,
    E_MI_SYS_BOARD_INFO_ID_TUNER_DISEQC_RX_LOW_EN3,
    E_MI_SYS_BOARD_INFO_ID_TUNER_MAX,

    E_MI_SYS_BOARD_INFO_ID_MAX = E_MI_SYS_BOARD_INFO_ID_TUNER_MAX,                          /// Max number of Board Info ID.
} MI_SYS_BoardInfoId_e;

typedef enum
{
    E_MI_SYS_OSD_INFO_ID_INVALID = -1,                ///< Invalid Osd Info ID
    E_MI_SYS_OSD_INFO_ID_MIN = 0,                     ///< Min number of Osd Info ID

    E_MI_SYS_OSD_INFO_ID_LAYER_MIN = E_MI_SYS_OSD_INFO_ID_MIN,
    E_MI_SYS_OSD_INFO_ID_LAYER_ZORDER0 = E_MI_SYS_OSD_INFO_ID_LAYER_MIN,
    E_MI_SYS_OSD_INFO_ID_LAYER_ZORDER1,
    E_MI_SYS_OSD_INFO_ID_LAYER_ZORDER2,
    E_MI_SYS_OSD_INFO_ID_LAYER_ZORDER3,
    E_MI_SYS_OSD_INFO_ID_LAYER_ZORDER4,
    E_MI_SYS_OSD_INFO_ID_LAYER_LAYER0_DESTINATION = E_MI_SYS_OSD_INFO_ID_LAYER_MIN+0x20,
    E_MI_SYS_OSD_INFO_ID_LAYER_LAYER1_DESTINATION,
    E_MI_SYS_OSD_INFO_ID_LAYER_LAYER2_DESTINATION,
    E_MI_SYS_OSD_INFO_ID_LAYER_LAYER3_DESTINATION,
    E_MI_SYS_OSD_INFO_ID_LAYER_LAYER4_DESTINATION,
    E_MI_SYS_OSD_INFO_ID_LAYER_UI_HD = E_MI_SYS_OSD_INFO_ID_LAYER_MIN+0x40,
    E_MI_SYS_OSD_INFO_ID_LAYER_UI_SD,
    E_MI_SYS_OSD_INFO_ID_LAYER_SUBTITLE,
    E_MI_SYS_OSD_INFO_ID_LAYER_STILLIMAGE_HD,
    E_MI_SYS_OSD_INFO_ID_LAYER_STILLIMAGE_SD,
    E_MI_SYS_OSD_INFO_ID_LAYER_MAX,

    E_MI_SYS_OSD_INFO_ID_VQ_MIN = 0x100,
    E_MI_SYS_OSD_INFO_ID_VQ_BUFFER_SIZE = E_MI_SYS_OSD_INFO_ID_VQ_MIN,
    E_MI_SYS_OSD_INFO_ID_VQ_MAX,

    E_MI_SYS_OSD_INFO_ID_MAX = E_MI_SYS_OSD_INFO_ID_VQ_MAX,                            /// Max number of Osd Info ID.
} MI_SYS_OsdInfoId_e;

typedef enum
{
    //Please keep the order
    E_MI_SYS_MODULE_ID_MIN = 0,                         ///< Min number of MI Module ID Type
    E_MI_SYS_MODULE_ID_SYS_KERNEL = E_MI_SYS_MODULE_ID_MIN,
    E_MI_SYS_MODULE_ID_SYS_USER,
    E_MI_SYS_MODULE_ID_DEBUG,
    E_MI_SYS_MODULE_ID_FLASH,
    E_MI_SYS_MODULE_ID_FS,
    E_MI_SYS_MODULE_ID_USB,
    E_MI_SYS_MODULE_ID_DISP,
    E_MI_SYS_MODULE_ID_DISPOUT,
    E_MI_SYS_MODULE_ID_CEC,
    E_MI_SYS_MODULE_ID_OSD,
    E_MI_SYS_MODULE_ID_TUNER,
    E_MI_SYS_MODULE_ID_DMX,
    E_MI_SYS_MODULE_ID_TSIO,
    E_MI_SYS_MODULE_ID_CAP,
    E_MI_SYS_MODULE_ID_VIDEO,
    E_MI_SYS_MODULE_ID_VMON,
    E_MI_SYS_MODULE_ID_VENC,
    E_MI_SYS_MODULE_ID_AUDIO,
    E_MI_SYS_MODULE_ID_AOUT,
    E_MI_SYS_MODULE_ID_PCM,
    E_MI_SYS_MODULE_ID_IMGDEC,
    E_MI_SYS_MODULE_ID_INJECT,
    E_MI_SYS_MODULE_ID_KL,
    E_MI_SYS_MODULE_ID_DSC,
    E_MI_SYS_MODULE_ID_ADVCA,
    E_MI_SYS_MODULE_ID_CIPHER,
    E_MI_SYS_MODULE_ID_EXTIN,
    E_MI_SYS_MODULE_ID_PM,
    E_MI_SYS_MODULE_ID_PWM,
    E_MI_SYS_MODULE_ID_WDT,
    E_MI_SYS_MODULE_ID_SMC,
    E_MI_SYS_MODULE_ID_PCMCIA,
    E_MI_SYS_MODULE_ID_TSENSOR,
    E_MI_SYS_MODULE_ID_GPIO,
    E_MI_SYS_MODULE_ID_IIC,
    E_MI_SYS_MODULE_ID_IR,
    E_MI_SYS_MODULE_ID_SAR,
    E_MI_SYS_MODULE_ID_TSR,
    E_MI_SYS_MODULE_ID_UART,
    E_MI_SYS_MODULE_ID_SYNC,

    E_MI_SYS_MODULE_ID_MAX,                           ///< Max number of MI Module ID Type
} MI_SYS_ModuleId_e;

typedef enum
{
    E_MI_SYS_ATTR_TYPE_INVALID = -1,                    ///< Invalid Attribute of MY SYS.
    E_MI_SYS_ATTR_TYPE_TYPE_MIN = 0,                    ///< Min Attribute of MY SYS.

    E_MI_SYS_ATTR_TYPE_PERSISTENT_DATA_BY_RESET = E_MI_SYS_ATTR_TYPE_TYPE_MIN,              ///< this type means data without changed after reset and the pUsrParam is the pointer of MI_U16.
    E_MI_SYS_ATTR_TYPE_AUTH_STATUS,                     ///< this type means status of AUTH  and the pUsrParam is the pointer of MI_U8. 1:ok, 0:fail
    E_MI_SYS_ATTR_TYPE_HW_TIMER_0_MS,                   ///< Get HW_Timer0 value in millisecond
    E_MI_SYS_ATTR_TYPE_HW_TIMER_1_MS,                   ///< Get HW_Timer1 value in millisecond
    E_MI_SYS_ATTR_TYPE_SDK_VER,
    E_MI_SYS_ATTR_TYPE_MODULE_STATUS,                   ///< this type meanse init status of module
    E_MI_SYS_ATTR_TYPE_UNIQUE_CHIP_ID,                  ///< this type return unique device id of the chip, MI_U16[6] 12 bytes
    E_MI_SYS_ATTR_TYPE_QUIETHOTBOOT_FLAG,               ///< this type update/return quiet hot boot status
    E_MI_SYS_ATTR_TYPE_CHIP_ID,                         ///< this type return chip id of the chip

    E_MI_SYS_ATTR_TYPE_MAX,                             ///< Max Attribute of MY SYS.
} MI_SYS_AttrType_e;

typedef enum
{
    E_MI_SYS_CONFIG_INFO_TYPE_INVALID = -1,
    E_MI_SYS_CONFIG_INFO_TYPE_MIN = 0,

    E_MI_SYS_CONFIG_INFO_TYPE_OSD = E_MI_SYS_CONFIG_INFO_TYPE_MIN,

    E_MI_SYS_CONFIG_INFO_TYPE_MAX,
} MI_SYS_ConfigInfoType_e;

typedef enum
{
    E_MI_SYS_UPGRADE_FW_TYPE_INVALID = -1,
    E_MI_SYS_UPGRADE_FW_TYPE_MIN = 0,

    E_MI_SYS_UPGRADE_FW_TYPE_HDMITX = E_MI_SYS_UPGRADE_FW_TYPE_MIN,
    E_MI_SYS_UPGRADE_FW_TYPE_DISPOUT,

    E_MI_SYS_UPGRADE_FW_TYPE_MAX,
} MI_SYS_UpgradeFwType_e;

typedef enum
{
    E_MI_SYS_QUERY_GINGA_NCL_SUPPORTED = 0x16, //mapping to E_SYS_QUERY_GINGA_NCL_SUPPORTED
    E_MI_SYS_QUERY_IWEDIA_HTML5_SUPPORTED = 0x32, //mapping to E_SYS_QUERY_IWEDIA_HTML5_SUPPORTED
    E_MI_SYS_QUERY_IWEDIA_HBBTV_SUPPORTED = 0x33, //mapping to E_SYS_QUERY_IWEDIA_HBBTV_SUPPORTED
    E_MI_SYS_QUERY_IWEDIA_OPEN_BROWSER_SUPPORTED = 0x34, //mapping to E_SYS_QUERY_IWEDIA_OPEN_BROWSER_SUPPORTED
} MI_SYS_QuerySupported_e;

typedef struct MI_SYS_MmapLayout_s
{
    MI_SYS_MmapId_e eMmapId;                            ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///Mmap ID

    MI_SYS_MiuType_e eMiuType;                          ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///MIU type

    MI_PHY phyMiuBaseAddr;                              ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///Base address of MIU

    MI_PHY phyMemAddr;                                  ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///Memory address offset to phyMiuBaseAddr

    MI_U32 u32MemLen;                                   ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///Size of memory

    MI_SYS_MemType_e eMemType;                          ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///Size of memory

    MI_U32 u32CmaHid;                                   ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///Size of memory

    MI_SYS_CobufLayer_e eCoBufLayer;                    ///[IN]: for function MI_SYS_Init
                                                        ///[OUT]: for function MI_SYS_GetMmapLayout
                                                        ///Co_Buffer Layer

    MI_U8 au8TagName[32];                                ///[OUT]: Tag name

} MI_SYS_MmapLayout_t;

typedef struct MI_SYS_Mmap_s
{
    // Version of structure
    MI_U32 u32Version;                                  ///[IN]: should be MI_SYS_MMAP_PREFIX_VERSION

    // Memory Layout
    MI_U64 au64MiuIntervals[E_MI_SYS_MIU_TYPE_MAX];     ///[IN]: au64MiuIntervals[0]: MIU1 phyMiuBaseAddr, au64MiuIntervals[1]: MIU2 phyMiuBaseAddr
    MI_U32 u32MmapLayoutCnt;                            ///[IN]: Count of mmap layout
    MI_SYS_MmapLayout_t *pstMmapLayout;                 ///[IN]: array of mmap layout
} MI_SYS_Mmap_t;

typedef struct MI_SYS_BoardInfo_s
{
    MI_SYS_BoardInfoId_e eBoardInfoId;                  ///[IN]:< enum type of board info ID
    MI_U32 u32InfoLength;                               ///[IN]:< lenght of Board Info by bytes
    MI_U32 au32InfoValue[8];                            ///[IN]:< data pointer of Board Info
} MI_SYS_BoardInfo_t;

typedef struct MI_SYS_OsdInfo_s
{
    MI_SYS_OsdInfoId_e eOsdInfoId;                      ///[IN]:< enum type of osd info ID
    MI_U32 u32InfoLength;                               ///[IN]:< lenght of Osd Info by bytes
    MI_U32 au32InfoValue[8];                            ///[IN]:< data pointer of Osd Info
} MI_SYS_OsdInfo_t;

typedef struct MI_SYS_Board_s
{
    // Version of structure
    MI_U32 u32Version;                                  ///[IN]: version of Board Info

    // Board Info
    MI_U32 u32BoardInfoCnt;                             ///[IN]: Count of board info
    MI_SYS_BoardInfo_t *pstBoardInfo;                   ///[IN]: array of board info
} MI_SYS_Board_t;

typedef struct MI_SYS_Osd_s
{
    // Version of structure
    MI_U32 u32Version;                                  ///[IN]: version of Osd Info

    // Osd Info
    MI_U32 u32OsdInfoCnt;                               ///[IN]: Count of osd info
    MI_SYS_OsdInfo_t *pstOsdInfo;                       ///[IN]: array of osd info
} MI_SYS_Osd_t;

typedef struct MI_SYS_ModuleInfoParams_s
{
    MI_SYS_ModuleId_e eModuleId;                        ///[IN]: MI module id
    MI_BOOL bInited;                                    ///[IN]: Set init status for MI_SYS_SetAttr
                                                        ///[OUT]: Get init status for MI_SYS_GetAttr
} MI_SYS_ModuleInfoParams_t;

typedef struct MI_SYS_InitParams_s
{
    MI_U8 *pszMmapFileName;                             ///[IN]: mmap file name for auto parsing memory layout in MI_SYS, If both pszMmapFileName & pstMemLayout are set, the MI_SYS will choose pszMmapFileName for first priority
    MI_SYS_Mmap_t stMmap;                               ///[IN]: mmap configured step by step

    // Customer_Info.h
    MI_U8 *pu8CidBuf;                                   ///[IN]: CID_Buf[] in Customer_Info.h
    MI_U32 u32CidBufSize;                               ///[IN]: size of CID_Buf[]

    MI_U8 *pu8IpCtrlMapping1;                           ///[IN]: IP_Cntrol_Mapping_1[] in Customer_Info.h
    MI_U8 *pu8IpCtrlMapping2;                           ///[IN]: IP_Cntrol_Mapping_2[] in Customer_Info.h
    MI_U8 *pu8IpCtrlMapping3;                           ///[IN]: IP_Cntrol_Mapping_3[] in Customer_Info.h
    MI_U8 *pu8IpCtrlMapping4;                           ///[IN]: IP_Cntrol_Mapping_4[] in Customer_Info.h
    MI_U32 u32IpCtrlMappingSize;                        ///[IN]: size of each IP_Cntrol_Maping_X[]

    MI_U8 *pu8CustomerHash;                             ///[IN]: Customer_hash[] in Customer_Info.h
    MI_U32 u32CustomerHashSize;                         ///[IN]: size of Customer_hash[]

    // Board.h information
    MI_SYS_Board_t stBoard;                             ///[IN]: board information

} MI_SYS_InitParams_t;

typedef struct MI_SYS_SdkVersion_s
{
    MI_U32 u32SdkVersion;                               ///[OUT]: Version definition of SDK, 1.1: 0x0001 0001, 1.2: 0x0001 0002, 2.1: 0x0002 0001,....
    MI_U32 u32MmapVersion;                              ///[OUT]: MI_SYS_MMAP_PREFIX_VERSION
    MI_U8 au8BuildTime[32];                             ///[OUT]: the binary latest build date time
    MI_U8 au8MiSdkCommitId[50];                         ///[OUT]: git mi sdk commit id
    MI_U8 au8DdiMiscCommitId[50];                       ///[OUT]: git ddi misc commit id
    MI_U8 au8BspPkgCommitId[50];                        ///[OUT]: git bsp package commit id
    MI_U8 au8MiSdkTagName[50];                          ///[OUT]: git describe --tags
} MI_SYS_SdkVersion_t;

typedef enum
{
    E_MI_SYS_CONFIG_DATA_TYPE_INVALID = -1,
    E_MI_SYS_CONFIG_DATA_TYPE_MIN = 0,

    E_MI_SYS_CONFIG_DATA_TYPE_U32 = E_MI_SYS_CONFIG_DATA_TYPE_MIN,
    E_MI_SYS_CONFIG_DATA_TYPE_S32,
    E_MI_SYS_CONFIG_DATA_TYPE_DATA,

    E_MI_SYS_CONFIG_DATA_TYPE_MAX,
} MI_SYS_ConfigDataType_e;

typedef struct MI_SYS_ConfigData_s
{
    MI_SYS_ConfigDataType_e eDataType;                  ///[OUT]: data type
    union
    {
        MI_U32 u32Data;                                 ///[OUT]: data
        MI_S32 s32Data;                                 ///[OUT]: data
        struct
        {
            MI_U32 u32Len;                              ///[OUT]: data's length
            void *pBuf;                                 ///[OUT]: pointer to data's buffer
        } stData;                                       ///[OUT]: data
    } ;
} MI_SYS_ConfigData_t;

typedef enum
{
    E_MI_SYS_QOS_BW_SCALER = 0x00000001,
    E_MI_SYS_QOS_BW_FRC = 0x00000002,
    E_MI_SYS_QOS_BW_PNL = 0x00000004,
    E_MI_SYS_QOS_BW_PQ = 0x00000008,
    E_MI_SYS_QOS_BW_VDEC = 0x00000010,
    E_MI_SYS_QOS_BW_ALL = 0xFFFFFFFF,
} MI_SYS_QosBwModule_e;

typedef enum
{
    E_MI_SYS_QOS_BW_LEVEL,
    E_MI_SYS_QOS_BW_USAGE,
    E_MI_SYS_QOS_BW_MAX
} MI_SYS_QosBwTyoe_e;

typedef enum
{
  // Timeout
  E_MI_SYS_QOS_EVENT_TIMEOUT,
  E_MI_SYS_QOS_EVENT_BW_ADJUST,
  E_MI_SYS_QOS_EVENT_CODEC_CHANGE,
  E_MI_SYS_QOS_EVENT_INPUT_SOURCE_CHANGE,
  E_MI_SYS_QOS_EVENT_INPUT_SOURCE_READY,
  E_MI_SYS_QOS_EVENT_PVR,
  E_MI_SYS_QOS_EVENT_CAPTURE,
  E_MI_SYS_QOS_EVENT_AIPQ,
  E_MI_SYS_QOS_EVENT_VR360,
  E_MI_SYS_QOS_EVENT_ROTATE,
  E_MI_SYS_QOS_EVENT_VOICE,
  E_MI_SYS_QOS_EVENT_RESTART,
  E_MI_SYS_QOS_EVENT_MAX
} MI_SYS_QosEventType_e;

typedef enum
{
    E_MI_SYS_QOS_ADJUST_FIX,
    E_MI_SYS_QOS_ADJUST_AUTO_RESET,
    E_MI_SYS_QOS_ADJUST_MAX
} MI_SYS_QosAdjustType_e;

typedef struct MI_SYS_QOS_BwSetInfo_s
{
    MI_U32 u32Version;
    MI_U32 u32Length;
    MI_SYS_QosBwModule_e eModule;       // adjust bandwidth module, ex: scaler.
    MI_SYS_QosBwTyoe_e eBwType;         // specify adjust bandwidth level or usage.
    MI_S32 s32BwValue;                  // specify bandwidth value depend on enBwType.
    MI_SYS_QosAdjustType_e eAdjType;    // adjust type
} MI_SYS_QOS_BwSetInfo_t;

typedef struct MI_SYS_QOS_BwGetInfo_s
{
    MI_U32 u32Version;
    MI_U32 u32Length;
    MI_U32 u32BwUsage;                  // percentage of bandwidth usage.
    MI_U32 u32TotalBw;                  // Total bandwidth.
} MI_SYS_QOS_BwGetInfo_t;

typedef struct MI_SYS_QOS_STATUS_s
{
    MI_U32 u32Version;
    MI_U32 u32Length;
    MI_BOOL bSysEnable;                 // QoS system enable flag.
    MI_BOOL bAutoAdjBwEnable;           // QoS auto adjust bandwidth enable flag
} MI_SYS_QOS_STATUS_t;

typedef struct MI_SYS_QOS_InputSourceInfo_s
{
  MI_U32 u32Version;
  MI_U32 u32Length;
  MI_U32 u32WinId;
  MI_U32 u32InputSource;
  MI_U32 u32Format;
  MI_U32 u32Width;
  MI_U32 u32Height;
  MI_U32 u32Fps;
} MI_SYS_QOS_InputSourceInfo_t;

typedef struct MI_SYS_QOS_SetModuleStatus_s
{
    MI_U32 u32Version;
    MI_U32 u32Length;
    MI_SYS_QosEventType_e eEventType;
    MI_SYS_QOS_BwSetInfo_t AdjustInfo;
    MI_SYS_QOS_InputSourceInfo_t InputSourceInfo;
    MI_BOOL bPvrEn;
    MI_BOOL bCapEn;
    MI_BOOL bAiPqEn;
    MI_BOOL bVr360En;
    MI_BOOL bRotateEn;
    MI_BOOL bVoiceEn;
} MI_SYS_QOS_SetModuleStatus_t;

//-------------------------------------------------------------------------------------------------
//  Global Functions
//-------------------------------------------------------------------------------------------------

//------------------------------------------------------------------------------
/// @brief Init SYSTEM module.
/// @param[in] pstInitParams: A pointer to structure MI_SYS_InitParams_t for initialization.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_RESOURCES: No available resource.
/// @return MI_ERR_MEMORY_ALLOCATE: Allocate memory fail.
/// @return MI_ERR_LIMITION: (EnvMmap) MMAP end address over MIU size.
/// @return MI_ERR_DATA_ERROR: Invalid MMAP name string array index.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_Init(const MI_SYS_InitParams_t *pstInitParams);

//------------------------------------------------------------------------------
/// @brief Exit and finalize SYSTEM module.
/// @return MI_OK: Process success.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_DeInit(void);

//------------------------------------------------------------------------------
/// @brief Get the hardware memory layout current stored.
/// @param[in] eMmapId ID of memory map
/// @param[out] pstMmapLayout Pointer to struct MI_SYS_MmapLayout_t to retrieve the memory map of the specified mmap id.
/// @return MI_OK: Process success.
/// @return MI_ERR_INVALID_PARAMETER: Invalid parameter.
/// @return MI_ERR_NOT_INITED: Module hasn't be inited.
/// @return MI_ERR_DATA_ERROR: MMAP layout not configured.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_GetMmapLayout(MI_SYS_MmapId_e eMmapId, MI_SYS_MmapLayout_t *pstMmapLayout);

//------------------------------------------------------------------------------
/// @brief Get Memory pool ID.
/// @param[out] ps32CachedPoolId: Pointer to retrieve the pool id of cached memory. Set NULL to ignore.
/// @param[out] ps32NonCachedPoolId: Pointer to retrieve the pool id of Noncached memory. Set NULL to ignore.
/// @return MI_OK: Process success.
/// @return MI_ERR_NOT_INITED: MI_SYS hasn't been inited.
/// @return MI_ERR_INVALID_PARAMETER: Parameters is invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_GetMemPoolId(MI_S32 *ps32CachedPoolId, MI_S32 *ps32NonCachedPoolId);

//------------------------------------------------------------------------------
/// @brief Get customer bonding information.
/// @param[in] eCustomerId: Customer ID.
/// @param[out] pInfo: Pointer to output information.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_GetCustomerBondingInfo(MI_SYS_Customer_e eCustomerId, void* pInfo);

//------------------------------------------------------------------------------
/// @brief Upgrade FW
/// @param[in] eFwType: FW type
/// @param[in] pBinPath: FW file path
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_UpgradeFw(MI_SYS_UpgradeFwType_e eFwType, MI_U8 *pszBinPath);

//------------------------------------------------------------------------------
/// @brief Set SYS Attribute.
/// @param[in] eAttrType: for sys module function type
/// @param[in] pAttrParams: Pointer to input information.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_SetAttr(MI_SYS_AttrType_e eAttrType, const void* pAttrParams);

//------------------------------------------------------------------------------
/// @brief Get SYS Attribute.
/// @param[in] eAttrType: for sys module function type
/// @param[out] pAttrParams: Pointer to output information.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_GetAttr(MI_SYS_AttrType_e eAttrType, void* pAttrParams);

//------------------------------------------------------------------------------
/// @brief Set SYS ConfigInfo.
/// @param[in] eConfigInfoType: for sys config info type
/// @param[in] pCfgInfoParam: Pointer to input information.
/// @return MI_OK: Process success.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_SetCfgInfo(MI_SYS_ConfigInfoType_e eConfigInfoType, const void *pCfgInfoParam);

//------------------------------------------------------------------------------
/// @brief Set debug level.
/// @param[in] u32DebugLevel: Debug level
/// @return MI_OK: Set debug level success.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_SetDebugLevel(MI_DBG_LEVEL u32DebugLevel);

//------------------------------------------------------------------------------
/// @brief OpenConfigFile.
/// @param[in] pszPath: config file path
/// @param[in] phSysConfig: ini file handle
/// @return MI_OK: Process ok.
/// @return MI_ERR_RESOURCES: system resource issue
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_OpenConfigFile(const MI_U8 *pszPath, MI_HANDLE *phSysConfig);

//------------------------------------------------------------------------------
/// @brief CloseConfigFile.
/// @param[in] hSysConfig: ini file handle
/// @return MI_OK: Process ok.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_CloseConfigFile(MI_HANDLE hSysConfig);

//------------------------------------------------------------------------------
/// @brief GetConfigData.
/// @param[in] hSysConfig: ini file handle
/// @param[in] pszKeyName: key name in ini file
/// @param[in] pstConfigData: config data in ini file
/// @return MI_OK: Process ok.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_GetConfigData(MI_HANDLE hSysConfig, const MI_U8 *pszKeyName, MI_SYS_ConfigData_t *pstConfigData);

//------------------------------------------------------------------------------
/// @brief SetConfigData.
/// @param[in] hSysConfig: ini file handle
/// @param[in] pszKeyName: key name in ini file
/// @param[in] pstConfigData: config data to be set in ini file
/// @return MI_OK: Process ok.
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_SetConfigData(MI_HANDLE hSysConfig, const MI_U8 *pszKeyName, MI_SYS_ConfigData_t *pstConfigData);

//------------------------------------------------------------------------------
/// @brief Check IP hash key.
/// @param[in] u32IpBit: IP's bit.
/// @param[out] pbSupported: The checking result for u32IpBit.
/// @return MI_OK: Process ok.
/// @return MI_ERR_NOT_SUPPORT: Not support for checking this IP.
/// @return MI_ERR_NOT_INITED: Module hasn't be inited.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_CheckIpHashKey(MI_U32 u32IpBit, MI_BOOL *pbSupported);

//------------------------------------------------------------------------------
/// @brief Query Efuse.
/// @param[in] eQuerySupported: for querying supported IP
/// @param[out] pbSupported: The checking result for eQuerySupported.
/// @return MI_OK: Process ok.
/// @return MI_ERR_NOT_SUPPORT: Not support for checking this IP.
/// @return MI_ERR_NOT_INITED: Module hasn't be inited.
/// @return MI_ERR_INVALID_PARAMETER: Parameters are invalid.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_QueryEfuse(MI_SYS_QuerySupported_e eQuerySupported, MI_BOOL *pbSupported);

//------------------------------------------------------------------------------
/// @brief Allocate the hardware memory layout current stored. (DEDICATE/CMA/MMA-IOMMU/MMA-CMA)
/// @param[in] eMmapId ID of memory map
/// @param[out] pstMmapLayout Pointer to struct MI_SYS_MmapLayout_t to retrieve the memory map of the specified mmap id.
/// @return MI_OK
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_AllocateMmapLayout(MI_SYS_MmapId_e eMmapId, MI_SYS_MmapLayout_t *pstMmapLayout);

//------------------------------------------------------------------------------
/// @brief Free the hardware memory layout current stored. (DEDICATE/CMA/MMA-IOMMU/MMA-CMA)
/// @param[in] eMmapId ID of memory map
/// @return MI_OK
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_FreeMmapLayout(MI_SYS_MmapId_e eMmapId);

//------------------------------------------------------------------------------
/// @brief mapping the hardware memory layout current stored. (DEDICATE/CMA/MMA-IOMMU/MMA-CMA)
/// @param[in] eMmapId ID of memory map
/// @param[in] pstMmapLayout Pointer to struct MI_SYS_MmapLayout_t to enter eMemTyp, u32MemLen, phyMemAddr
/// @return MI_OK
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_MappingMmapLayout(MI_SYS_MmapId_e eMmapId, MI_SYS_MmapLayout_t *pstMmapLayout);

//------------------------------------------------------------------------------
/// @brief unmapping the hardware memory layout current stored. (DEDICATE/CMA/MMA-IOMMU/MMA-CMA)
/// @param[in] eMmapId ID of memory map
/// @param[in] pstMmapLayout Pointer to struct MI_SYS_MmapLayout_t to enter u32MemLen, phyMemAddr
/// @return MI_OK
/// @return MI_ERR_INVALID_HANDLE: invalid handle.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_UnMappingMmapLayout(MI_SYS_MmapId_e eMmapId, MI_SYS_MmapLayout_t *pstMmapLayout);

//------------------------------------------------------------------------------
/// @brief Set memory ssc (spread spectrum clock) value.
/// @param[in] eMiuType: Miu device.
/// @param[in] u32SscFrequency: Spread spectrum frequency. (Unit: KHz)
/// @param[in] u32SscRatio: Spread spectrum deviation. (Unit: 0.1%)
/// @param[in] bEnable: Enable ssc feature or not.
/// @return MI_OK: Process ok.
/// @return MI_ERR_NOT_INITED: Module hasn't be inited.
/// @return MI_ERR_FAILED: Process fail.
//------------------------------------------------------------------------------
MI_RESULT MI_SYS_SetMiuSsc(MI_SYS_MiuType_e eMiuType, MI_U32 u32SscFrequency, MI_U32 u32SscRatio, MI_BOOL bEnable);

//------------------------------------------------------------------------------
/// @brief
/// @param[in] pstQosBwAdjustInfo: Qos Bandwidth Adjust Info
/// @return MI_OK: Process ok.
/// @return MI_ERR_FAILED: Process fail.
MI_RESULT MI_SYS_QOS_SetBwInfo(MI_SYS_QOS_BwSetInfo_t *pstQosBwSetInfo);

//------------------------------------------------------------------------------
/// @brief
/// @param[in] pstQosBwGetInfo: Qos Bandwidth Info
/// @return MI_OK: Process ok.
/// @return MI_ERR_FAILED: Process fail.
MI_RESULT MI_SYS_QOS_GetBwInfo(MI_SYS_QOS_BwGetInfo_t *pstQosBwGetInfo);

//------------------------------------------------------------------------------
/// @brief
/// @param[in] pstQosStatus: Qos Status
/// @return MI_OK: Process ok.
/// @return MI_ERR_FAILED: Process fail.
MI_RESULT MI_SYS_QOS_SetStatus(MI_SYS_QOS_STATUS_t *pstQosStatus);

//------------------------------------------------------------------------------
/// @brief
/// @param[in] pstQosStatus: Qos Status
/// @return MI_OK: Process ok.
/// @return MI_ERR_FAILED: Process fail.
MI_RESULT MI_SYS_QOS_GetStatus(MI_SYS_QOS_STATUS_t *pstQosStatus);

//------------------------------------------------------------------------------
/// @brief
/// @param[in] pstQosStatus: Set Qos modue status
/// @return MI_OK: Process ok.
/// @return MI_ERR_FAILED: Process fail.
MI_RESULT MI_SYS_QOS_SetModuleStatus(MI_SYS_QOS_SetModuleStatus_t *pstQosSetModuleStatus);


#ifdef __cplusplus
}
#endif

#endif///_MI_SYS_H_
