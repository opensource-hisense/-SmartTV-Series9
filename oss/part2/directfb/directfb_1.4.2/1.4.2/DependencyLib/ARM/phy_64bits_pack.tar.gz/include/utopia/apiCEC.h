//<MStar Software>
//******************************************************************************
// MStar Software
// Copyright (c) 2010 - 2012 MStar Semiconductor, Inc. All rights reserved.
// All software, firmware and related documentation herein ("MStar Software") are
// intellectual property of MStar Semiconductor, Inc. ("MStar") and protected by
// law, including, but not limited to, copyright law and international treaties.
// Any use, modification, reproduction, retransmission, or republication of all
// or part of MStar Software is expressly prohibited, unless prior written
// permission has been granted by MStar.
//
// By accessing, browsing and/or using MStar Software, you acknowledge that you
// have read, understood, and agree, to be bound by below terms ("Terms") and to
// comply with all applicable laws and regulations:
//
// 1. MStar shall retain any and all right, ownership and interest to MStar
//    Software and any modification/derivatives thereof.
//    No right, ownership, or interest to MStar Software and any
//    modification/derivatives thereof is transferred to you under Terms.
//
// 2. You understand that MStar Software might include, incorporate or be
//    supplied together with third party`s software and the use of MStar
//    Software may require additional licenses from third parties.
//    Therefore, you hereby agree it is your sole responsibility to separately
//    obtain any and all third party right and license necessary for your use of
//    such third party`s software.
//
// 3. MStar Software and any modification/derivatives thereof shall be deemed as
//    MStar`s confidential information and you agree to keep MStar`s
//    confidential information in strictest confidence and not disclose to any
//    third party.
//
// 4. MStar Software is provided on an "AS IS" basis without warranties of any
//    kind. Any warranties are hereby expressly disclaimed by MStar, including
//    without limitation, any warranties of merchantability, non-infringement of
//    intellectual property rights, fitness for a particular purpose, error free
//    and in conformity with any international standard.  You agree to waive any
//    claim against MStar for any loss, damage, cost or expense that you may
//    incur related to your use of MStar Software.
//    In no event shall MStar be liable for any direct, indirect, incidental or
//    consequential damages, including without limitation, lost of profit or
//    revenues, lost or damage of data, and unauthorized system use.
//    You agree that this Section 4 shall still apply without being affected
//    even if MStar Software has been modified by MStar in accordance with your
//    request or instruction for your use, except otherwise agreed by both
//    parties in writing.
//
// 5. If requested, MStar may from time to time provide technical supports or
//    services in relation with MStar Software to you for your use of
//    MStar Software in conjunction with your or your customer`s product
//    ("Services").
//    You understand and agree that, except otherwise agreed by both parties in
//    writing, Services are provided on an "AS IS" basis and the warranty
//    disclaimer set forth in Section 4 above shall apply.
//
// 6. Nothing contained herein shall be construed as by implication, estoppels
//    or otherwise:
//    (a) conferring any license or right to use MStar name, trademark, service
//        mark, symbol or any other identification;
//    (b) obligating MStar or any of its affiliates to furnish any person,
//        including without limitation, you and your customers, any assistance
//        of any kind whatsoever, or any information; or
//    (c) conferring any license or right under any intellectual property right.
//
// 7. These terms shall be governed by and construed in accordance with the laws
//    of Taiwan, R.O.C., excluding its conflict of law rules.
//    Any and all dispute arising out hereof or related hereto shall be finally
//    settled by arbitration referred to the Chinese Arbitration Association,
//    Taipei in accordance with the ROC Arbitration Law and the Arbitration
//    Rules of the Association by three (3) arbitrators appointed in accordance
//    with the said Rules.
//    The place of arbitration shall be in Taipei, Taiwan and the language shall
//    be English.
//    The arbitration award shall be final and binding to both parties.
//
//******************************************************************************
//<MStar Software>
////////////////////////////////////////////////////////////////////////////////
//
// Copyright (c) 2008-2009 MStar Semiconductor, Inc.
// All rights reserved.
//
// Unless otherwise stipulated in writing, any and all information contained
// herein regardless in any format shall remain the sole proprietary of
// MStar Semiconductor Inc. and be kept in strict confidence
// ("MStar Confidential Information") by the recipient.
// Any unauthorized act including without limitation unauthorized disclosure,
// copying, use, reproduction, sale, distribution, modification, disassembling,
// reverse engineering and compiling of the contents of MStar Confidential
// Information is unlawful and strictly prohibited. MStar hereby reserves the
// rights to any and all damages, losses, costs and expenses resulting therefrom.
//
////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////
///
/// @file   apiCEC.h
/// @brief  CEC Interface
/// @author MStar Semiconductor Inc.
///////////////////////////////////////////////////////////////////////////////////////////////////

/*! \defgroup MISC HDMI modules

    <b> CEC (Consumer Electronics Control) </b>\n
    - In Europe, there was an analog predecessor to HDMI known as the SCART interface. Like HDMI, SCART carried audio and video signals through one cable. The SCART cable had a one-wire bus for controlling a home theater system.  This was branded as AV.link by Philips, among others. This bus supported one touch play, standby, etc.\n
    For more information,see \link APICEC apiCEC interface (apiCEC.h) \endlink \n

    <b> DAC(digital-to-analog converter,DAC)</b>\n
    - Convert digital signal to analog signal.\n
    For more information,see \link DAC DAC interface (apiDAC.h) \endlink \n

    <b> MHL interface </b>
    - Check whether MHL cable is plugged or not in Rx side
    - Disable R-term and output Vbus
    - Check whether Cbus is connected(discovery pulse completed)
    - Sink -> Source: "SET_HPD"
    - Sink -> Source: Write_Stat - "DCAP_RDY" and Write_INT - "DCAP_CHG"
    - Sink -> Source: Write_Stat - "PATH_EN"\n
    For more information,see \link MHL MHL interface (apiMHL.h)  \endlink \n

    <b> HDMI interface </b>
    - HDMI Ethernet Channel
    Support Ethernet communication through HDMI
    - Audio Return Channel
    - 3D support
    - Frame packing, Side-by-Side half, Top-Buttom and etc.
    - 4Kx2K support
    3840x2160@24/25/30Hz, 4096x2160@24Hz
    - Additional Color Spaces
    sYCC601, AdobeRGB, AdobeYCC601
    - HDMI Micro Connector
    19-pin/1080p\n
    For more information,see \link APICEC apiCEC interface (apiCEC.h)  \endlink \n

 * \defgroup APICEC apiCEC interface (apiCEC.h)
 * \ingroup MISC

   <b> CEC (Consumer Electronics Control) </b>
    In Europe, there was an analog predecessor to HDMI known as the SCART interface. Like HDMI, SCART carried audio and video signals through one cable. The SCART cable had a one-wire bus for controlling a home theater system.  This was branded as AV.link by Philips, among others. This bus supported one touch play, standby, etc.


   <b> CEC layout </b>
   \image html apiCEC_pic1.png
   \image html apiCEC_pic2.png

   <b>Feature </b>
   - Device OSD Name Transfer - Enables devices to upload their preferred OSD name to the TV. The TV can then use this name in any menus associated with that device.
   - Device Power Status ?Allows the current power status of a device to be discovered.
   - OSD Display - Enables a device to use the on-screen display of the TV to display text strings.
   - Routing Control - Allows the control of CEC Switches for streaming of a new source device.
   - System Information - Queries the system to determine device addresses and language.
   - Vendor Specific Commands - Allows a set of vendor-defined commands to be used between devices of that vendor.
   - Audio Rate Control ?Allows an Amplifier to fractionally increase or decrease the playback rate of an audio source.

   \image html apiCEC_pic3.png
   \image html apiCEC_pic4.png


 * \defgroup apiCEC_BASIC apiCEC Module basic
 * \ingroup APICEC

 * \dergroup apiCEC_Message send messge
 * \ingroup APICEC

*! \dergroup apiCEC_STATUS CEC status
* \ingroup APICEC

*! \dergroup apiCEC_SECOND support second LA
* \ingroup APICEC

*! \dergroup apiCEC_ToBeRemove apiCEC api to be removed
* \ingroup APICEC

*! \dergroup apiCEC_ToBeAdd apiCEC api to be added
* \ingroup APICEC

*/

#ifndef _APICEC_H_
#define _APICEC_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include "MsTypes.h"
#include "MsDevice.h"
#include "MsCommon.h"


//-------------------------------------------------------------------------------------------------
//  Macro and Define
//-------------------------------------------------------------------------------------------------
#define MSIF_CEC_LIB_CODE               {'C','E','C','_'}
#define MSIF_CEC_LIBVER                 {'0','0'}                         /* 0.0 ~ Z.Z */
#define MSIF_CEC_BUILDNUM               {'0','8'}                         /* 00 ~ 99   */
#define MSIF_CEC_CHANGELIST             {'0','0','4','4','9','9','9','1'} /* CL#       */
#define CEC_API_VERSION                  /* Character String for DRV/API version             */  \
    MSIF_TAG,                           /* 'MSIF'                                           */  \
    MSIF_CLASS,                         /* '00'                                             */  \
    MSIF_CUS,                           /* 0x0000                                           */  \
    MSIF_MOD,                           /* 0x0000                                           */  \
    MSIF_CHIP,                                                                                  \
    MSIF_CPU,                                                                                   \
    MSIF_CEC_LIB_CODE,                  /* IP__                                             */  \
    MSIF_CEC_LIBVER,                    /* 0.0 ~ Z.Z                                        */  \
    MSIF_CEC_BUILDNUM,                  /* 00 ~ 99                                          */  \
    MSIF_CEC_CHANGELIST,                /* CL#                                              */  \
    MSIF_OS

#define CEC_VERSION_11      0UL   //CEC1.1
#define CEC_VERSION_12      1UL   //CEC1.2
#define CEC_VERSION_12a     2UL   //CEC1.2a
#define CEC_VERSION_13      3UL   //CEC1.3
#define CEC_VERSION_13a     4UL   //CEC1.3a
#define CEC_VERSION_14      5UL   //CEC1.4

#define HDMI_CEC_VERSION    CEC_VERSION_14

#define CEC_FIFO_CNT                4UL
#define CEC_FIFO_NUM_COUNT          CEC_FIFO_CNT
#define CEC_PHY_ADDR_COUNT          2UL
#define CEC_DEVICE_EXIST_COUNT      15UL
#define CEC_FIFO_DATA_NUMBER        16UL
#define CEC_VENDOR_ID_COUNT         3UL
#define CEC_MENU_LANGUAGE_COUNT     3UL

#define RETRY_CNT          1UL
#define FrameInterval      7UL
#define BusFreeTime        6UL//5 // Free bit time by IC design has a little difference than spec, set to 6 instead of 5
#define ReTxInterval       3UL

#define ENABLE_CEC_INT                  ENABLE
#define ENABLE_CUST01_CEC               ENABLE
#define ENABLE_SW_CEC_WAKEUP            ENABLE
#define ENABLE_CEC_MULTIPLE             DISABLE

//-------------------------------------------------------------------------------------------------
//  Type and Structure
//-------------------------------------------------------------------------------------------------

typedef enum _MsCEC_INPUT_PORT
{
    INPUT_PORT0 = 0x00,
    INPUT_PORT1 = 0x01,
    INPUT_PORT2 = 0x02,
    INPUT_PORT3 = 0x03,
}MsCEC_INPUT_PORT;

typedef enum _CEC_ERROR_CODE
{
    E_CEC_FEATURE_ABORT = 0x00,
    E_CEC_RX_SUCCESS    = 0x01,
    E_CEC_TX_SUCCESS    = 0x02,
    E_CEC_RF            = 0x04,
    E_CEC_LOST_ABT      = 0x08,
    E_CEC_BIT_SHORT     = 0x10,
    E_CEC_BIT_LONG      = 0x20,
    E_CEC_NACK          = 0x40,
    E_CEC_SYSTEM_BUSY   = 0x80,
} CEC_ERROR_CODE;

//Logical Address
typedef enum _MsCEC_DEVICELA
{
    E_LA_TV              =0,
    E_LA_RECORDER1       =1,
    E_LA_RECORDER2       =2,
    E_LA_TUNER1          =3,
    E_LA_PLAYBACK1       =4,
    E_LA_AUDIO_SYS       =5,
    E_LA_TUNER2          =6,
    E_LA_TUNER3          =7,
    E_LA_PLAYBACK2       =8,
    E_LA_RECORER3        =9,
#if(HDMI_CEC_VERSION >= CEC_VERSION_13a)
    E_LA_TUNER4          =10,
    E_LA_PLYBACK3        =11,
#endif
    RESERVED_1            =12,
    RESERVED_2            =13,
    E_LA_FREE_USE        =14,
    E_LA_UNREGISTERED    =15,
    E_LA_BROADCAST       =15,
    E_LA_MAX =15,
} MsCEC_DEVICELA;

//the opcode is referenced from CEC1.3a table 7 ~ 27
typedef enum _MsCEC_MSGLIST
{
//----- One Touch Play ----------------------------
    E_MSG_ACTIVE_SOURCE                         = 0x82,
    E_MSG_OTP_IMAGE_VIEW_ON                     = 0x04,
    E_MSG_OTP_TEXT_VIEW_ON                      = 0x0D,


//----- Routing Control ---------------------------
    //E_MSG_RC_ACTIVE_SOURCE                      = 0x82,
    E_MSG_RC_INACTIVE_SOURCE                    = 0x9D,

    E_MSG_RC_REQ_ACTIVE_SOURCE                  = 0x85, // should be removed
    E_MSG_RC_REQUEST_ACTIVE_SOURCE              = 0x85,

    E_MSG_RC_ROUTING_CHANGE                     = 0x80,

    E_MSG_RC_ROUTING_INFO                       = 0x81, // should be removed
    E_MSG_RC_ROUTING_INFORMATION                = 0x81,

    E_MSG_RC_SET_STREM_PATH                     = 0x86,


//----- Standby Command ---------------------------
    E_MSG_STANDBY                               = 0x36,


//----- One Touch Record---------------------------
    E_MSG_OTR_RECORD_OFF                        = 0x0B,
    E_MSG_OTR_RECORD_ON                         = 0x09,
    E_MSG_OTR_RECORD_STATUS                     = 0x0A,
    E_MSG_OTR_RECORD_TV_SCREEN                  = 0x0F,


//----- Timer programmer -------------------------- CEC1.3a
    E_MSG_TP_CLEAR_ANALOG_TIMER                 = 0x33, // should be removed
    E_MSG_TP_CLEAR_ANALOGUE_TIMER               = 0x33,

    E_MSG_TP_CLEAR_DIGITAL_TIMER                = 0x99,

    E_MSG_TP_CLEAR_EXT_TIMER                    = 0xA1, // should be removed
    E_MSG_TP_CLEAR_EXTERNAL_TIMER               = 0xA1,

    E_MSG_TP_SET_ANALOG_TIMER                   = 0x34, // should be removed
    E_MSG_TP_SET_ANALOGUE_TIMER                 = 0x34,

    E_MSG_TP_SET_DIGITAL_TIMER                  = 0x97,

    E_MSG_TP_SET_EXT_TIMER                      = 0xA2, // should be removed
    E_MSG_TP_SET_EXTERNAL_TIMER                 = 0xA2,

    E_MSG_TP_SET_TIMER_PROGRAM_TITLE            = 0x67,
    E_MSG_TP_TIMER_CLEARD_STATUS                = 0x43,
    E_MSG_TP_TIMER_STATUS                       = 0x35,


//----- System Information ------------------------
    E_MSG_SI_CEC_VERSION                        = 0x9E,       //1.3a
    E_MSG_SI_GET_CEC_VERSION                    = 0x9F,       //1.3a

    E_MSG_SI_REQUEST_PHY_ADDR                   = 0x83, // should be removed
    E_MSG_SI_GIVE_PHYSICAL_ADDRESS              = 0x83,

    E_MSG_SI_GET_MENU_LANGUAGE                  = 0x91,
    //E_MSG_SI_POLLING_MESSAGE                    = ?,

    E_MSG_SI_REPORT_PHY_ADDR                    = 0x84, // should be removed
    E_MSG_SI_REPORT_PHYSICAL_ADDRESS            = 0x84,

    E_MSG_SI_SET_MENU_LANGUAGE                  = 0x32,

    //E_MSG_SI_REC_TYPE_PRESET                    = 0x00,  //parameter   ?
    //E_MSG_SI_REC_TYPE_OWNSRC                    = 0x01,  //parameter   ?


//----- Deck Control Feature-----------------------
    E_MSG_DC_DECK_CTRL                          = 0x42, // should be removed
    E_MSG_DC_DECK_CONTROL                       = 0x42,

    E_MSG_DC_DECK_STATUS                        = 0x1B,
    E_MSG_DC_GIVE_DECK_STATUS                   = 0x1A,
    E_MSG_DC_PLAY                               = 0x41,


//----- Tuner Control ------------------------------
    E_MSG_TC_GIVE_TUNER_STATUS                  = 0x08, // should be removed
    E_MSG_TC_GIVE_TUNER_DEVICE_STATUS           = 0x08,

    E_MSG_TC_SEL_ANALOG_SERVICE                 = 0x92, // should be removed
    E_MSG_TC_SEL_ANALOGUE_SERVICE               = 0x92,

    E_MSG_TC_SEL_DIGITAL_SERVICE                = 0x93, // should be removed
    E_MSG_TC_SELECT_DIGITAL_SERVICE             = 0x93,

    E_MSG_TC_TUNER_DEVICE_STATUS                = 0x07,

    E_MSG_TC_TUNER_STEP_DEC                     = 0x06, // should be removed
    E_MSG_TC_TUNER_STEP_DECREMENT               = 0x06,

    E_MSG_TC_TUNER_STEP_INC                     = 0x05, // should be removed
    E_MSG_TC_TUNER_STEP_INCREMENT               = 0x05,


//---------Vendor Specific -------------------------
    //E_MSG_VS_CEC_VERSION                        = 0x9E,       //1.3a
    E_MSG_VS_DEVICE_VENDOR_ID                   = 0x87,
    //E_MSG_VS_GET_CEC_VERSION                    = 0x9F,       //1.3a

    E_MSG_VS_GIVE_VENDOR_ID                     = 0x8C, // should be removed
    E_MSG_VS_GIVE_DEVICE_VENDOR_ID              = 0x8C,

    E_MSG_VS_VENDOR_COMMAND                     = 0x89,
    E_MSG_VS_VENDOR_COMMAND_WITH_ID             = 0xA0,      //1.3a

    E_MSG_VS_VENDOR_RC_BUT_DOWN                 = 0x8A, // should be removed
    E_MSG_VS_VENDOR_REMOTE_BUTTON_DOWN          = 0x8A,

    E_MSG_VS_VENDOR_RC_BUT_UP                   = 0x8B, // should be removed
    E_MSG_VS_VENDOR_REMOTE_BUTTON_UP            = 0x8B,


//----- OSD Display --------------------------------
    E_MSG_SET_OSD_STRING                        = 0x64,


//----- Device OSD Name Transfer  -------------------------
    E_MSG_OSDNT_GIVE_OSD_NAME                   = 0x46,
    E_MSG_OSDNT_SET_OSD_NAME                    = 0x47,


//----- Device Menu Control ------------------------
    E_MSG_DMC_MENU_REQUEST                      = 0x8D,
    E_MSG_DMC_MENU_STATUS                       = 0x8E,
    //E_MSG_DMC_MENU_ACTIVATED                    = 0x00,   //parameter
    //E_MSG_DMC_MENU_DEACTIVATED                  = 0x01,   //parameter

    E_MSG_UI_PRESS                              = 0x44, // should be removed
    E_MSG_DMC_USER_CONTROL_PRESSED              = 0x44,

    E_MSG_UI_RELEASE                            = 0x45, // should be removed
    E_MSG_DMC_USER_CONTROL_RELEASED             = 0x45,


//----- Remote Control Passthrough ----------------
//----- UI Message --------------------------------
//    E_MSG_RCP_USER_CONTROL_PRESSED              = 0x44,
//    E_MSG_RCP_USER_CONTROL_RELEASED             = 0x45,


//----- Power Status  ------------------------------
    E_MSG_PS_GIVE_POWER_STATUS                  = 0x8F, // should be removed
    E_MSG_PS_GIVE_DEVICE_POWER_STATUS           = 0x8F,

    E_MSG_PS_REPORT_POWER_STATUS                = 0x90,


//----- General Protocal Message ------------------

//----- Feature Abort -----------------------------
    E_MSG_FEATURE_ABORT                         = 0x00,

//----- Abort Message -----------------------------
    E_MSG_ABORT_MESSAGE                         = 0xFF,


//----- System Audio Control ------------------
    E_MSG_SAC_GIVE_AUDIO_STATUS                 = 0x71,
    E_MSG_SAC_GIVE_SYSTEM_AUDIO_MODE_STATUS     = 0x7D,
    E_MSG_SAC_REPORT_AUDIO_STATUS               = 0x7A,

    E_MSG_SAC_REPORT_SHORT_AUDIO_DESCRIPTOR     = 0xA3,
    E_MSG_SAC_REQUEST_SHORT_AUDIO_DESCRIPTOR    = 0xA4,

    E_MSG_SAC_SET_SYSTEM_AUDIO_MODE             = 0x72,
    E_MSG_SAC_SYSTEM_AUDIO_MODE_REQUEST         = 0x70,
    E_MSG_SAC_SYSTEM_AUDIO_MODE_STATUS          = 0x7E,


//----- System Audio Control ------------------
    E_MSG_SAC_SET_AUDIO_RATE                    = 0x9A,


//----- Audio Return Channel  Control ------------------
    E_MSG_ARC_INITIATE_ARC                      = 0xC0,
    E_MSG_ARC_REPORT_ARC_INITIATED              = 0xC1,
    E_MSG_ARC_REPORT_ARC_TERMINATED             = 0xC2,

    E_MSG_ARC_REQUEST_ARC_INITATION             = 0xC3, // should be removed
    E_MSG_ARC_REQUEST_ARC_INITIATION            = 0xC3,

    E_MSG_ARC_REQUEST_ARC_TERMINATION           = 0xC4,

    E_MSG_ARC_TERMINATED_ARC                    = 0xC5, // should be removed
    E_MSG_ARC_TERMINATE_ARC                     = 0xC5,


//----- Capability Discovery and Control ------------------
    E_MSG_CDC_CDC_MESSAGE                       = 0xF8,

} MsCEC_MSGLIST;

typedef enum _MsCEC_MSG_TRANS_TYPE
{
    E_TRANS_BROADCAST_MSG   = 0,
    E_TRANS_DIRECT_MSG      = 1,
    E_TRANS_BOTHTYPE_MSG    = 2,
} MsCEC_MSG_TRANS_TYPE;


//Device Type, 1byte
typedef enum _MsCEC_DEVICE_TYPE
{
    E_DEVICE_TYPE_TV                    =0,
    E_DEVICE_TYPE_RECORDING_DEVICE      =1,
    E_DEVICE_TYPE_RESERVED              =2,
    E_DEVICE_TYPE_TUNER                 =3,
    E_DEVICE_TYPE_PLAYBACK_DEVICE       =4,
    E_DEVICE_TYPE_AUDIO_SYSTEM          =5,
} MsCEC_DEVICE_TYPE;


//Deck Control, Deck Control Mode 1 byte
typedef enum _MsCEC_MSG_DC_DECK_CTRL_PARM
{
    E_MSG_DCM_CMD_SKIP_FORWARD          = 1,  //parameter
    E_MSG_DCM_CMD_SKIP_REVERSE          = 2,  //parameter
    E_MSG_DCM_CMD_STOP                  = 3,  //parameter
    E_MSG_DCM_CMD_EJECT                 = 4,  //parameter
} MsCEC_MSG_DC_DECK_CTRL_PARM;

//Deck status, Deck info 1 byte
typedef enum _MsCEC_MSG_DC_DECK_STATUS_PARM
{
    E_MSG_DI_CMD_PLAY                   = 0x11,  //parameter
    E_MSG_DI_CMD_RECORD                 = 0x12,  //parameter
    E_MSG_DI_CMD_PLAY_REVERSE           = 0x13,  //parameter
    E_MSG_DI_CMD_STILL                  = 0x14,  //parameter
    E_MSG_DI_CMD_SLOW                   = 0x15,  //parameter
    E_MSG_DI_CMD_SLOW_REVERSE           = 0x16,  //parameter
    E_MSG_DI_CMD_FAST_FORWARD           = 0x17,  //parameter
    E_MSG_DI_CMD_FAST_REVERSE           = 0x18,  //parameter
    E_MSG_DI_CMD_NO_MEDIA               = 0x19,  //parameter
    E_MSG_DI_CMD_STOP                   = 0x1A,  //parameter
    E_MSG_DI_CMD_SKIP_FORWARD           = 0x1B,  //parameter
    E_MSG_DI_CMD_SKIP_REVERSE           = 0x1C,  //parameter
    E_MSG_DI_CMD_INDEX_SEARCH_FORWARD   = 0x1D,  //parameter
    E_MSG_DI_CMD_INDEX_SEARCH_REVERSE   = 0x1E,  //parameter
    E_MSG_DI_CMD_OTHER_STATUS           = 0x1F,  //parameter
} MsCEC_MSG_DC_DECK_STATUS_PARM;


//Give deck status, Status request 1 byte
typedef enum _MsCEC_MSG_STATUS_REQUEST_PARM
{
    E_MSG_SR_CMD_ON                     = 1,  //parameter
    E_MSG_SR_CMD_OFF                    = 2,  //parameter
    E_MSG_SR_CMD_ONCE                   = 3,  //parameter
} MsCEC_MSG_STATUS_REQUEST_PARM;


//Play, [Play Mode] 1 byte
typedef enum _MsCEC_MSG_DC_PLAY_PARM
{
    E_MSG_PM_CMD_PLAY_FORWARD               = 0x24,  //parameter
    E_MSG_PM_CMD_PLAY_REVERSE               = 0x20,  //parameter
    E_MSG_PM_CMD_PLAY_STILL                 = 0x25,  //parameter
    E_MSG_PM_CMD_FAST_FORWARD_MINI_SPEED    = 0x05,  //parameter
    E_MSG_PM_CMD_FAST_FORWARD_MEDIUM_SPEED  = 0x06,  //parameter
    E_MSG_PM_CMD_FAST_FORWARD_MAXI_SPEED    = 0x07,  //parameter
    E_MSG_PM_CMD_FAST_REVERSE_MINI_SPEED    = 0x09,  //parameter
    E_MSG_PM_CMD_FAST_REVERSE_MEDIUM_SPEED  = 0x0A,  //parameter
    E_MSG_PM_CMD_FAST_REVERSE_MAXI_SPEED    = 0x0B,  //parameter
    E_MSG_PM_CMD_SLOW_FORWARD_MINI_SPEED    = 0x15,  //parameter
    E_MSG_PM_CMD_SLOW_FORWARD_MEDIUM_SPEED  = 0x16,  //parameter
    E_MSG_PM_CMD_SLOW_FORWARD_MAXI_SPEED    = 0x17,  //parameter
    E_MSG_PM_CMD_SLOW_REVERSE_MINI_SPEED    = 0x19,  //parameter
    E_MSG_PM_CMD_SLOW_REVERSE_MEDIUM_SPEED  = 0x1A,  //parameter
    E_MSG_PM_CMD_SLOW_REVERSE_MAXI_SPEED    = 0x1B,  //parameter
} MsCEC_MSG_DC_PLAY_PARM;


//Power status 1 byte
typedef enum _MsCEC_MSG_POWER_STATUS_PARM
{
    E_MSG_PWRSTA_ON             = 0x00,
    E_MSG_PWRSTA_STANDBY        = 0x01,
    E_MSG_PWRSTA_STANDBY2ON     = 0x02,
    E_MSG_PWRSTA_ON2STANDBY     = 0x03,
    E_MSG_PWRSTA_UNKNOW                 = 0x04,
} MsCEC_MSG_POWER_STATUS_PARM;


typedef enum _MsCEC_MSG_ABORT_REASON
{
    E_MSG_AR_UNRECOGNIZE_OPCDE  = 0x00,  // abort reason
    E_MSG_AR_CANNOTRESPOND      = 0x01,  // abort reason
    E_MSG_AR_CANNOTPROVIDESCR   = 0x02,  // abort reason
    E_MSG_AR_INVALID_OPCODE     = 0x03,  // abort reason
    E_MSG_AR_REFUSED            = 0x04,  // abort reason
    E_MSG_AR_IGNORED            = 0x05,
    E_MSG_AR_SUCCESSED        = 0x06,
} MsCEC_MSG_ABORT_REASON;


typedef enum _MsCEC_MSG_MENU_REQ_TYPE
{
    E_MSG_MENU_REQ_ACTIVATED    = 0,  // menu request activated status
    E_MSG_MENU_REQ_DEACTIVATED  = 1,  // menu request deactivated status
    E_MSG_MENU_REQ_QUERY        = 2,  // menu request query status
} MsCEC_MSG_MENU_REQ_TYPE;


typedef enum _MsCEC_MSG_MENU_STATE
{
    E_MSG_MENU_ACTIVATED    = 0,  // menu activated
    E_MSG_MENU_DEACTIVATED  = 1,  // menu deactivated
} MsCEC_MSG_MENU_STATE;


typedef enum _MsCEC_MSG_RECORD_SOURCE_TYPE
{
    E_MSG_RECORD_TYPE_OWN_SOURCE                = 1,  // own source
    E_MSG_RECORD_TYPE_DIGITAL_SERVICE           = 2,  // digital service
#if(HDMI_CEC_VERSION >= CEC_VERSION_13a)
    E_MSG_RECORD_TYPE_ANALOGUE_SERVICE          = 3,  // Analogue Service
    E_MSG_RECORD_TYPE_EXTERNAL_PLUG             = 4,  // External Plug
    E_MSG_RECORD_TYPE_EXTERNAL_PHYSICAL_ADDRESS = 5,  // External Physical Address
#endif
} MsCEC_MSG_RECORD_SOURCE_TYPE;


typedef enum _MsCEC_MSG_RECORD_STATUS_INFO
{
    E_MSG_RECORD_INFO_RECORDING_OWN_SOURCE   = 0x01,  // Recording currently selected source
    E_MSG_RECORD_INFO_RECORDING_DIGITAL_SERVICE   = 0x02,  // Recording Digital Service
#if(HDMI_CEC_VERSION >= CEC_VERSION_13a)
    E_MSG_RECORD_INFO_RECORDING_ANALOGUE_SERVICE   = 0x03,  // Recording Analogue Service
    E_MSG_RECORD_INFO_RECORDING_EXTERNAL_INPUT   = 0x04,  // Recording External input
#endif
    E_MSG_RECORD_INFO_NO_RECORDING_DIGITAL_SERVICE   = 0x05,  // unable to record Digital Service, no suitable tuner.
#if(HDMI_CEC_VERSION >= CEC_VERSION_13a)
    E_MSG_RECORD_INFO_NO_RECORDING_ANALOGUE_SERVICE   = 0x06,  // unable to record Analogue Service, no suitable tuner.
    E_MSG_RECORD_INFO_NO_RECORDING_REQ_SERVICE   = 0x07,  // unable to select required service, Has suitable tuner, but the requested parameters are invalid or out of range for that tuner.
    E_MSG_RECORD_INFO_NO_RECORDING_INVALID_EXTERNAL_PLUG_NUMBER   = 0x09,  // invalid External plug number
    E_MSG_RECORD_INFO_NO_RECORDING_INVALID_EXTERNAL_PHYSICAL_ADDRESS   = 0x0A,  // invalid External Physical Address
    E_MSG_RECORD_INFO_NO_RECORDING_CA_NOT_SUPPORT   = 0x0B,  // CA system not supported
    E_MSG_RECORD_INFO_NO_RECORDING_CA_NO   = 0x0C,  // No or Insufficient CA Entitlements
    E_MSG_RECORD_INFO_NO_RECORDING_COPY_NEVER   = 0x0D,  // Not allowed to copy source, source is ��copy never��.
    E_MSG_RECORD_INFO_NO_RECORDING_NO_FURTHER_COPY   = 0x0E,  // No further copies allowed
#endif
    E_MSG_RECORD_INFO_NO_RECORDING_NO_MEDIA   = 0x10,  // no media
    E_MSG_RECORD_INFO_NO_RECORDING_PLAYING   = 0x11,  // Playing
    E_MSG_RECORD_INFO_NO_RECORDING_ALREADY_RECORDING   = 0x12,  // already recording
    E_MSG_RECORD_INFO_NO_RECORDING_MEDIA_PROTECTED   = 0x13,  // media protected
    E_MSG_RECORD_INFO_NO_RECORDING_NO_SOURCE  = 0x14,  // no source signal
    E_MSG_RECORD_INFO_NO_RECORDING_MEDIA_PROBLEM  = 0x15,  // media problem
#if(HDMI_CEC_VERSION >= CEC_VERSION_13a)
    E_MSG_RECORD_INFO_NO_RECORDING_NOT_ENOUGH_SPACE  = 0x16,  // not enough space available
    E_MSG_RECORD_INFO_NO_RECORDING_PARENTAL_LOCK  = 0x17,  // Parental Lock On
    E_MSG_RECORD_INFO_RECORDING_TERMINATED_NORMALLY  = 0x1A,  // Recording terminated normally, can optionally be sent in response to a <Record Off> message.
    E_MSG_RECORD_INFO_RECORDING_ALREADY_TERMINATED  = 0x1B,  // Recording has already terminated, can optionally be sent in response to a <Record Off> message.
#endif
    E_MSG_RECORD_INFO_NO_RECORDING_OTHER_REASON  = 0x1F,  // No recording �V other reason
} MsCEC_MSG_RECORD_STATUS_INFO;


//UI command parameter: Table 27 User Control Codes
typedef enum _MsCEC_MSG_USER_CTRL_PARM
{
    E_MSG_UI_SELECT             = 0x00,
    E_MSG_UI_UP                 = 0x01,
    E_MSG_UI_DOWN               = 0x02,
    E_MSG_UI_LEFT               = 0x03,
    E_MSG_UI_RIGHT              = 0x04,
    E_MSG_UI_RIGHT_UP           = 0x05,
    E_MSG_UI_RIGHT_DOWN         = 0x06,
    E_MSG_UI_LEFT_UP            = 0x07,
    E_MSG_UI_LEFT_DOWN          = 0x08,
    E_MSG_UI_ROOTMENU           = 0x09,
    E_MSG_UI_SETUP_MENU         = 0x0A,
    E_MSG_UI_CONTENTS_MENU      = 0x0B,
    E_MSG_UI_FAVORITE_MENU      = 0x0C,
    E_MSG_UI_EXIT               = 0x0D,

// 0x0E ~ 0x1F  reserved

    E_MSG_UI_NUMBER_0           = 0x20,
    E_MSG_UI_NUMBER_1           = 0x21,
    E_MSG_UI_NUMBER_2           = 0x22,
    E_MSG_UI_NUMBER_3           = 0x23,
    E_MSG_UI_NUMBER_4           = 0x24,
    E_MSG_UI_NUMBER_5           = 0x25,
    E_MSG_UI_NUMBER_6           = 0x26,
    E_MSG_UI_NUMBER_7           = 0x27,
    E_MSG_UI_NUMBER_8           = 0x28,
    E_MSG_UI_NUMBER_9           = 0x29,

    E_MSG_UI_DOT                = 0x2A,
    E_MSG_UI_ENTER              = 0x2B,
    E_MSG_UI_CLEAR              = 0x2C,

// 0x2D ~ 0x2E reserved
    E_MSG_UI_NEXT_FAVORITE      = 0x2F,

    E_MSG_UI_CHANNEL_UP         = 0x30,
    E_MSG_UI_CHANNEL_DOWN       = 0x31,
    E_MSG_UI_PREVIOUS_CHANNEL   = 0x32,
    E_MSG_UI_SOUND_SELECT       = 0x33,
    E_MSG_UI_INPUT_SELECT       = 0x34,
    E_MSG_UI_DISPLAY_INFO       = 0x35,
    E_MSG_UI_HELP               = 0x36,
    E_MSG_UI_PAGE_UP            = 0x37,
    E_MSG_UI_PAGE_DOWN          = 0x38,

// 0x39 ~ 0x3F reserved

    E_MSG_UI_POWER              = 0x40,
    E_MSG_UI_VOLUME_UP          = 0x41,
    E_MSG_UI_VOLUME_DOWN        = 0x42,
    E_MSG_UI_MUTE               = 0x43,
    E_MSG_UI_PLAY               = 0x44,
    E_MSG_UI_STOP               = 0x45,
    E_MSG_UI_PAUSE              = 0x46,
    E_MSG_UI_RECORD             = 0x47,
    E_MSG_UI_REWIND             = 0x48,
    E_MSG_UI_FAST_FORWARD       = 0x49,
    E_MSG_UI_EJECT              = 0x4A,
    E_MSG_UI_FORWARD            = 0x4B,
    E_MSG_UI_BACKWARD           = 0x4C,
    E_MSG_UI_STOP_RECORD        = 0x4D,
    E_MSG_UI_PAUSE_RECORD       = 0x4E,

// 0x4F reserved

    E_MSG_UI_ANGLE                      = 0x50,
    E_MSG_UI_SUB_PICTURE                = 0x51,
    E_MSG_UI_VIDEO_ON_DEMAND            = 0x52,
    E_MSG_UI_ELECTRONIC_PROGRAM_GUIDE   = 0x53,
    E_MSG_UI_TIMER_PROGRAMMING          = 0x54,
    E_MSG_UI_INITIAL_CONFIGURATION      = 0x55,

// 0x56 ~ 0x5F reserved

  //0x60 ~ 0x6D, identified as function
    E_MSG_UI_PLAY_FUN               = 0x60,
    E_MSG_UI_PSUSE_PLAY_FUN         = 0x61,
    E_MSG_UI_RECORD_FUN             = 0x62,
    E_MSG_UI_PAUSE_RECORD_FUN       = 0x63,
    E_MSG_UI_STOP_FUN               = 0x64,
    E_MSG_UI_MUTE_FUN               = 0x65,
    E_MSG_UI_RESTORE_VOLUME_FUN     = 0x66,
    E_MSG_UI_TUNE_FUN               = 0x67,
    E_MSG_UI_SELECT_MEDIA_FUN       = 0x68,
    E_MSG_UI_SELECT_AV_INPUT_FUN    = 0x69,
    E_MSG_UI_SELECT_AUDIO_INPUT_FUN = 0x6A,
    E_MSG_UI_POWER_TOGGLE_FUN       = 0x6B,
    E_MSG_UI_POWER_OFF_FUN          = 0x6C,
    E_MSG_UI_POWER_ON_FUN           = 0x6D,

// 0x6E ~ 0x70 reserved

    E_MSG_UI_F1_BLUE            = 0x71,
    E_MSG_UI_F2_RED             = 0x72,
    E_MSG_UI_F3_GREEN           = 0x73,
    E_MSG_UI_F4_YELLOW          = 0x74,
    E_MSG_UI_F5                 = 0x75,
    E_MSG_UI_DATA               = 0x76,

// 0x77 ~ 0xFF reserved
} MsCEC_MSG_USER_CTRL_PARM;

//query the power on mode through mailbox
#define CP_READ_POWERON_MODE  0x9A

//mailbox report CEC wake up system
#define M_POWER_ON_BY_HDMI_CEC  0x2F


typedef struct _MDrv_Cec_RxData_Info
{
    MS_U8 ucLength;
    MS_U8 tRxData[CEC_FIFO_DATA_NUMBER];
} MS_CEC_RxData_Info;

typedef struct DLL_PACKED
{
    MS_U8 CecFifoIdxS;
    MS_U8 CecFifoIdxE;
    MS_U8 bCecMsgCnt;
    MS_BOOL fCecInitFinish;
    MS_CEC_RxData_Info CecRxBuf[CEC_FIFO_NUM_COUNT];   //TV CEC H/W part
    MsCEC_DEVICELA MyLogicalAddress;                         //TV related
    MS_U8 MyPhysicalAddress[CEC_PHY_ADDR_COUNT];
    MsCEC_DEVICE_TYPE MyDeviceType;
    MsCEC_MSG_POWER_STATUS_PARM MyPowerStatus;
    MS_BOOL CecDevicesExisted[15];

    MS_U8 ActiveDeviceCECVersion;
    MsCEC_DEVICE_TYPE ActiveDeviceType;
    MsCEC_DEVICELA ActiveLogicalAddress;    //the remoter controller's active device
    MS_U8 ActivePhysicalAddress[CEC_PHY_ADDR_COUNT];
    MsCEC_MSG_POWER_STATUS_PARM ActivePowerStatus;

#if ENABLE_CEC_MULTIPLE
    MsCEC_DEVICELA MyLogicalAddress2;
    MS_U8 MyPhysicalAddress2[CEC_PHY_ADDR_COUNT];
    MsCEC_DEVICE_TYPE MyDeviceType2;
    MsCEC_DEVICE_TYPE IniLogicalAddress;
#endif
} MS_CEC_INFO_LIST;

typedef enum
{
    E_CEC_CMD_ATTACH_DRIVER_ISR
}E_CEC_CTRL_ID;

//-------------------------------------------------------------------------------------------------
/// Attach driver ISR or not
/// @ingroup apiCEC_ToBeAdd
/// @param  bAttachDrvFlag       \b IN: true: attach driver ISR; false: no attach driver ISR
/// @return None
//-------------------------------------------------------------------------------------------------
typedef struct
{
    MS_BOOL bAttachDrvFlag;
}stCMD_CEC_ATTACH_DRIVER_ISR;

typedef enum
{
    //CEC property
    MAPI_CMD_DDC2BI_GET_INFO,
    MAPI_CMD_CEC_INIT_CHIP,
    MAPI_CMD_CEC_PORT_SELECT,
    MAPI_CMD_CEC_EXIT,
    MAPI_CMD_CEC_SET_MY_LOGICAL_ADDRESS,
    MAPI_CMD_CEC_INIT,
    MAPI_CMD_CEC_CHECK_EXIST_DEVICES,
    MAPI_CMD_CEC_NEXT_DEVICE,
    MAPI_CMD_CEC_CHK_RX_BUF,
    MAPI_CMD_CEC_TX_SEND_MSG,
    MAPI_CMD_CEC_TX_SEND_MSG2,
    MAPI_CMD_CEC_TX_SEND_POLLING_MSG,
    MAPI_CMD_CEC_MSG_ACTIVE_SOURCE,
    MAPI_CMD_CEC_MSG_ROUTING_CHANGE,
    MAPI_CMD_CEC_MSG_REQ_ACTIVE_SOURCE,
    MAPI_CMD_CEC_MSG_SET_STREAM_PATH,
    MAPI_CMD_CEC_MSG_STANDBY,
    MAPI_CMD_CEC_MSG_RECORD_OFF,
    MAPI_CMD_CEC_MSG_RECORD_ON,
    MAPI_CMD_CEC_MSG_REPORT_CEC_VERSION,
    MAPI_CMD_CEC_MSG_REQ_CEC_VERSION,
    MAPI_CMD_CEC_MSG_REPORT_PHYCAL_ADDRESS,
    MAPI_CMD_CEC_MSG_REQ_PHYCAL_ADDRESS,
    MAPI_CMD_CEC_MSG_DECK_CONTROL,
    MAPI_CMD_CEC_MSG_DEC_STATUS,
    MAPI_CMD_CEC_MSG_GIVE_DECK_STATUS,
    MAPI_CMD_CEC_MSG_DC_PLAY,
    MAPI_CMD_CEC_MSG_REQ_MENU_STATUS,
    MAPI_CMD_CEC_MSG_USER_CTRL_PRESSED,
    MAPI_CMD_CEC_MSG_USER_CTRL_RELEASED,
    MAPI_CMD_CEC_MSG_GIVE_AUDIO_STATUS,
    MAPI_CMD_CEC_MSG_REPORT_POWER_STATUS,
    MAPI_CMD_CEC_MSG_REQ_POWER_STATUS,
    MAPI_CMD_CEC_MSG_FEATURE_ABORT,
    MAPI_CMD_CEC_MSG_ABORT,
    MAPI_CMD_CEC_MSG_SEND_MENU_LANGUAGE,
    MAPI_CMD_CEC_MSG_REQ_ARC_INITIATION,
    MAPI_CMD_CEC_MSG_REQ_ARC_TERMINATION,
    MAPI_CMD_CEC_MSG_AUDIO_MODE_REQ,
    MAPI_CMD_CEC_MSG_REPORT_PHYCAL_ADDRESS2,
    MAPI_CMD_CEC_CHECK_FRAME,
    MAPI_CMD_CEC_CONFIG_WAKEUP,
    MAPI_CMD_CEC_ENABLED,
    MAPI_CMD_CEC_GET_TX_STATUS,
    MAPI_CMD_CEC_SET_POWER_STATE,
    MAPI_CMD_CEC_SET_MY_LOGICAL_ADDRESS2,
    MAPI_CMD_CEC_GET_HEADER,  // API TO DRV
    MAPI_CMD_CEC_GET_OPCODE,
    MAPI_CMD_CEC_GET_PARA,
    MAPI_CMD_CEC_GET_CMD_LEN,
    MAPI_CMD_CEC_IS_RX_BUF_EMPTY,
    MAPI_CMD_CEC_SET_ACTIVE_LOGICAL_ADDRESS,
    MAPI_CMD_CEC_GET_ACTIVE_LOGICAL_ADDRESS,
    MAPI_CMD_CEC_GET_POWER_STATUS,
    MAPI_CMD_CEC_GET_FIFO_IDX,
    MAPI_CMD_CEC_SET_FIFO_IDX,
    MAPI_CMD_CEC_SET_ACTIVE_POWER_STATUS,
    MAPI_CMD_CEC_GET_ACTIVE_POWER_STATUS,
    MAPI_CMD_CEC_SET_ACTIVE_PHYSICAL_ADDRESS,
    MAPI_CMD_CEC_SET_ACTIVE_DEVICE_CEC_VERSION,
    MAPI_CMD_CEC_SET_ACTIVE_DEVICE_TYPE,
    MAPI_CMD_CEC_GET_MSG_CNT,
    MAPI_CMD_CEC_SET_MSG_CNT,
    MAPI_CMD_CEC_GET_RX_DATA,
    MAPI_CMD_CEC_SET_MY_PHYSICAL_ADDRESS,
    MAPI_CMD_CEC_SET_MY_PHYSICAL_ADDRESS2,
    MAPI_CMD_CEC_SET_INITIATOR,
    MAPI_CMD_CEC_CHECK_DEVICE_IS_TX,
    MAPI_CMD_CEC_CONFIG_WAKEUP_INFO_VENDOR_ID,
    MAPI_CMD_CEC_SET_RETRY_COUNT,
    MAPI_CMD_CEC_ATTACH_DRIVER_ISR,
}E_CEC_API_CMD_TYPE;

typedef struct
{
    MS_U32 u32XTAL_CLK_Hz;
}MS_CEC_INIT_INFO;

typedef struct DLL_PACKED
{
    MS_CEC_INFO_LIST *eInfo;
    MS_BOOL bGetInfo;
} stCEC_DDC2BI_GET_INFO, *pstCEC_DDC2BI_GET_INFO;

typedef struct
{
    MS_U32 u32XTAL_CLK_Hz;
} stCEC_INIT_CHIP, *pstCEC_INIT_CHIP;

typedef struct
{
    MsCEC_INPUT_PORT InputPort;
} stCEC_PORT_SELECT, *pstCEC_PORT_SELECT;

typedef struct
{
    MsCEC_DEVICELA myLA;
} stCEC_SET_MY_LOGICAL_ADDRESS, *pstCEC_SET_MY_LOGICAL_ADDRESS;

typedef struct
{
    MS_U32 u32XTAL_CLK_Hz;
} stCEC_INIT, *pstCEC_INIT;

typedef struct
{
    MsCEC_DEVICELA eNextDeviceLA;
} stCEC_NEXT_DEVICE, *pstCEC_NEXT_DEVICE;

typedef struct DLL_PACKED
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSGLIST eMsg;
    MS_U8 *ucCmd;
    MS_U8 ucLen;
    CEC_ERROR_CODE eErrorCode;
} stCEC_TX_SEND_MSG, *pstCEC_TX_SEND_MSG;

typedef struct DLL_PACKED
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSGLIST eMsg;
    MS_U8 *ucCmd;
    MS_U8 ucLen;
    CEC_ERROR_CODE eErrorCode;
} stCEC_TX_SEND_MSG2, *pstCEC_TX_SEND_MSG2;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_TX_SEND_POLLING_MSG, *pstCEC_TX_SEND_POLLING_MSG;

typedef struct
{
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_ACTIVE_SOURCE, *pstCEC_MSG_ACTIVE_SOURCE;

typedef struct DLL_PACKED
{
    MS_U8 *ucOrigAddr;
    MS_U8 *ucNewAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_ROUTING_CHANGE, *pstCEC_MSG_ROUTING_CHANGE;

typedef struct
{
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REQ_ACTIVE_SOURCE, *pstCEC_MSG_REQ_ACTIVE_SOURCE;

typedef struct DLL_PACKED
{
    MS_U8 *ucNewAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_SET_STREAM_PATH, *pstCEC_MSG_SET_STREAM_PATH;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_STANDBY, *pstCEC_MSG_STANDBY;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_RECORD_OFF, *pstCEC_MSG_RECORD_OFF;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSG_RECORD_SOURCE_TYPE eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_RECORD_ON, *pstCEC_MSG_RECORD_ON;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MS_U8 ucVersion;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REPORT_CEC_VERSION, *pstCEC_MSG_REPORT_CEC_VERSION;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REQ_CEC_VERSION, *pstCEC_MSG_REQ_CEC_VERSION;

typedef struct
{
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REPORT_PHYCAL_ADDRESS, *pstCEC_MSG_REPORT_PHYCAL_ADDRESS;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REQ_PHYCAL_ADDRESS, *pstCEC_MSG_REQ_PHYCAL_ADDRESS;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSG_DC_DECK_CTRL_PARM eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_DECK_CONTROL, *pstCEC_MSG_DECK_CONTROL;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSG_DC_DECK_STATUS_PARM eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_DEC_STATUS, *pstCEC_MSG_DEC_STATUS;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSG_STATUS_REQUEST_PARM eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_GIVE_DECK_STATUS, *pstCEC_MSG_GIVE_DECK_STATUS;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSG_DC_PLAY_PARM eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_DC_PLAY, *pstCEC_MSG_DC_PLAY;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSG_MENU_REQ_TYPE eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REQ_MENU_STATUS, *pstCEC_MSG_REQ_MENU_STATUS;

typedef struct
{
    MS_BOOL bUserCtrlEn;
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSG_USER_CTRL_PARM eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_USER_CTRL_PRESSED, *pstCEC_MSG_USER_CTRL_PRESSED;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_USER_CTRL_RELEASED, *pstCEC_MSG_USER_CTRL_RELEASED;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_GIVE_AUDIO_STATUS, *pstCEC_MSG_GIVE_AUDIO_STATUS;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REPORT_POWER_STATUS, *pstCEC_MSG_REPORT_POWER_STATUS;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REQ_POWER_STATUS, *pstCEC_MSG_REQ_POWER_STATUS;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSGLIST eMsg;
    MsCEC_MSG_ABORT_REASON eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_FEATURE_ABORT, *pstCEC_MSG_FEATURE_ABORT;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    MsCEC_MSGLIST eMsg;
    MsCEC_MSG_ABORT_REASON eCmd;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_ABORT, *pstCEC_MSG_ABORT;

typedef struct DLL_PACKED
{
    MS_U8 *pu8MenulanguageCode;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_SEND_MENU_LANGUAGE, *pstCEC_MSG_SEND_MENU_LANGUAGE;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REQ_ARC_INITIATION, *pstCEC_MSG_REQ_ARC_INITIATION;

typedef struct
{
    MsCEC_DEVICELA eDetAddr;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REQ_ARC_TERMINATION, *pstCEC_MSG_REQ_ARC_TERMINATION;

typedef struct DLL_PACKED
{
    MsCEC_DEVICELA eDetAddr;
    MS_BOOL bAmpSwitch;
    MS_U8 *ucMyAddress;
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_AUDIO_MODE_REQ, *pstCEC_MSG_AUDIO_MODE_REQ;

typedef struct
{
    CEC_ERROR_CODE eErrorCode;
} stCEC_MSG_REPORT_PHYCAL_ADDRESS2, *pstCEC_MSG_REPORT_PHYCAL_ADDRESS2;

typedef struct
{
    MsCEC_MSG_TRANS_TYPE eMsgType;
    MS_U8 ucLen;
    MS_BOOL bValid;
} stCEC_CHECK_FRAME, *pstCEC_CHECK_FRAME;

typedef struct
{
    MS_BOOL bEnableFlag;
} stCEC_ENABLED, *pstCEC_ENABLED;

typedef struct
{
    MS_U8 ucTxStatus;
} stCEC_GET_TX_STATUS, *pstCEC_GET_TX_STATUS;

typedef struct
{
    MS_BOOL bIsTx;
} stCEC_DEVICE_IS_TX, *pstCEC_DEVICE_IS_TX;

typedef struct
{
    EN_POWER_MODE ePowerState;
    MS_U32 u32Status;
} stCEC_SET_POWER_STATE, *pstCEC_SET_POWER_STATE;

typedef struct
{
    MsCEC_DEVICELA myLA;
} stCEC_SET_MY_LOGICAL_ADDRESS2, *pstCEC_SET_MY_LOGICAL_ADDRESS2;

// API TO DRV
typedef struct
{
    MS_U8 ucValue;
} stCEC_GET_HEADER, *pstCEC_GET_HEADER;

typedef struct
{
    MS_U8 ucValue;
} stCEC_GET_OPCODE, *pstCEC_GET_OPCODE;

typedef struct
{
    MS_U8 ucIdx;
    MS_U8 ucValue;
} stCEC_GET_PARA, *pstCEC_GET_PARA;

typedef struct
{
    MS_U8 ucValue;
} stCEC_GET_CMD_LEN, *pstCEC_GET_CMD_LEN;

typedef struct
{
    MS_BOOL bEmpty;
} stCEC_IS_RX_BUF_EMPTY, *pstCEC_IS_RX_BUF_EMPTY;

typedef struct
{
    MsCEC_DEVICELA eAddr;
} stCEC_SET_ACTIVE_LOGICAL_ADDRESS, *pstCEC_SET_ACTIVE_LOGICAL_ADDRESS;

typedef struct
{
    MsCEC_DEVICELA eAddr;
} stCEC_GET_ACTIVE_LOGICAL_ADDRESS, *pstCEC_GET_ACTIVE_LOGICAL_ADDRESS;

typedef struct
{
    MsCEC_MSG_POWER_STATUS_PARM ePowerStatus;
} stCEC_GET_POWER_STATUS, *pstCEC_GET_POWER_STATUS;

typedef struct
{
    MS_U8 ucFifoIdx;
} stCEC_GET_FIFO_IDX, *pstCEC_GET_FIFO_IDX;

typedef struct
{
    MS_U8 ucIdx;
} stCEC_SET_FIFO_IDX, *pstCEC_SET_FIFO_IDX;

typedef struct
{
    MsCEC_MSG_POWER_STATUS_PARM eStatus;
} stCEC_SET_ACTIVE_POWER_STATUS, *pstCEC_SET_ACTIVE_POWER_STATUS;

typedef struct
{
    MsCEC_MSG_POWER_STATUS_PARM ePowerStatus;
} stCEC_GET_ACTIVE_POWER_STATUS, *pstCEC_GET_ACTIVE_POWER_STATUS;

typedef struct
{
    MS_U8 ucPara1;
    MS_U8 ucPara2;
} stCEC_SET_ACTIVE_PHYSICAL_ADDRESS, *pstCEC_SET_ACTIVE_PHYSICAL_ADDRESS;

typedef struct
{
    MS_U8 ucVer;
} stCEC_SET_ACTIVE_DEVICE_CEC_VERSION, *pstCEC_SET_ACTIVE_DEVICE_CEC_VERSION;

typedef struct
{
    MsCEC_DEVICE_TYPE eType;
} stCEC_SET_ACTIVE_DEVICE_TYPE, *pstCEC_SET_ACTIVE_DEVICE_TYPE;

typedef struct
{
    MS_U8 ucMsgCnt;
} stCEC_GET_MSG_CNT, *pstCEC_GET_MSG_CNT;

typedef struct
{
    MS_U8 ucCnt;
} stCEC_SET_MSG_CNT, *pstCEC_SET_MSG_CNT;

typedef struct
{
    MS_U8 ucFifoIdx;
    MS_U8 ucIdx;
    MS_U8 ucRxData;
} stCEC_GET_RX_DATA, *pstCEC_GET_RX_DATA;

typedef struct DLL_PACKED
{
    MS_U8 *ucData;
} stCEC_SET_MY_PHYSICAL_ADDRESS, *pstCEC_SET_MY_PHYSICAL_ADDRESS;

typedef struct DLL_PACKED
{
    MS_U8 *ucData;
} stCEC_SET_MY_PHYSICAL_ADDRESS2, *pstCEC_SET_MY_PHYSICAL_ADDRESS2;

typedef struct
{
    MsCEC_DEVICELA eIniLa;
} stCEC_SET_INITIATOR, *pstCEC_SET_INITIATOR;

typedef struct DLL_PACKED
{
    MS_U8 *ucVendorID;
} stCEC_CONFIG_WAKEUP_INFO_VENDOR_ID, *pstCEC_CONFIG_WAKEUP_INFO_VENDOR_ID;

typedef struct
{
    MS_U8 ucRetryCount;
} stCEC_SET_RETRY_COUNT, *pstCEC_SET_RETRY_COUNT;

typedef struct
{
    MS_BOOL bAttachDrvFlag;
}stCEC_ATTACH_DRIVER_ISR, *pstCEC_ATTACH_DRIVER_ISR;

//------------------------------------------------------------------------------------------------

typedef struct
{
    MS_BOOL bIsInitialized;
    MS_BOOL bIsRunning;
}MS_CEC_Status;

//-------------------------------------------------------------------------------------------------
//  Function and Variable
//-------------------------------------------------------------------------------------------------
/**
*   @brief HDMI Status
*/

//-------------------------------------------------------------------------------------------------
/// Assign which HDMI port connect to CEC
/// @ingroup apiCEC_BASIC
/// @param  InputPort          \b IN: CEC connect port
/// @return None
//-------------------------------------------------------------------------------------------------
void SYMBOL_WEAK MApi_CEC_PortSelcet(MsCEC_INPUT_PORT InputPort); // Select CEC bank mapping

//-------------------------------------------------------------------------------------------------
/// Get version (without Mutex protect)
/// @ingroup apiCEC_BASIC
/// @param  ppVersion          \b IN: version
/// @return TRUE: have version
/// @return FALSE: no version
//-------------------------------------------------------------------------------------------------
// MS_BOOL MApi_CEC_GetLibVer(const MSIF_Version **ppVersion);      ///< Get version (without Mutex protect)

//-------------------------------------------------------------------------------------------------
/// Get cec info
/// @ingroup apiCEC_BASIC
/// @param  pInfo          \b IN: info list
/// @return TRUE: have info list
/// @return FALSE: no info list
//-------------------------------------------------------------------------------------------------
// MS_BOOL MApi_DDC2BI_GetInfo(MS_CEC_INFO_LIST *pInfo);

//-------------------------------------------------------------------------------------------------
/// Get cec status
/// @ingroup apiCEC_BASIC
/// @param  pStatus          \b IN: status
/// @return TRUE: have status
/// @return FALSE: no status
//-------------------------------------------------------------------------------------------------
// MS_BOOL MApi_DDC2BI_GetStatus(MS_CEC_Status *pStatus);

//-------------------------------------------------------------------------------------------------
/// Set debug level
/// @ingroup apiCEC_BASIC
/// @param  u16DbgSwitch          \b IN: switch or not
/// @return TRUE: do switch
/// @return FALSE: no switch
//-------------------------------------------------------------------------------------------------
MS_BOOL MApi_DDC2BI_SetDbgLevel(MS_U16 u16DbgSwitch);

//-------------------------------------------------------------------------------------------------
/// CEC do not work
/// @ingroup apiCEC_BASIC
/// @return None
//------------------------------------------------------------------------------------------------
void MApi_CEC_Exit(void); // Mask CEC interrupt and release CEC

//-------------------------------------------------------------------------------------------------
/// CEC initial sequence
/// @ingroup apiCEC_BASIC
/// @param  pCECInfo          \b IN: CEC info
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_Init(MS_CEC_INIT_INFO *pCECInfo); // CEC initial sequence

//-------------------------------------------------------------------------------------------------
/// CEC initial chip relatived part
/// @ingroup apiCEC_BASIC
/// @param  pCECInfo          \b IN: CEC info
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_InitChip(MS_CEC_INIT_INFO *pCECInfo); // CEC initial chip relatived part

//-------------------------------------------------------------------------------------------------
/// CEC set own logical address
/// @ingroup apiCEC_STATUS
/// @param  myLA          \b IN: logical address
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetMyLogicalAddress(MsCEC_DEVICELA myLA); // CEC set own logical address

//-------------------------------------------------------------------------------------------------
/// Use to store CEC received messages
/// @ingroup apiCEC_STATUS
/// @return None
//------------------------------------------------------------------------------------------------
void MApi_CEC_ChkRxBuf(void); // Use to store CEC received messages

//-------------------------------------------------------------------------------------------------
/// Use to send any CEC message by user defined
/// @ingroup apiCEC_STATUS
/// @param  header          \b IN: destination logical address
/// @param  opcode          \b IN: opcode
/// @param  operand_ptr          \b IN: operand
/// @param  len          \b IN: length
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
CEC_ERROR_CODE MApi_CEC_TxSendMsg(MsCEC_DEVICELA header,MsCEC_MSGLIST opcode,MS_U8* operand_ptr,MS_U8 len);

//-------------------------------------------------------------------------------------------------
/// Use to send any CEC message by user defined
/// @ingroup apiCEC_ToBeRemove
/// @param  dst_address          \b IN: destination logical address
/// @param  opcode          \b IN: opcode
/// @param  operand_ptr          \b IN: operand
/// @param  len          \b IN: length
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
CEC_ERROR_CODE MApi_CEC_TxSendMsg2(MsCEC_DEVICELA dst_address, MsCEC_MSGLIST msg, MS_U8* operand_ptr, MS_U8 len);

//-------------------------------------------------------------------------------------------------
/// Use to send CEC polling msg
/// @ingroup apiCEC_BASIC
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
CEC_ERROR_CODE MsAPI_CecTxSendPollingMsg(MsCEC_DEVICELA dst_address); // Use to send CEC polling msg

//*****************************//
//    One Touch Play &
//    Routing Control Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
/// Used by a new source to indicate that it has started to transmit a stream or used in response to a <Request Active Source>
/// @ingroup apiCEC_Message
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ActiveSource(void);


//*****************************//
//    Routing Control Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
/// Used by a CEC switch when it's manually switched to inform akk other devices
/// @ingroup apiCEC_Message
/// @param  orig_address       \b IN: the original physicall address
/// @param  new_address       \b IN: the new physical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_RoutingChange(MS_U8* orig_address, MS_U8* new_address);

//-------------------------------------------------------------------------------------------------
/// Used by a new device to discover the status of the system.
/// @ingroup apiCEC_Message
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReqActiveSource(void);

//-------------------------------------------------------------------------------------------------
/// Used by the TV to request a streaming path from the specified physical address.
/// @ingroup apiCEC_Message
/// @param  new_address       \b IN: the new physical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_SetStreamPath(MS_U8* new_address);


//*****************************//
//    Standby Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
/// Use to switch one or all devices into standby mode.
/// One device: it's specific logical address, like "E_LA_RECORDER1"
/// All device:   Use broadcast logical address, "E_LA_BROADCAST"
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_Standby(MsCEC_DEVICELA dst_address);


//*****************************//
//    On Touch Record
//*****************************//

//-------------------------------------------------------------------------------------------------
/// Requests a device to stop a recording.
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_RecordOff(MsCEC_DEVICELA dst_address);

//-------------------------------------------------------------------------------------------------
/// Attempt to record the specified source.
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  cmd       \b IN: record source command
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MsAPI_CEC_Msg_RecordOn(MsCEC_DEVICELA dst_address, MsCEC_MSG_RECORD_SOURCE_TYPE cmd);


//*****************************//
//    System Information Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
/// Used to indicate the supported CEC version, in response to a <Get CEC Version>
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  version       \b IN: cec version
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReportCECVersion(MsCEC_DEVICELA dst_address, MS_U8 version);

//-------------------------------------------------------------------------------------------------
/// Used by a device to enquire which version of CEC the target supports
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReqCECVersion(MsCEC_DEVICELA dst_address);

//-------------------------------------------------------------------------------------------------
///  Use to inform all other devices of the mapping between physical and logical address of the initiator
/// @ingroup apiCEC_Message
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReportPhycalAddress(void);

//-------------------------------------------------------------------------------------------------
/// A request to a device to return its physical address
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReqPhycalAddress(MsCEC_DEVICELA dst_address);


//*****************************//
//    Deck Control Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
///  Use to control a device's media functions
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  cmd       \b IN: deck control mode command
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_DeckControl(MsCEC_DEVICELA dst_address, MsCEC_MSG_DC_DECK_CTRL_PARM cmd);

//-------------------------------------------------------------------------------------------------
///  Use to provide a device's status when received "Give Deck Status"
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  cmd       \b IN: deck info command
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_DecStatus(MsCEC_DEVICELA dst_address, MsCEC_MSG_DC_DECK_STATUS_PARM cmd);

//-------------------------------------------------------------------------------------------------
///  Use to request device's status
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  cmd       \b IN: status request command
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_MSg_GiveDeckStatus(MsCEC_DEVICELA dst_address, MsCEC_MSG_STATUS_REQUEST_PARM cmd);

//-------------------------------------------------------------------------------------------------
///  Use to control the playback behaviour of a source device
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  cmd       \b IN: play mode command
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_MSg_DCPlay(MsCEC_DEVICELA dst_address, MsCEC_MSG_DC_PLAY_PARM cmd);


//*****************************//
//    Device Menu Control &
//    Remote Control Passthrough Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
///  Request from TV for a device to show/remove a menu or to query status
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  cmd       \b IN: menu request type command
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReqMenuStatus(MsCEC_DEVICELA dst_address, MsCEC_MSG_MENU_REQ_TYPE cmd);

//-------------------------------------------------------------------------------------------------
/// Use to indicated that user pressed which control button
/// @ingroup apiCEC_Message
/// @param  bUserCtrlEn       \b IN: menu status is activated or not
/// @param  dst_address       \b IN: destination logical address
/// @param  cmd       \b IN: UI command
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_UserCtrlPressed(MS_BOOL bUserCtrlEn, MsCEC_DEVICELA dst_address, MsCEC_MSG_USER_CTRL_PARM cmd);

//-------------------------------------------------------------------------------------------------
/// Use to indicated that user released which control button
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_UserCtrlReleased(MsCEC_DEVICELA dst_address);


//*****************************//
//    Power Status Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
/// Use to inform a requesting device of the current power status
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReportPowerStatus(MsCEC_DEVICELA dst_address);

//-------------------------------------------------------------------------------------------------
/// Use to determine the current power status of a target device
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_ReqPowerStatus(MsCEC_DEVICELA dst_address);

//*****************************//
//    General Protocol Feature
//*****************************//

//-------------------------------------------------------------------------------------------------
/// Use to indicate that device doesn't support message type
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  msg       \b IN: feature opcode
/// @param  cmd       \b IN: abort reason
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_FeatureAbort(MsCEC_DEVICELA dst_address, MsCEC_MSGLIST msg, MsCEC_MSG_ABORT_REASON cmd);

//-------------------------------------------------------------------------------------------------
/// This message is reserved for testing purposes.
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_Abort(MsCEC_DEVICELA dst_address);

//-------------------------------------------------------------------------------------------------
/// Used by a TV to indicate its currently selected menu language
/// @ingroup apiCEC_Message
/// @param  pu8MenuLanguageCode       \b IN: menu language code
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_SendMenuLanguage(MS_U8* pu8MenuLanguageCode);

//-------------------------------------------------------------------------------------------------
/// Used by an ARC TX device to request an ARC RX device to activate the ARC functionility in ARC TX device
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MsAPI_CecMsg_ReqARCInitiation(MsCEC_DEVICELA dst_address);

//-------------------------------------------------------------------------------------------------
/// Used by an ARC TX device to request an ARC RX device to deactivate the ARC functionility in ARC TX device
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MsAPI_CecMsg_ReqARCTermination(MsCEC_DEVICELA dst_address);

//-------------------------------------------------------------------------------------------------
/// A device implementing System Audio Control and which has volume control  RC buttons request to use System Audio Mode to the Amplifier
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @param  amp_switch       \b IN: 1: unmute amplifier. 0: mute amplifier
/// @param  my_address       \b IN: source to be used is the device specified at this address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MsAPI_CecMsg_AudioModeReq(MsCEC_DEVICELA dst_address, MS_BOOL amp_switch, MS_U8* my_address );

//-------------------------------------------------------------------------------------------------
/// Use to request an Amplifier to send its volume and mute status
/// @ingroup apiCEC_Message
/// @param  dst_address       \b IN: destination logical address
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
// CEC_ERROR_CODE MApi_CEC_Msg_GiveAudioStatus(MsCEC_DEVICELA dst_address);

//-------------------------------------------------------------------------------------------------
/// Get RX header
/// @ingroup apiCEC_STATUS
/// @return header
//-------------------------------------------------------------------------------------------------
MS_U8 MApi_CEC_Get_Header(void);

//-------------------------------------------------------------------------------------------------
/// Get RX opcode
/// @ingroup apiCEC_STATUS
/// @return opcode
//-------------------------------------------------------------------------------------------------
MS_U8 MApi_CEC_Get_OpCode(void);

//-------------------------------------------------------------------------------------------------
/// Get RX parameter
/// @ingroup apiCEC_STATUS
/// @param  u8Idx       \b IN: parameter index
/// @return parameter
//-------------------------------------------------------------------------------------------------
MS_U8 MApi_CEC_Get_Para(MS_U8 u8Idx);

//-------------------------------------------------------------------------------------------------
/// Get RX command length
/// @ingroup apiCEC_STATUS
/// @return comand length
//-------------------------------------------------------------------------------------------------
MS_U8 MApi_CEC_GetCmdLen(void);

//-------------------------------------------------------------------------------------------------
/// Set active logical address
/// @ingroup apiCEC_STATUS
/// @param  Addr       \b IN: logical address
/// @return None
//-------------------------------------------------------------------------------------------------
// void MApi_CEC_SetActiveLogicalAddress(MsCEC_DEVICELA Addr);

//-------------------------------------------------------------------------------------------------
/// Get active logical address
/// @ingroup apiCEC_STATUS
/// @return logical address
//-------------------------------------------------------------------------------------------------
// MsCEC_DEVICELA MApi_CEC_GetActiveLogicalAddress(void);

//-------------------------------------------------------------------------------------------------
/// Get power status
/// @ingroup apiCEC_STATUS
/// @return power status
//-------------------------------------------------------------------------------------------------
// MsCEC_MSG_POWER_STATUS_PARM MApi_CEC_GetPowerStatus(void);

//-------------------------------------------------------------------------------------------------
/// Get fifo index
/// @ingroup apiCEC_BASIC
/// @return fifo index
//-------------------------------------------------------------------------------------------------
MS_U8 MApi_CEC_GetFifoIdx(void);

//-------------------------------------------------------------------------------------------------
/// Set fifo index
/// @ingroup apiCEC_BASIC
/// @param  u8Idx       \b IN: fifo index
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetFifoIdx(MS_U8 u8Idx);

//-------------------------------------------------------------------------------------------------
/// Set active power status
/// @ingroup apiCEC_STATUS
/// @param  Status       \b IN: active power status
/// @return None
//-------------------------------------------------------------------------------------------------
// void MApi_CEC_SetActivePowerStatus(MsCEC_MSG_POWER_STATUS_PARM Status);

//-------------------------------------------------------------------------------------------------
/// Get active power status
/// @ingroup apiCEC_STATUS
/// @return power status
//-------------------------------------------------------------------------------------------------
// MsCEC_MSG_POWER_STATUS_PARM MApi_CEC_GetActivePowerStatus(void);

//-------------------------------------------------------------------------------------------------
/// Set active physical address
/// @ingroup apiCEC_STATUS
/// @param  u8Para1       \b IN: physical address lower byte
/// @param  u8Para2       \b IN: physical address higer byte
/// @return None
//-------------------------------------------------------------------------------------------------
// void MApi_CEC_SetActivePhysicalAddress(MS_U8 u8Para1, MS_U8 u8Para2);

//-------------------------------------------------------------------------------------------------
/// Set active device CEC version
/// @ingroup apiCEC_STATUS
/// @param  u8Ver       \b IN: active cec version
/// @return None
//-------------------------------------------------------------------------------------------------
// void MApi_CEC_SetActiveDeviceCECVersion(MS_U8 u8Ver);

//-------------------------------------------------------------------------------------------------
/// Set active device type
/// @ingroup apiCEC_STATUS
/// @param  Type       \b IN: active device type
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetActiveDeviceType(MsCEC_DEVICE_TYPE Type);

//-------------------------------------------------------------------------------------------------
/// Get message count
/// @ingroup apiCEC_STATUS
/// @return message count
//-------------------------------------------------------------------------------------------------
MS_U8 MApi_CEC_GetMsgCnt(void);

//-------------------------------------------------------------------------------------------------
/// Set message count
/// @ingroup apiCEC_STATUS
/// @param  u8Cnt       \b IN: message count
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetMsgCnt(MS_U8 u8Cnt);

//-------------------------------------------------------------------------------------------------
/// Get Rx data
/// @ingroup apiCEC_STATUS
/// @param  u8Fifoidx       \b IN: fifo index
/// @param  u8Idx       \b IN: data index
/// @return data
//-------------------------------------------------------------------------------------------------
MS_U8 MApi_CEC_GetRxData(MS_U8 u8Fifoidx, MS_U8 u8Idx);

//-------------------------------------------------------------------------------------------------
/// Use to check CEC frame is valid or not
/// @ingroup apiCEC_BASIC
/// @param  msg_type       \b IN: CEC message type
/// @param  ucLen       \b IN: message length, include header and opcode
/// @return TRUE: CEC frame is valid
/// @return FALSE: CEC frame is not valid
//-------------------------------------------------------------------------------------------------
MS_BOOL MApi_CEC_CheckFrame(MsCEC_MSG_TRANS_TYPE msg_type, MS_U8 ucLen);

//-------------------------------------------------------------------------------------------------
/// Use to check exist devices
/// @ingroup apiCEC_BASIC
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_CheckExistDevices(void);

//-------------------------------------------------------------------------------------------------
/// Use to config wake up
/// @ingroup apiCEC_BASIC
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_ConfigWakeUp(void);

//-------------------------------------------------------------------------------------------------
/// Enable CEC
/// @ingroup apiCEC_BASIC
/// @param  bEnableFlag       \b IN: enable CEC or not
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_Enabled(MS_BOOL bEnableFlag);

//-------------------------------------------------------------------------------------------------
/// Set physical address
/// @ingroup apiCEC_STATUS
/// @param  pdata       \b IN: physical address
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetMyPhysicalAddress(MS_U8 *pdata);

#if ENABLE_CEC_MULTIPLE
//-------------------------------------------------------------------------------------------------
/// Set second logical address
/// @ingroup apiCEC_SECOND
/// @param  myLA       \b IN: second logical address
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetMyLogicalAddress2(MsCEC_DEVICELA myLA);

//-------------------------------------------------------------------------------------------------
/// Report second physical address
/// @ingroup apiCEC_SECOND
/// @return CEC_ERROR_CODE
//-------------------------------------------------------------------------------------------------
CEC_ERROR_CODE MApi_CEC_Msg_ReportPhycalAddress2(void);

//-------------------------------------------------------------------------------------------------
/// Set second physical address
/// @ingroup apiCEC_SECOND
/// @param  pdata       \b IN: second physical address
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetMyPhysicalAddress2(MS_U8 *pdata);

//-------------------------------------------------------------------------------------------------
/// Set initiator logical address
/// @ingroup apiCEC_SECOND
/// @param  IniLA       \b IN: initiator logical address
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetInitiator(MsCEC_DEVICELA IniLA);
#endif

//-------------------------------------------------------------------------------------------------
/// Get Tx status
/// @ingroup apiCEC_STATUS
/// @return status
///[Bit0]: CEC receives a new message.
///[Bit1]: CEC transmits a message successfully.
///[Bit2]: CEC retry fail for TX.
///[Bit3]: CEC lost arbitration to the second initiator.
//-------------------------------------------------------------------------------------------------
// MS_U8 MApi_CEC_GetTxStatus(void);

//-------------------------------------------------------------------------------------------------
/// Set power state
/// @ingroup apiCEC_STATUS
/// @param  u16PowerState       \b IN: power state
/// @return 0: success
/// @return 1: fail
//-------------------------------------------------------------------------------------------------
MS_U32 MApi_CEC_SetPowerState(EN_POWER_MODE u16PowerState);

//-------------------------------------------------------------------------------------------------
/// Set retry count
/// @ingroup apiCEC_ToBeAdd
/// @param  u8RetryCount       \b IN: retry count
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_SetRetryCount(MS_U8 u8RetryCount);

//-------------------------------------------------------------------------------------------------
/// config wakeup info vendor ID
/// @ingroup apiCEC_ToBeAdd
/// @param  u8CecVendorID       \b IN: vendor ID
/// @return None
//-------------------------------------------------------------------------------------------------
void MApi_CEC_ConfigWakeupInfoVendorID(MS_U8* u8CecVendorID);

//-------------------------------------------------------------------------------------------------
/// Set logical address to next active device
/// @ingroup apiCEC_ToBeAdd
/// @param  None
/// @return logical address
//-------------------------------------------------------------------------------------------------
MsCEC_DEVICELA MApi_CEC_NextDevice(void);

//-------------------------------------------------------------------------------------------------
/// Check Rx Buf if empty or not
/// @ingroup apiCEC_ToBeAdd
/// @param  None
/// @return 1: empty
/// @return 0: non empty
//-------------------------------------------------------------------------------------------------
MS_BOOL MApi_CEC_IsRxBufEmpty(void);

//-------------------------------------------------------------------------------------------------
/// Check divcec is Tx or not
/// @ingroup apiCEC_ToBeAdd
/// @param  None
/// @return 1: Tx
/// @return 0: Rx
//-------------------------------------------------------------------------------------------------
MS_BOOL MApi_CEC_CheckDeviceIsTx(void);

//-------------------------------------------------------------------------------------------------
/// General API
/// @ingroup apiCEC_ToBeAdd
/// @param  u32Cmd       \b IN: API name
/// @param  pBuf       \b IN: buffer of input and output value
/// @param  u32BufSize       \b IN: buffer size
/// @return TRUE: call API success
/// @return FALSE: call API fail
//-------------------------------------------------------------------------------------------------
MS_BOOL SYMBOL_WEAK MApi_CEC_Ctrl(MS_U32 u32Cmd, void *pBuf, MS_U32 u32BufSize);

#ifdef __cplusplus
}
#endif

#endif //_API_CEC_H_

