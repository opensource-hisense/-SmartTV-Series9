#include <stddef.h>
void mpsort (void const **, size_t, int (*) (void const *, void const *));
